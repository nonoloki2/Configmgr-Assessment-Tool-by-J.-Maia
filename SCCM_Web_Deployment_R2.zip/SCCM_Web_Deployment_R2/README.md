# SCCM Web Deployment Console — Release 2

## What changed

Release 2 no longer depends on the current PowerShell location or on a CMSite drive remaining alive between HTTP requests.

Every SCCM API call now:

1. Verifies that the ConfigurationManager module is loaded.
2. Verifies that the CMSite drive exists.
3. Recreates the drive when needed.
4. Switches into the site drive.
5. Executes the ConfigMgr command.
6. Restores the previous PowerShell location.
7. Performs one automatic reconnect attempt if the first operation fails.

This specifically fixes searches that connected successfully but later failed because the `A03:` or other site drive was unavailable.

## Start

Run Windows PowerShell 5.1 as Administrator:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
cd C:\Path\SCCM_Web_Deployment_R2
.\Start-SCCMWebDeploy.ps1
```

Open:

```text
http://localhost:8787/
```

Enter the Site Code and SMS Provider in **Connection Settings**.

## Search behavior

Application search checks:

- Display name
- Version
- Manufacturer

Collection search checks:

- Collection name
- Collection ID

All matches are displayed. Applications are selected by `CI_ID`; collections are selected by `CollectionID`.

## Logs

```text
logs\SCCMWebDeploy-YYYYMMDD.log
```

Application and collection searches are now logged, including the submitted query and full backend exceptions.

## Safe first test

Use a small test collection and create an `Available` deployment first.
