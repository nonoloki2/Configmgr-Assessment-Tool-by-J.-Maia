﻿#requires -Version 5.1
<#
.SYNOPSIS
    SCCM Web Deployment Console - Release 1
.DESCRIPTION
    Local web interface for searching SCCM Applications and Device Collections
    and creating Application deployments using unique SCCM identifiers.
.NOTES
    Run in an elevated Windows PowerShell 5.1 session on a machine with the
    Configuration Manager console installed.
#>

[CmdletBinding()]
param(
    [string]$ConfigPath = (Join-Path $PSScriptRoot 'config.json')
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Write-Log {
    param(
        [Parameter(Mandatory)][string]$Message,
        [ValidateSet('INFO','WARN','ERROR','AUDIT')][string]$Level = 'INFO'
    )
    $line = '{0:u} [{1}] {2}' -f (Get-Date), $Level, $Message
    Write-Host $line
    Add-Content -LiteralPath $script:LogFile -Value $line -Encoding UTF8
}

function Send-Json {
    param(
        [Parameter(Mandatory)]$Context,
        [Parameter(Mandatory)]$Data,
        [int]$StatusCode = 200
    )
    $json = $Data | ConvertTo-Json -Depth 8 -Compress
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $Context.Response.StatusCode = $StatusCode
    $Context.Response.ContentType = 'application/json; charset=utf-8'
    $Context.Response.ContentLength64 = $bytes.Length
    $Context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $Context.Response.OutputStream.Close()
}

function Send-File {
    param(
        [Parameter(Mandatory)]$Context,
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$ContentType
    )
    if (-not (Test-Path -LiteralPath $Path)) {
        Send-Json -Context $Context -Data @{ ok = $false; error = 'File not found.' } -StatusCode 404
        return
    }
    $bytes = [IO.File]::ReadAllBytes($Path)
    $Context.Response.StatusCode = 200
    $Context.Response.ContentType = $ContentType
    $Context.Response.ContentLength64 = $bytes.Length
    $Context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $Context.Response.OutputStream.Close()
}

function Read-RequestJson {
    param([Parameter(Mandatory)]$Request)
    $reader = New-Object IO.StreamReader($Request.InputStream, $Request.ContentEncoding)
    try {
        $raw = $reader.ReadToEnd()
    } finally {
        $reader.Dispose()
    }
    if ([string]::IsNullOrWhiteSpace($raw)) { return $null }
    return $raw | ConvertFrom-Json
}

function Connect-ConfigMgr {
    param(
        [Parameter(Mandatory)][string]$SiteCode,
        [Parameter(Mandatory)][string]$SmsProvider
    )

    if ([string]::IsNullOrWhiteSpace($SiteCode)) { throw 'Site Code is required.' }
    if ([string]::IsNullOrWhiteSpace($SmsProvider)) { throw 'SMS Provider is required.' }

    $modulePath = $null
    if ($env:SMS_ADMIN_UI_PATH) {
        $candidate = Join-Path (Split-Path $env:SMS_ADMIN_UI_PATH -Parent) 'ConfigurationManager.psd1'
        if (Test-Path -LiteralPath $candidate) { $modulePath = $candidate }
    }
    if (-not $modulePath) {
        $module = Get-Module -ListAvailable ConfigurationManager | Select-Object -First 1
        if ($module) { $modulePath = $module.Path }
    }
    if (-not $modulePath) {
        throw 'ConfigurationManager PowerShell module was not found. Install the SCCM console on this computer.'
    }

    Import-Module $modulePath -Force

    $existing = Get-PSDrive -Name $SiteCode -PSProvider CMSite -ErrorAction SilentlyContinue
    if ($existing) { Remove-PSDrive -Name $SiteCode -Force -ErrorAction SilentlyContinue }

    New-PSDrive -Name $SiteCode -PSProvider CMSite -Root $SmsProvider -ErrorAction Stop | Out-Null

    $script:Config.SiteCode = $SiteCode.ToUpperInvariant()
    $script:Config.SmsProvider = $SmsProvider
    $script:IsConnected = $true
    Set-Location ('{0}:\' -f $script:Config.SiteCode)

    $site = Get-CMSite -ErrorAction Stop | Select-Object -First 1
    $script:Config | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $ConfigPath -Encoding UTF8

    Write-Log "Connected to SCCM Site '$($script:Config.SiteCode)' through '$SmsProvider'."

    [pscustomobject]@{
        siteCode = $script:Config.SiteCode
        smsProvider = $script:Config.SmsProvider
        siteName = [string]$site.SiteName
        version = [string]$site.Version
    }
}

function Invoke-InSiteDrive {
    param([Parameter(Mandatory)][scriptblock]$ScriptBlock)
    if (-not $script:IsConnected) { throw 'Not connected to SCCM. Configure the connection in the web interface.' }
    $old = Get-Location
    try {
        Set-Location ('{0}:\' -f $script:Config.SiteCode)
        & $ScriptBlock
    } finally {
        Set-Location $old
    }
}

function Get-Applications {
    param([string]$Query)

    Invoke-InSiteDrive {
        $all = Get-CMApplication -Fast
        if (-not [string]::IsNullOrWhiteSpace($Query)) {
            $escaped = [WildcardPattern]::Escape($Query.Trim())
            $all = $all | Where-Object {
                $_.LocalizedDisplayName -like "*$escaped*" -or
                $_.SoftwareVersion -like "*$escaped*" -or
                $_.Manufacturer -like "*$escaped*"
            }
        }

        @($all | Sort-Object LocalizedDisplayName, SoftwareVersion, CIVersion -Descending |
            Select-Object -First $script:Config.MaxSearchResults |
            ForEach-Object {
                [pscustomobject]@{
                    name         = [string]$_.LocalizedDisplayName
                    version      = [string]$_.SoftwareVersion
                    manufacturer = [string]$_.Manufacturer
                    ciId         = [int]$_.CI_ID
                    revision     = [int]$_.CIVersion
                    modelName    = [string]$_.ModelName
                    lastModified = if ($_.DateLastModified) { ([datetime]$_.DateLastModified).ToString('s') } else { $null }
                    isExpired    = [bool]$_.IsExpired
                    isEnabled    = -not [bool]$_.IsExpired
                }
            })
    }
}

function Get-Collections {
    param([string]$Query)

    Invoke-InSiteDrive {
        $all = Get-CMDeviceCollection
        if (-not [string]::IsNullOrWhiteSpace($Query)) {
            $escaped = [WildcardPattern]::Escape($Query.Trim())
            $all = $all | Where-Object {
                $_.Name -like "*$escaped*" -or $_.CollectionID -like "*$escaped*"
            }
        }

        @($all | Sort-Object Name |
            Select-Object -First $script:Config.MaxSearchResults |
            ForEach-Object {
                [pscustomobject]@{
                    name                    = [string]$_.Name
                    collectionId            = [string]$_.CollectionID
                    memberCount             = [int]$_.MemberCount
                    limitingCollectionName  = [string]$_.LimitToCollectionName
                    limitingCollectionId    = [string]$_.LimitToCollectionID
                    comment                 = [string]$_.Comment
                }
            })
    }
}

function Test-BlockedCollection {
    param(
        [Parameter(Mandatory)][string]$CollectionId,
        [Parameter(Mandatory)][string]$CollectionName
    )
    return (
        $script:Config.BlockedCollectionIds -contains $CollectionId -or
        $script:Config.BlockedCollectionNames -contains $CollectionName
    )
}

function New-ApplicationDeploymentFromRequest {
    param(
        [Parameter(Mandatory)]$Body,
        [Parameter(Mandatory)][string]$UserName,
        [Parameter(Mandatory)][string]$RemoteAddress
    )

    if (-not $script:Config.EnableDeploymentCreation) {
        throw 'Deployment creation is disabled in config.json.'
    }

    $required = @('applicationCiId','collectionId','collectionName','deployAction','deployPurpose','userNotification','confirmationText')
    foreach ($field in $required) {
        if ($null -eq $Body.$field -or [string]::IsNullOrWhiteSpace([string]$Body.$field)) {
            throw "Required field is missing: $field"
        }
    }

    if ([string]$Body.confirmationText -cne [string]$Body.collectionName) {
        throw 'Collection confirmation text does not match exactly.'
    }

    $validActions = @('Install','Uninstall')
    $validPurposes = @('Available','Required')
    $validNotifications = @('DisplayAll','DisplaySoftwareCenterOnly','HideAll')

    if ($validActions -notcontains [string]$Body.deployAction) { throw 'Invalid deploy action.' }
    if ($validPurposes -notcontains [string]$Body.deployPurpose) { throw 'Invalid deploy purpose.' }
    if ($validNotifications -notcontains [string]$Body.userNotification) { throw 'Invalid notification option.' }

    if (Test-BlockedCollection -CollectionId $Body.collectionId -CollectionName $Body.collectionName) {
        throw "The collection '$($Body.collectionName)' is blocked by config.json."
    }

    $available = if ($Body.availableDateTime) { [datetime]::Parse([string]$Body.availableDateTime) } else { Get-Date }
    $deadline = $null

    if ([string]$Body.deployPurpose -eq 'Required') {
        if (-not $Body.deadlineDateTime) { throw 'A deadline is required for a Required deployment.' }
        $deadline = [datetime]::Parse([string]$Body.deadlineDateTime)
        if ($deadline -lt $available) { throw 'Deadline cannot be earlier than availability.' }
    }

    $ciId = [int]$Body.applicationCiId
    $collectionId = [string]$Body.collectionId

    $result = Invoke-InSiteDrive {
        $app = Get-CMApplication -Id $ciId -Fast
        if (-not $app) { throw "Application CI_ID $ciId was not found." }

        $collection = Get-CMDeviceCollection -Id $collectionId
        if (-not $collection) { throw "Device Collection $collectionId was not found." }

        # Revalidate names/details immediately before the write.
        $actualAppName = [string]$app.LocalizedDisplayName
        $actualCollectionName = [string]$collection.Name

        if ($actualCollectionName -cne [string]$Body.collectionName) {
            throw "Collection name changed or did not match. Current name: $actualCollectionName"
        }

        $params = @{
            Id                  = $ciId
            CollectionId        = $collectionId
            DeployAction        = [string]$Body.deployAction
            DeployPurpose       = [string]$Body.deployPurpose
            AvailableDateTime   = $available
            UserNotification    = [string]$Body.userNotification
            TimeBaseOn          = 'LocalTime'
            OverrideServiceWindow = [bool]$Body.overrideServiceWindow
            RebootOutsideServiceWindow = [bool]$Body.rebootOutsideServiceWindow
            UseMeteredNetwork   = [bool]$Body.useMeteredNetwork
            ErrorAction         = 'Stop'
        }

        if ($deadline) { $params.DeadlineDateTime = $deadline }
        if (-not [string]::IsNullOrWhiteSpace([string]$Body.comment)) {
            $params.Comment = [string]$Body.comment
        }

        $created = New-CMApplicationDeployment @params

        [pscustomobject]@{
            applicationName = $actualAppName
            applicationCiId = $ciId
            collectionName  = $actualCollectionName
            collectionId    = $collectionId
            deployAction     = [string]$Body.deployAction
            deployPurpose    = [string]$Body.deployPurpose
            availableDateTime = $available.ToString('s')
            deadlineDateTime = if ($deadline) { $deadline.ToString('s') } else { $null }
            createdObject    = if ($created) { [string]$created } else { 'Deployment command completed.' }
        }
    }

    Write-Log -Level AUDIT -Message (
        "User='$UserName'; Remote='$RemoteAddress'; Action='Create Application Deployment'; " +
        "Application='$($result.applicationName)' CI_ID='$($result.applicationCiId)'; " +
        "Collection='$($result.collectionName)' CollectionID='$($result.collectionId)'; " +
        "Purpose='$($result.deployPurpose)'; DeployAction='$($result.deployAction)'"
    )

    return $result
}

if (-not (Test-Path -LiteralPath $ConfigPath)) {
    throw "Configuration file not found: $ConfigPath"
}

$script:Config = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
$script:LogFile = Join-Path $PSScriptRoot ('logs\SCCMWebDeploy-{0}.log' -f (Get-Date -Format 'yyyyMMdd'))
New-Item -ItemType Directory -Path (Split-Path $script:LogFile) -Force | Out-Null

$script:IsConnected = $false

$listener = New-Object Net.HttpListener
$listener.Prefixes.Add([string]$script:Config.ListenUrl)
$listener.AuthenticationSchemes = [Net.AuthenticationSchemes]::Anonymous

try {
    $listener.Start()
} catch {
    throw "Could not listen on $($script:Config.ListenUrl). Run PowerShell as Administrator or reserve the URL with netsh. $($_.Exception.Message)"
}

Write-Log "SCCM Web Deployment Console started at $($script:Config.ListenUrl)"
Write-Log "Waiting for SCCM connection settings from the web interface."
Write-Host ''
Write-Host "Open $($script:Config.ListenUrl) in a browser. Press Ctrl+C to stop." -ForegroundColor Cyan

try {
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $request = $context.Request
        $path = $request.Url.AbsolutePath.TrimEnd('/')
        if ([string]::IsNullOrEmpty($path)) { $path = '/' }

        try {
            switch -Regex ("$($request.HttpMethod) $path") {
                '^GET /$' {
                    Send-File -Context $context -Path (Join-Path $PSScriptRoot 'www\index.html') -ContentType 'text/html; charset=utf-8'
                    break
                }
                '^GET /api/health$' {
                    Send-Json -Context $context -Data @{
                        ok = $true
                        connected = [bool]$script:IsConnected
                        siteCode = [string]$script:Config.SiteCode
                        smsProvider = [string]$script:Config.SmsProvider
                        deploymentCreationEnabled = [bool]$script:Config.EnableDeploymentCreation
                        serverTime = (Get-Date).ToString('s')
                    }
                    break
                }
                '^GET /api/config$' {
                    Send-Json -Context $context -Data @{
                        ok = $true
                        siteCode = [string]$script:Config.SiteCode
                        smsProvider = [string]$script:Config.SmsProvider
                    }
                    break
                }
                '^POST /api/connect$' {
                    $body = Read-RequestJson -Request $request
                    $connection = Connect-ConfigMgr -SiteCode ([string]$body.siteCode) -SmsProvider ([string]$body.smsProvider)
                    Send-Json -Context $context -Data @{
                        ok = $true
                        message = 'Connected to SCCM successfully.'
                        connection = $connection
                    }
                    break
                }
                '^GET /api/applications$' {
                    $query = [Web.HttpUtility]::UrlDecode($request.QueryString['query'])
                    $items = Get-Applications -Query $query
                    Send-Json -Context $context -Data @{ ok = $true; count = @($items).Count; items = @($items) }
                    break
                }
                '^GET /api/collections$' {
                    $query = [Web.HttpUtility]::UrlDecode($request.QueryString['query'])
                    $items = Get-Collections -Query $query
                    Send-Json -Context $context -Data @{ ok = $true; count = @($items).Count; items = @($items) }
                    break
                }
                '^POST /api/deployments/application$' {
                    $body = Read-RequestJson -Request $request
                    $remote = if ($request.RemoteEndPoint) { $request.RemoteEndPoint.Address.ToString() } else { 'unknown' }
                    $user = [Security.Principal.WindowsIdentity]::GetCurrent().Name
                    $result = New-ApplicationDeploymentFromRequest -Body $body -UserName $user -RemoteAddress $remote
                    Send-Json -Context $context -Data @{ ok = $true; message = 'Application deployment created successfully.'; deployment = $result } -StatusCode 201
                    break
                }
                default {
                    Send-Json -Context $context -Data @{ ok = $false; error = 'Route not found.' } -StatusCode 404
                }
            }
        } catch {
            Write-Log -Level ERROR -Message $_.Exception.Message
            if ($context.Response.OutputStream.CanWrite) {
                Send-Json -Context $context -Data @{ ok = $false; error = $_.Exception.Message } -StatusCode 400
            }
        }
    }
} finally {
    if ($listener.IsListening) { $listener.Stop() }
    $listener.Close()
    Write-Log 'SCCM Web Deployment Console stopped.'
}
