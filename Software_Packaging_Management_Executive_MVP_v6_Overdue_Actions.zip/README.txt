SOFTWARE PACKAGING MANAGEMENT - EXECUTIVE MVP V6

START
1. Extract the complete ZIP to a new folder.
2. Run START_APPLICATION.bat.
3. Keep the PowerShell window open.
4. Use the application at http://localhost:8765.

V6 CRITICAL IMPROVEMENTS
- ServiceNow requester email extraction accepts only a valid email address.
- "Cell phone" or other adjacent labels can no longer populate Requester Email.
- Opened date extraction searches specifically around the ServiceNow Opened field.
- Supports ServiceNow dates such as MM/DD/YYYY and DD/MM/YYYY.
- Delivery Target is automatically calculated as Opened Date + 15 calendar days.
- Days Late displayed on Executive Dashboard and Requests table.
- Longest Delay, Average Delay and SLA Compliance KPIs.
- Action Required button: Contact Developer Assigned.
- Follow-up form records delay reason, revised completion date, support required and recovery plan.
- Existing browser records are preserved because the storage key remains unchanged.

DATA STORAGE
Records remain in the browser local storage. Do not clear browser site data for localhost:8765.
