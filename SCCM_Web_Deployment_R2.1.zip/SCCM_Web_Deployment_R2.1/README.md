# SCCM Web Deployment Console — Release 2.1

## Correction

Release 2 incorrectly invoked the automatic CMSite recovery wrapper while the initial SCCM connection was still being created. In some environments this produced:

```text
Value cannot be null.
Parameter name: key
```

Release 2.1 restores the direct connection sequence that worked in Release 1.1:

1. Load ConfigurationManager module.
2. Remove an old drive with the same Site Code.
3. Create the CMSite drive.
4. Enter the drive.
5. Validate with `Get-CMSite`.
6. Mark the web session as connected.

Automatic drive repair is now used only for later searches and deployment operations.

## Start

Use Windows PowerShell 5.1 as Administrator:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
cd C:\Path\SCCM_Web_Deployment_R2.1
.\Start-SCCMWebDeploy.ps1
```

Open:

```text
http://localhost:8787/
```

Configure Site Code and SMS Provider through **Connection Settings**.

## Logs

```text
logs\SCCMWebDeploy-YYYYMMDD.log
```
