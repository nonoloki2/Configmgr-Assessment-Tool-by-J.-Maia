const PHASES=[
  {name:"New Request",progress:0},
  {name:"Data Gathering",progress:10},
  {name:"Packaging Work",progress:55},
  {name:"Testing",progress:75},
  {name:"Rollout",progress:90},
  {name:"Monitoring / Reporting",progress:95},
  {name:"Completed",progress:100}
];
const STATUSES=["Not Started","In Progress","Waiting Requestor","Blocked","Completed"];
const STORAGE_KEY="softwarePackagingRequestsV1";
let requests=JSON.parse(localStorage.getItem(STORAGE_KEY)||"[]");

const $=id=>document.getElementById(id);
const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[m]));
const today=()=>new Date(new Date().toDateString());
const dateObj=s=>s?new Date(s+"T00:00:00"):null;
const fmt=s=>s?dateObj(s).toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"}):"—";
const phaseProgress=p=>(PHASES.find(x=>x.name===p)||PHASES[0]).progress;
const isCompleted=r=>r.phase==="Completed"||r.status==="Completed";
const isLate=r=>!isCompleted(r)&&dateObj(r.deliveryTarget)&&dateObj(r.deliveryTarget)<today();
const dueWeek=r=>{if(isCompleted(r)||!r.deliveryTarget)return false;const d=dateObj(r.deliveryTarget),t=today(),e=new Date(t);e.setDate(t.getDate()+7);return d>=t&&d<=e};
function save(){localStorage.setItem(STORAGE_KEY,JSON.stringify(requests))}
function badge(value){let c="";const v=value.toLowerCase();if(v.includes("blocked")||v.includes("late"))c="blocked";else if(v.includes("completed"))c="completed";else if(v.includes("waiting"))c="waiting";return `<span class="badge ${c}">${esc(value)}</span>`}
function progressCell(p){return `<div class="mini-progress"><div class="mini-track"><div class="mini-fill" style="width:${p}%"></div></div><strong>${p}%</strong></div>`}

function initSelects(){
  $("phase").innerHTML=PHASES.map(x=>`<option>${x.name}</option>`).join("");
  $("phaseFilter").innerHTML='<option value="">All phases</option>'+PHASES.map(x=>`<option>${x.name}</option>`).join("");
  $("status").innerHTML=STATUSES.map(x=>`<option>${x}</option>`).join("");
  $("statusFilter").innerHTML='<option value="">All statuses</option>'+STATUSES.map(x=>`<option>${x}</option>`).join("");
}
function renderDashboard(){
  const total=requests.length, completed=requests.filter(isCompleted).length, late=requests.filter(isLate).length;
  const blocked=requests.filter(r=>r.status==="Blocked").length, inProgress=total-completed;
  const due=requests.filter(dueWeek).length;
  const avg=total?Math.round(requests.reduce((a,r)=>a+phaseProgress(r.phase),0)/total):0;
  $("kpiTotal").textContent=total;$("kpiCompleted").textContent=completed;$("kpiProgress").textContent=inProgress;
  $("kpiLate").textContent=late;$("kpiBlocked").textContent=blocked;$("kpiDueWeek").textContent=due;
  $("overallPct").textContent=avg+"%";$("progressRing").style.setProperty("--progress",avg);
  $("progressTotal").textContent=total;$("progressCompleted").textContent=completed;$("progressRemaining").textContent=total-completed;

  renderBars("phaseChart",PHASES.map(p=>({label:p.name,value:requests.filter(r=>r.phase===p.name).length})));
  const developers={};requests.filter(r=>!isCompleted(r)).forEach(r=>developers[r.developerAssigned||"Unassigned"]=(developers[r.developerAssigned||"Unassigned"]||0)+1);
  renderBars("developerChart",Object.entries(developers).map(([label,value])=>({label,value})).sort((a,b)=>b.value-a.value).slice(0,8));
  renderBars("deliveryChart",[
    {label:"Late",value:late,cls:"danger"},
    {label:"Due This Week",value:due,cls:"warning"},
    {label:"On Schedule",value:requests.filter(r=>!isCompleted(r)&&!isLate(r)&&!dueWeek(r)).length,cls:"success"},
    {label:"Completed",value:completed,cls:"success"}
  ]);
  const priority=[...requests].sort((a,b)=>{
    const score=r=>(isLate(r)?100:0)+(r.priority?.startsWith("1")?50:r.priority?.startsWith("2")?30:0)+(dueWeek(r)?20:0);
    return score(b)-score(a)||String(a.deliveryTarget).localeCompare(String(b.deliveryTarget));
  }).slice(0,8);
  $("priorityTable").innerHTML=priority.length?priority.map(r=>rowHtml(r,false)).join(""):`<tr><td colspan="8" class="empty">No requests registered yet.</td></tr>`;
}
function renderBars(id,items){
  const max=Math.max(1,...items.map(x=>x.value));
  $(id).innerHTML=items.length?items.map(x=>`<div class="bar-row ${x.cls||""}"><span class="bar-label" title="${esc(x.label)}">${esc(x.label)}</span><div class="bar-track"><div class="bar-fill" style="width:${(x.value/max)*100}%"></div></div><strong>${x.value}</strong></div>`).join(""):`<div class="empty">No data available.</div>`;
}
function rowHtml(r,actions=true){
  const late=isLate(r);
  return `<tr class="${late?"late-row":""}">
    <td><strong>${esc(r.taskNumber)}</strong></td><td>${esc(r.softwareName)}</td>
    ${actions?`<td>${esc(r.requestedBy)}</td>`:""}
    <td>${fmt(r.requestDate)}</td><td>${fmt(r.deliveryTarget)} ${late?badge("Late"):""}</td>
    <td>${esc(r.developerAssigned)}</td><td>${badge(r.phase)}</td><td>${badge(r.status)}</td>
    <td>${progressCell(phaseProgress(r.phase))}</td>
    ${actions?`<td><button class="action-btn" onclick="editRequest('${r.id}')">Edit</button></td>`:""}
  </tr>`;
}
function renderRequests(){
  const q=$("searchInput").value.trim().toLowerCase(), pf=$("phaseFilter").value, sf=$("statusFilter").value;
  const data=requests.filter(r=>{
    const text=[r.taskNumber,r.softwareName,r.requestedBy,r.requesterEmail,r.developerAssigned].join(" ").toLowerCase();
    return (!q||text.includes(q))&&(!pf||r.phase===pf)&&(!sf||r.status===sf);
  }).sort((a,b)=>String(a.deliveryTarget).localeCompare(String(b.deliveryTarget)));
  $("requestsTable").innerHTML=data.length?data.map(r=>rowHtml(r,true)).join(""):`<tr><td colspan="10" class="empty">No matching requests.</td></tr>`;
}
function showView(name){
  document.querySelectorAll(".view").forEach(v=>v.classList.remove("active"));
  document.querySelectorAll(".nav-item").forEach(v=>v.classList.remove("active"));
  $(name+"View").classList.add("active");
  document.querySelector(`[data-view="${name}"]`)?.classList.add("active");
  $("pageTitle").textContent=name==="dashboard"?"Executive Dashboard":"Software Requests";
  $("pageSubtitle").textContent=name==="dashboard"?"Software packaging portfolio status and delivery control":"Register, assign and track packaging and deployment requests";
  if(name==="dashboard")renderDashboard();else renderRequests();
}
function openModal(r=null){
  $("requestForm").reset();$("requestId").value=r?.id||"";
  $("modalTitle").textContent=r?"Edit Software Request":"New Software Request";
  $("deleteRequest").classList.toggle("hidden",!r);
  if(r){
    ["taskNumber","softwareName","requestedBy","requesterEmail","requestDate","deliveryTarget","developerAssigned","assignmentGroup","assignedTo","priority","phase","status","notes"].forEach(k=>$(k).value=r[k]??"");
    ["sourceFiles","prerequisites","documentation","requestorComplete"].forEach(k=>$(k).checked=!!r[k]);
  }else{
    $("requestDate").value=new Date().toISOString().slice(0,10);$("phase").value="New Request";$("status").value="Not Started";
  }
  $("requestModal").showModal();
}
window.editRequest=id=>openModal(requests.find(r=>r.id===id));
function closeModal(){$("requestModal").close()}
function submitRequest(e){
  e.preventDefault();
  const id=$("requestId").value||crypto.randomUUID();
  const r={id};
  ["taskNumber","softwareName","requestedBy","requesterEmail","requestDate","deliveryTarget","developerAssigned","assignmentGroup","assignedTo","priority","phase","status","notes"].forEach(k=>r[k]=$(k).value.trim());
  ["sourceFiles","prerequisites","documentation","requestorComplete"].forEach(k=>r[k]=$(k).checked);
  r.updatedAt=new Date().toISOString();
  const idx=requests.findIndex(x=>x.id===id);if(idx>=0)requests[idx]=r;else requests.push(r);
  save();closeModal();renderDashboard();renderRequests();
}
function deleteCurrent(){
  const id=$("requestId").value;if(!id)return;
  if(confirm("Delete this request permanently?")){requests=requests.filter(r=>r.id!==id);save();closeModal();renderDashboard();renderRequests()}
}
function exportReport(){
  const rows=requests.map(r=>`<tr><td>${esc(r.taskNumber)}</td><td>${esc(r.softwareName)}</td><td>${fmt(r.requestDate)}</td><td>${fmt(r.deliveryTarget)}</td><td>${esc(r.developerAssigned)}</td><td>${esc(r.phase)}</td><td>${esc(r.status)}</td><td>${phaseProgress(r.phase)}%</td></tr>`).join("");
  const html=`<!doctype html><html><head><meta charset="utf-8"><title>Software Packaging Executive Report</title><style>body{font-family:Segoe UI,Arial;padding:30px;color:#172033}h1{margin-bottom:4px}.muted{color:#687386}table{width:100%;border-collapse:collapse;margin-top:22px}th,td{border-bottom:1px solid #ddd;padding:9px;text-align:left;font-size:12px}th{background:#173b75;color:#fff}.kpis{display:flex;gap:12px;margin-top:20px}.k{padding:14px 20px;border:1px solid #ddd;border-radius:10px}.k strong{display:block;font-size:26px}</style></head><body><h1>Software Packaging Executive Report</h1><div class="muted">Generated ${new Date().toLocaleString()}</div><div class="kpis"><div class="k">Total<strong>${requests.length}</strong></div><div class="k">Completed<strong>${requests.filter(isCompleted).length}</strong></div><div class="k">Late<strong>${requests.filter(isLate).length}</strong></div><div class="k">Blocked<strong>${requests.filter(r=>r.status==="Blocked").length}</strong></div></div><table><thead><tr><th>Task</th><th>Software</th><th>Request Date</th><th>Delivery Target</th><th>Developer</th><th>Phase</th><th>Status</th><th>Progress</th></tr></thead><tbody>${rows}</tbody></table></body></html>`;
  const blob=new Blob([html],{type:"text/html"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="Software_Packaging_Executive_Report.html";a.click();URL.revokeObjectURL(a.href);
}
document.querySelectorAll("[data-view]").forEach(b=>b.onclick=()=>showView(b.dataset.view));
document.querySelectorAll("[data-go-requests]").forEach(b=>b.onclick=()=>showView("requests"));
$("newRequestSide").onclick=()=>openModal();$("newRequestTop").onclick=()=>openModal();
$("closeModal").onclick=closeModal;$("cancelModal").onclick=closeModal;$("requestForm").onsubmit=submitRequest;$("deleteRequest").onclick=deleteCurrent;
$("exportBtn").onclick=exportReport;
["searchInput","phaseFilter","statusFilter"].forEach(id=>$(id).addEventListener("input",renderRequests));
$("clearFilters").onclick=()=>{$("searchInput").value="";$("phaseFilter").value="";$("statusFilter").value="";renderRequests()};
initSelects();renderDashboard();renderRequests();
