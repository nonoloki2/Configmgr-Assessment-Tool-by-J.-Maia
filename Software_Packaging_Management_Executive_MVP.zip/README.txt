SOFTWARE PACKAGING MANAGEMENT - EXECUTIVE MVP

How to use
1. Extract the ZIP file.
2. Open index.html in Microsoft Edge, Google Chrome or Firefox.
3. Click "+ New Request".
4. Register ServiceNow task information.
5. Data remains stored locally in the browser using localStorage.
6. Use "Export Report" to generate an executive HTML report.

Priority executive fields included
- Request Date
- Requested / Expected Delivery Target
- Developer Assigned
- SW Packaging Phase
  - Data Gathering
  - Packaging Work
  - Testing
- Deployment Phase
  - Rollout
  - Monitoring / Reporting

Important
- Do not clear browser site data, or local records will be removed.
- Use the same browser and the same index.html location.
- This MVP does not yet import ServiceNow PDFs.
