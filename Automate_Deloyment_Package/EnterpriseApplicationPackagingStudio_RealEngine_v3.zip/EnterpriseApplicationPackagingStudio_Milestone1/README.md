# Enterprise Application Packaging Studio — Real Engine v3

This build replaces the simulated analysis screen with a real background analysis worker.

## What can be tested now

- Source path validation and file enumeration
- Real SHA-256 calculation for every supported file
- File and product metadata collection
- Authenticode signature validation on Windows
- Installer technology detection
- MSI ProductCode and UpgradeCode extraction
- Silent command candidate generation
- Detection candidate generation
- Live backend progress, timestamps, job ID and event console
- Cancel operation
- Explicit failure messages instead of an endless animated bar

## Run

Open PowerShell as Administrator:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\run.ps1
```

Open `http://127.0.0.1:5188`.

## Independent proof test

This verifies the analysis functions without the browser:

```powershell
.\Test-InstallerAnalysis.ps1 -Path 'C:\Packaging\CitrixWorkspaceApp.exe'
```

It calculates real hashes, reads metadata and signature information, and creates `InstallerAnalysis-Proof.json`.

## Expected visible processes

The web backend runs as `dotnet.exe`. During Authenticode and MSI metadata checks, short-lived `powershell.exe` processes may appear. Static analysis does not start `msiexec.exe`; that process is used only during an actual installation or uninstall test.
