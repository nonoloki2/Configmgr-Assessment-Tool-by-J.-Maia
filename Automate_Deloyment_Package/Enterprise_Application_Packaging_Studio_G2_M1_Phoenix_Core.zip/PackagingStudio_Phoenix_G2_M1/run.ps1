$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = 'Enterprise Application Packaging Studio - Phoenix'
Set-Location $PSScriptRoot

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    Write-Host 'Microsoft .NET 8 SDK or Runtime was not found.' -ForegroundColor Red
    Write-Host 'Install .NET 8 and run this file again.' -ForegroundColor Yellow
    Read-Host 'Press Enter to close'
    exit 1
}

$port = 5188
$existing = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
if (-not $existing) {
    $process = Start-Process dotnet -ArgumentList 'run --project PackagingStudio.Phoenix.csproj' -PassThru -WindowStyle Minimized
}

$uri = "http://127.0.0.1:$port/api/health"
$ready = $false
for ($i=0; $i -lt 60; $i++) {
    try {
        $response = Invoke-RestMethod -Uri $uri -TimeoutSec 1
        if ($response.status -eq 'ready') { $ready = $true; break }
    } catch { Start-Sleep -Milliseconds 500 }
}

if (-not $ready) {
    Write-Host 'The local service did not become ready.' -ForegroundColor Red
    Write-Host 'Run: dotnet run --project PackagingStudio.Phoenix.csproj' -ForegroundColor Yellow
    Read-Host 'Press Enter to close'
    exit 1
}
Start-Process "http://127.0.0.1:$port"
