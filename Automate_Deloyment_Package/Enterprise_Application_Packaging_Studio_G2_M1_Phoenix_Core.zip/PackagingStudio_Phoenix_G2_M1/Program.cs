using PackagingStudio.Phoenix.Core.Services;

var builder = WebApplication.CreateBuilder(args);
builder.WebHost.UseUrls("http://127.0.0.1:5188");
builder.Services.AddSingleton<RulePackService>();
builder.Services.AddSingleton<RecognitionService>();

var app = builder.Build();
app.UseDefaultFiles();
app.UseStaticFiles();

app.MapGet("/api/health", () => Results.Ok(new { status = "ready", release = "G2-M1 Phoenix Core" }));
app.MapGet("/api/rules", (RulePackService rules) => Results.Ok(rules.GetRulePackSummary()));
app.MapPost("/api/analyze", async (AnalyzeRequest request, RecognitionService recognition, CancellationToken ct) =>
{
    if (string.IsNullOrWhiteSpace(request.Path))
        return Results.BadRequest(new { error = "Installer path is required." });

    var result = await recognition.AnalyzeAsync(request.Path.Trim().Trim('"'), ct);
    return result.Success ? Results.Ok(result) : Results.BadRequest(result);
});

app.MapFallbackToFile("index.html");
app.Run();

public sealed record AnalyzeRequest(string Path);
