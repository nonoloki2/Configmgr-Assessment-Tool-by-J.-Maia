﻿Set-StrictMode -Version 2.0

function Get-SafeText {
    param([object]$Value,[string]$Fallback='Unknown')
    if ($null -eq $Value) { return $Fallback }
    $text = [string]$Value
    if ([string]::IsNullOrWhiteSpace($text)) { return $Fallback }
    return $text.Trim()
}

function Get-PeArchitecture {
    param([Parameter(Mandatory=$true)][string]$Path)
    try {
        $stream = [System.IO.File]::Open($Path,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Read,[System.IO.FileShare]::ReadWrite)
        try {
            $reader = New-Object System.IO.BinaryReader($stream)
            if ($reader.ReadUInt16() -ne 0x5A4D) { return 'Unknown' }
            $stream.Position = 0x3C
            $peOffset = $reader.ReadInt32()
            if ($peOffset -lt 0 -or $peOffset -gt ($stream.Length - 6)) { return 'Unknown' }
            $stream.Position = $peOffset
            if ($reader.ReadUInt32() -ne 0x00004550) { return 'Unknown' }
            $machine = $reader.ReadUInt16()
            switch ($machine) {
                0x014c { return 'x86' }
                0x8664 { return 'x64' }
                0xAA64 { return 'ARM64' }
                default { return ('Unknown (0x{0:X4})' -f $machine) }
            }
        } finally { $stream.Dispose() }
    } catch { return 'Unknown' }
}

function Get-SignerName {
    param($Signature)
    try {
        if ($null -eq $Signature -or $null -eq $Signature.SignerCertificate) { return 'Not available' }
        $simple = $Signature.SignerCertificate.GetNameInfo([System.Security.Cryptography.X509Certificates.X509NameType]::SimpleName,$false)
        return Get-SafeText $simple 'Not available'
    } catch { return 'Not available' }
}

function Get-MsiProperties {
    param([Parameter(Mandatory=$true)][string]$Path)
    $props = [ordered]@{
        productCode    = 'Unknown'
        productName    = 'Unknown'
        productVersion = 'Unknown'
        manufacturer   = 'Unknown'
        upgradeCode    = 'Unknown'
        allUsers       = 'Unknown'
        readable       = $false
        readError      = $null
    }
    $installer = $null; $database = $null; $view = $null
    try {
        $installer = New-Object -ComObject WindowsInstaller.Installer
        # msiOpenDatabaseModeReadOnly = 0
        $database = $installer.GetType().InvokeMember('OpenDatabase','InvokeMethod',$null,$installer,@($Path,0))
        $view = $database.GetType().InvokeMember('OpenView','InvokeMethod',$null,$database,@('SELECT `Property`,`Value` FROM `Property`'))
        $null = $view.GetType().InvokeMember('Execute','InvokeMethod',$null,$view,$null)
        while ($true) {
            $record = $view.GetType().InvokeMember('Fetch','InvokeMethod',$null,$view,$null)
            if ($null -eq $record) { break }
            $name  = $record.GetType().InvokeMember('StringData','GetProperty',$null,$record,1)
            $value = $record.GetType().InvokeMember('StringData','GetProperty',$null,$record,2)
            switch ($name) {
                'ProductCode'    { $props.productCode    = $value }
                'ProductName'    { $props.productName    = $value }
                'ProductVersion' { $props.productVersion = $value }
                'Manufacturer'   { $props.manufacturer   = $value }
                'UpgradeCode'    { $props.upgradeCode    = $value }
                'ALLUSERS'       { $props.allUsers       = $value }
            }
            try { [Runtime.InteropServices.Marshal]::ReleaseComObject($record) | Out-Null } catch {}
        }
        $props.readable = $true
    } catch {
        $props.readError = $_.Exception.Message
    } finally {
        foreach ($com in @($view,$database,$installer)) {
            if ($com) { try { [Runtime.InteropServices.Marshal]::ReleaseComObject($com) | Out-Null } catch {} }
        }
    }
    return [pscustomobject]$props
}

function Get-ExeEngineSignal {
    param([Parameter(Mandatory=$true)][string]$Path)
    $maxScanBytes = 150MB
    $signal = [ordered]@{
        engine         = 'Unrecognized wrapper'
        confidence     = 'No known marker found'
        matchedMarkers = @()
    }
    try {
        $fileInfo = Get-Item -LiteralPath $Path
        if ($fileInfo.Length -gt $maxScanBytes) {
            $signal.engine = 'Not scanned'
            $signal.confidence = "File exceeds the $([int]($maxScanBytes/1MB)) MB scan limit for string-marker detection."
            return [pscustomobject]$signal
        }
        $bytes = [IO.File]::ReadAllBytes($Path)
        $text = [Text.Encoding]::Latin1.GetString($bytes)

        # Publicly documented, well-known strings/resource names embedded by each installer
        # authoring tool's runtime stub. Order matters: first match wins.
        $markerMap = [ordered]@{
            'Inno Setup'              = @('Inno Setup Setup Data','Inno Setup Messages')
            'Nullsoft (NSIS)'         = @('NullsoftInst','Nullsoft Install System')
            'WiX Burn (Bootstrapper)' = @('.wixburn','WixBundleManufacturer','WixBurn')
            'InstallShield'           = @('InstallShield','ISSetupStream')
            'Advanced Installer'      = @('Advanced Installer')
            'Squirrel'                = @('SquirrelAwareVersion','SquirrelSetup')
        }

        foreach ($engine in $markerMap.Keys) {
            $hits = @()
            foreach ($marker in $markerMap[$engine]) {
                if ($text.IndexOf($marker,[StringComparison]::OrdinalIgnoreCase) -ge 0) { $hits += $marker }
            }
            if ($hits.Count -gt 0) {
                $signal.engine = $engine
                $signal.confidence = 'Heuristic match: installer-wrapper string marker found in the binary.'
                $signal.matchedMarkers = $hits
                break
            }
        }
    } catch {
        $signal.engine = 'Unknown'
        $signal.confidence = "Scan failed: $($_.Exception.Message)"
    }
    return [pscustomobject]$signal
}

function Test-JavaInstaller {
    param([string]$Product,[string]$Publisher,[string]$FileBaseName)
    if ($Publisher -match '(?i)oracle') { return $true }
    if ($Product -match '(?i)\bjava\b') { return $true }
    if ($FileBaseName -match '(?i)^(jre|jdk)[-_ ]') { return $true }
    return $false
}

function Get-JavaUpdateNumber {
    param([string]$FileBaseName,[string]$ProductVersion)
    if ($FileBaseName -match '(?i)8u0*(\d+)') { return $Matches[1] }
    if ($ProductVersion -match '1\.8\.0_0*(\d+)') { return $Matches[1] }
    return $null
}

function Get-JavaCommandPlan {
    param([string]$Path,[string]$FileBaseName,[string]$ProductVersion)
    $quotedPath = '"' + $Path + '"'
    $update = Get-JavaUpdateNumber -FileBaseName $FileBaseName -ProductVersion $ProductVersion
    $displayNameGuess = if ($update) { "Java 8 Update $update" } else { 'Java <major> Update <NNN>' }

    $plan = [ordered]@{
        installCommand          = "$quotedPath /s INSTALL_SILENT=1 STATIC=1 AUTO_UPDATE=0 WEB_JAVA=0 WEB_ANALYTICS=0 REBOOT=0 NOSTARTMENU=1"
        installCommandNotes     = 'Oracle-documented silent switches (java.com "Installing the JRE Silently" reference). STATIC=1 skips installing the Java Update Scheduler; add INSTALLDIR="<path>" to control the target folder. IEXPLORER=0 / MOZILLA=0 apply on older builds that still register browser plug-ins.'
        silentInstallConfidence = 'Medium-High (Oracle-documented switches for this product family; the file itself is a proprietary self-extracting bootstrapper wrapping an MSI, not one of the generic wrapper engines).'
        uninstallCommand        = 'MsiExec.exe /X{<ProductCode read from registry>} /qn /norestart'
        uninstallCommandNotes   = "The Java bootstrapper's wrapped-MSI ProductCode changes on every update build, so it cannot be hard-coded from this EXE alone — read it from the registry Uninstall key at install time (DisplayName '$displayNameGuess (64-bit)' or similar), then call msiexec /X against that GUID."
        detectionMethod         = 'Registry: Add/Remove Programs entry + JavaSoft version key (dual check)'
        detectionDetails        = "1) HKLM:\SOFTWARE\JavaSoft\Java Runtime Environment\CurrentVersion (or WOW6432Node on 64-bit hosts for 32-bit JREs) should equal the installed version. 2) The Uninstall key DisplayName should read '$displayNameGuess'. Using both avoids false positives when multiple Java versions coexist side-by-side, which Java explicitly allows."
    }
    return [pscustomobject]$plan
}

function Test-MozillaInstaller {
    param([string]$Product,[string]$Publisher,[string]$FileBaseName)
    if ($Publisher -match '(?i)mozilla') { return $true }
    if ($Product -match '(?i)\bfirefox\b') { return $true }
    if ($FileBaseName -match '(?i)firefox[\s_-]*(setup|installer)') { return $true }
    return $false
}

function Get-MozillaCommandPlan {
    param([string]$Path,[string]$ProductVersion)
    $quotedPath = '"' + $Path + '"'
    $displayNameGuess = if ($ProductVersion -and $ProductVersion -ne 'Unknown') { "Mozilla Firefox $ProductVersion (x64 en-US)" } else { 'Mozilla Firefox <version> (<arch> <locale>)' }

    $plan = [ordered]@{
        installCommand          = "$quotedPath -ms"
        installCommandNotes     = 'Mozilla''s own silent switch for the stub/full EXE installer (also documented as accepting the NSIS-standard /S). Add /MaintenanceService=false, /DesktopShortcut=false or /TaskbarShortcut=false as extra switches to skip those components. For full unattended customization (default browser, telemetry, homepage, etc.) deploy a policies.json file to <InstallDir>\distribution\ after install instead.'
        silentInstallConfidence = 'Medium-High (Mozilla-documented switch for this product family; the modern installer is a custom Mozilla bootstrapper, not one of the generic third-party wrapper engines, so no generic wrapper marker is expected here).'
        uninstallCommand        = '"<InstallDir>\uninstall\helper.exe" /S'
        uninstallCommandNotes   = "Firefox writes its own uninstaller to <InstallDir>\uninstall\helper.exe (commonly `"C:\Program Files\Mozilla Firefox\uninstall\helper.exe`" on 64-bit hosts, or the (x86) path for 32-bit builds). Read the exact UninstallString from the registry Uninstall key at install time (DisplayName '$displayNameGuess' or similar) rather than hard-coding it."
        detectionMethod         = 'Registry: Add/Remove Programs entry + Mozilla version key (dual check)'
        detectionDetails        = "1) HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Mozilla Firefox <version> (<arch> <locale>) (or the WOW6432Node path on 64-bit hosts for 32-bit builds) should exist with a matching DisplayName. 2) HKLM:\SOFTWARE\Mozilla\Mozilla Firefox\CurrentVersion should equal the installed version. Firefox's stub/full EXE does not expose a stable MSI ProductCode, so the DisplayName/version pair is the standard way to detect it."
    }
    return [pscustomobject]$plan
}

function Get-InstallerCommandPlan {
    param(
        [Parameter(Mandatory=$true)][string]$Extension,
        [Parameter(Mandatory=$true)][string]$Path,
        [pscustomobject]$MsiProperties,
        [pscustomobject]$ExeSignal,
        [bool]$IsJavaInstaller,
        [bool]$IsMozillaInstaller,
        [string]$FileBaseName,
        [string]$ProductVersion
    )
    $plan = [ordered]@{
        installCommand          = 'Unknown'
        installCommandNotes     = ''
        silentInstallConfidence = 'Low'
        uninstallCommand        = 'Unknown'
        uninstallCommandNotes   = ''
        detectionMethod         = 'Unknown'
        detectionDetails        = ''
    }
    $quotedPath = '"' + $Path + '"'

    if ($Extension -eq '.msi') {
        $plan.installCommand = "msiexec.exe /i $quotedPath /qn /norestart"
        $plan.installCommandNotes = 'Standard Windows Installer switches. Add /l*v "install.log" for a verbose log, or REBOOT=ReallySuppress if the package still prompts.'
        $plan.silentInstallConfidence = 'High (standard MSI switches; every MSI honors /qn).'
        if ($MsiProperties -and $MsiProperties.readable -and $MsiProperties.productCode -ne 'Unknown') {
            $plan.uninstallCommand = "msiexec.exe /x $($MsiProperties.productCode) /qn /norestart"
            $plan.uninstallCommandNotes = 'ProductCode read directly from the MSI Property table, so this uninstall command is exact.'
            $plan.detectionMethod = 'MSI Product Code'
            $plan.detectionDetails = "Registry: HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\$($MsiProperties.productCode) (or the WOW6432Node path on 64-bit systems) will exist once installed."
        } else {
            $reason = if ($MsiProperties -and $MsiProperties.readError) { $MsiProperties.readError } else { 'the Windows Installer COM service is unavailable on this host (this recognizer must run on Windows).' }
            $plan.uninstallCommand = 'Unknown'
            $plan.uninstallCommandNotes = "Could not read the ProductCode from the MSI database: $reason"
            $plan.detectionMethod = 'MSI Product Code (unread)'
            $plan.detectionDetails = 'Re-run recognition on a Windows host with the Windows Installer service available to extract the ProductCode automatically.'
        }
        return [pscustomobject]$plan
    }

    # .exe
    if ($IsJavaInstaller) {
        return Get-JavaCommandPlan -Path $Path -FileBaseName $FileBaseName -ProductVersion $ProductVersion
    }
    if ($IsMozillaInstaller) {
        return Get-MozillaCommandPlan -Path $Path -ProductVersion $ProductVersion
    }
    $engine = if ($ExeSignal) { $ExeSignal.engine } else { 'Unrecognized wrapper' }
    switch ($engine) {
        'Inno Setup' {
            $plan.installCommand = "$quotedPath /VERYSILENT /SUPPRESSMSGBOXES /NORESTART /SP-"
            $plan.installCommandNotes = 'Standard Inno Setup silent switches. Add /LOG="install.log" for logging.'
            $plan.silentInstallConfidence = 'Medium (installer-wrapper string marker matched).'
            $plan.uninstallCommand = '<InstallDir>\unins000.exe /VERYSILENT /NORESTART'
            $plan.uninstallCommandNotes = 'The exact uninstaller filename/path is only known after installation.'
            $plan.detectionMethod = 'Registry Uninstall key (by DisplayName)'
            $plan.detectionDetails = 'Inno Setup registers under HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\<AppId>_is1.'
        }
        'Nullsoft (NSIS)' {
            $plan.installCommand = "$quotedPath /S"
            $plan.installCommandNotes = 'Standard NSIS silent switch. Some NSIS builds also accept /D=<install dir> as the last, unquoted argument.'
            $plan.silentInstallConfidence = 'Medium (installer-wrapper string marker matched).'
            $plan.uninstallCommand = '<InstallDir>\Uninstall.exe /S'
            $plan.uninstallCommandNotes = 'Confirm the uninstaller path after installation; NSIS naming varies per package.'
            $plan.detectionMethod = 'Registry Uninstall key (by DisplayName)'
            $plan.detectionDetails = 'Check HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall for a matching DisplayName once installed.'
        }
        'WiX Burn (Bootstrapper)' {
            $plan.installCommand = "$quotedPath /quiet /norestart"
            $plan.installCommandNotes = 'WiX Burn bootstrappers commonly accept /quiet or /passive. Add /log "install.log" for logging.'
            $plan.silentInstallConfidence = 'Medium (installer-wrapper string marker matched).'
            $plan.uninstallCommand = "$quotedPath /uninstall /quiet /norestart"
            $plan.uninstallCommandNotes = 'The bootstrapper exe itself usually accepts /uninstall; confirm with /?.'
            $plan.detectionMethod = 'Registry Uninstall key (by DisplayName) or bundled MSI Product Code'
            $plan.detectionDetails = 'WiX bundles usually register an Add/Remove Programs entry under HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall.'
        }
        'InstallShield' {
            $plan.installCommand = "$quotedPath /s /v`"/qn /norestart`""
            $plan.installCommandNotes = 'Works for InstallShield packages that wrap an MSI. For InstallScript-only projects, record a response file first (/r), then deploy with /s /f1"<path.iss>".'
            $plan.silentInstallConfidence = 'Medium (installer-wrapper string marker matched).'
            $plan.uninstallCommand = 'Unknown'
            $plan.uninstallCommandNotes = 'InstallShield uninstall commands vary by project type; read the UninstallString from the registry after a test install.'
            $plan.detectionMethod = 'Registry Uninstall key (by DisplayName) or embedded MSI Product Code'
            $plan.detectionDetails = 'If this package wraps an MSI, extracting it may expose a ProductCode for exact MSI-style detection.'
        }
        'Advanced Installer' {
            $plan.installCommand = "$quotedPath /qn /norestart"
            $plan.installCommandNotes = 'Advanced Installer projects are usually MSI-based even when wrapped in an EXE bootstrapper; MSI-style switches typically pass through.'
            $plan.silentInstallConfidence = 'Medium (installer-wrapper string marker matched).'
            $plan.uninstallCommand = 'Unknown'
            $plan.uninstallCommandNotes = 'Read the UninstallString from the registry after a test install.'
            $plan.detectionMethod = 'Registry Uninstall key (by DisplayName)'
            $plan.detectionDetails = 'Check HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall for a matching DisplayName once installed.'
        }
        'Squirrel' {
            $plan.installCommand = "$quotedPath --silent"
            $plan.installCommandNotes = 'Squirrel-based installers (common for Electron apps) typically accept --silent and install per-user.'
            $plan.silentInstallConfidence = 'Medium (installer-wrapper string marker matched).'
            $plan.uninstallCommand = '%LocalAppData%\<AppName>\Update.exe --uninstall'
            $plan.uninstallCommandNotes = 'Squirrel apps self-register their uninstaller under the user profile rather than a fixed Program Files path.'
            $plan.detectionMethod = 'Registry Uninstall key (by DisplayName) or folder presence in %LocalAppData%'
            $plan.detectionDetails = 'Squirrel apps commonly install per-user rather than per-machine.'
        }
        default {
            $plan.installCommand = 'Unknown'
            $plan.installCommandNotes = 'No known installer-wrapper marker was found. Try running the installer manually with /? or -h to reveal its supported switches, or inspect it with an archive tool (e.g. 7-Zip) to identify the wrapper.'
            $plan.silentInstallConfidence = 'Low (no wrapper marker recognized).'
            $plan.uninstallCommand = 'Unknown'
            $plan.uninstallCommandNotes = 'Not determinable from static recognition alone.'
            $plan.detectionMethod = 'Registry Uninstall key (by DisplayName) — best effort'
            $plan.detectionDetails = 'After a test install in a lab VM, diff the registry Uninstall key before/after to capture the exact DisplayName and UninstallString.'
        }
    }
    return [pscustomobject]$plan
}

function Get-InstallerCandidatesInFolder {
    param([Parameter(Mandatory=$true)][string]$FolderPath)
    $items = Get-ChildItem -LiteralPath $FolderPath -File -Recurse -Depth 1 -ErrorAction SilentlyContinue |
        Where-Object { $_.Extension -match '(?i)^\.(exe|msi)$' }
    $candidates = foreach ($item in $items) {
        [pscustomobject]@{
            fileName    = $item.Name
            fullPath    = $item.FullName
            extension   = $item.Extension.ToLowerInvariant()
            sizeBytes   = [Int64]$item.Length
            sizeDisplay = ('{0:N2} MB' -f ($item.Length / 1MB))
            modifiedUtc = $item.LastWriteTimeUtc.ToString('o')
        }
    }
    return @($candidates | Sort-Object -Property sizeBytes -Descending)
}

function Invoke-InstallerRecognition {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Path)

    $stage = 'Input validation'
    try {
        $cleanPath = [Environment]::ExpandEnvironmentVariables((Get-SafeText $Path '').Trim('"'))
        if ([string]::IsNullOrWhiteSpace($cleanPath)) { throw 'Installer path is empty.' }

        if (Test-Path -LiteralPath $cleanPath -PathType Container) {
            $stage = 'Folder scan'
            $folderFullPath = (Get-Item -LiteralPath $cleanPath -ErrorAction Stop).FullName
            $candidates = @(Get-InstallerCandidatesInFolder -FolderPath $folderFullPath)
            if ($candidates.Count -eq 0) {
                throw "No .exe or .msi installer was found in folder: $folderFullPath"
            }
            if ($candidates.Count -eq 1) {
                $cleanPath = $candidates[0].fullPath
            } else {
                return [pscustomobject]@{
                    success        = $true
                    needsSelection = $true
                    path           = $folderFullPath
                    folder         = $folderFullPath
                    message        = "Found $($candidates.Count) installer candidates in this folder. Choose one to analyze."
                    candidates     = $candidates
                }
            }
        }

        if (-not (Test-Path -LiteralPath $cleanPath -PathType Leaf)) { throw "Installer not found: $cleanPath" }

        $file = Get-Item -LiteralPath $cleanPath -ErrorAction Stop
        $extension = $file.Extension.ToLowerInvariant()
        if ($extension -ne '.exe' -and $extension -ne '.msi') { throw 'This milestone supports only EXE and MSI files.' }

        $stage = 'File metadata collection'
        $versionInfo = $file.VersionInfo
        $publisher = Get-SafeText $versionInfo.CompanyName 'Unknown publisher'
        $product = Get-SafeText $versionInfo.ProductName (Get-SafeText $versionInfo.FileDescription $file.BaseName)
        $productVersion = Get-SafeText $versionInfo.ProductVersion (Get-SafeText $versionInfo.FileVersion 'Unknown')
        $fileVersion = Get-SafeText $versionInfo.FileVersion 'Unknown'
        $description = Get-SafeText $versionInfo.FileDescription 'Unknown'
        $originalFilename = Get-SafeText $versionInfo.OriginalFilename 'Unknown'
        $language = Get-SafeText $versionInfo.Language 'Unknown'

        $stage = 'Integrity collection'
        $sha256 = (Get-FileHash -LiteralPath $cleanPath -Algorithm SHA256 -ErrorAction Stop).Hash

        $stage = 'Signature inspection'
        $signatureStatus = 'Not checked'
        $signer = 'Not available'
        try {
            $signature = Get-AuthenticodeSignature -LiteralPath $cleanPath -ErrorAction Stop
            $signatureStatus = Get-SafeText $signature.Status 'Unknown'
            $signer = Get-SignerName $signature
            if ($publisher -eq 'Unknown publisher' -and $signer -ne 'Not available') { $publisher = $signer }
        } catch {
            $signatureStatus = 'Unable to inspect'
        }

        $stage = 'Installer classification'
        $msiProps = $null
        $exeSignal = $null
        if ($extension -eq '.msi') {
            $installerType = 'Windows Installer Package (MSI)'
            $architecture = 'Database-defined / not evaluated in this milestone'
        } else {
            $installerType = 'Windows Executable Installer (EXE)'
            $architecture = Get-PeArchitecture -Path $cleanPath
        }

        $stage = 'Command discovery'
        $isJavaInstaller = $false
        $isMozillaInstaller = $false
        if ($extension -eq '.msi') {
            $msiProps = Get-MsiProperties -Path $cleanPath
        } else {
            $exeSignal = Get-ExeEngineSignal -Path $cleanPath
            $isJavaInstaller = Test-JavaInstaller -Product $product -Publisher $publisher -FileBaseName $file.BaseName
            $isMozillaInstaller = Test-MozillaInstaller -Product $product -Publisher $publisher -FileBaseName $file.BaseName
        }
        $commandPlan = Get-InstallerCommandPlan -Extension $extension -Path $cleanPath -MsiProperties $msiProps -ExeSignal $exeSignal -IsJavaInstaller $isJavaInstaller -IsMozillaInstaller $isMozillaInstaller -FileBaseName $file.BaseName -ProductVersion $productVersion

        $result = [ordered]@{}
        $result.success = $true
        $result.path = $file.FullName
        $result.fileName = $file.Name
        $result.extension = $extension
        $result.sizeBytes = [Int64]$file.Length
        $result.sizeDisplay = ('{0:N2} MB' -f ($file.Length / 1MB))
        $result.createdUtc = $file.CreationTimeUtc.ToString('o')
        $result.modifiedUtc = $file.LastWriteTimeUtc.ToString('o')
        $result.publisher = $publisher
        $result.product = $product
        $result.productVersion = $productVersion
        $result.fileVersion = $fileVersion
        $result.description = $description
        $result.originalFilename = $originalFilename
        $result.language = $language
        $result.architecture = $architecture
        $result.installerType = $installerType
        $result.signatureStatus = $signatureStatus
        $result.signer = $signer
        $result.sha256 = $sha256

        if ($msiProps) {
            $result.productCode    = $msiProps.productCode
            $result.upgradeCode    = $msiProps.upgradeCode
            $result.msiManufacturer = $msiProps.manufacturer
            $result.msiAllUsers    = $msiProps.allUsers
        }
        if ($exeSignal) {
            if ($isJavaInstaller) {
                $result.detectedEngine            = 'Java / Oracle installer (proprietary bootstrapper wrapping an MSI)'
                $result.engineDetectionConfidence = 'Detected from publisher/product name and file name pattern, not a generic wrapper marker.'
                $result.matchedMarkers            = 'product-specific: Java'
            } elseif ($isMozillaInstaller) {
                $result.detectedEngine            = 'Mozilla installer (custom bootstrapper, NSIS-derived silent switches)'
                $result.engineDetectionConfidence = 'Detected from publisher/product name and file name pattern, not a generic wrapper marker.'
                $result.matchedMarkers            = 'product-specific: Mozilla Firefox'
            } else {
                $result.detectedEngine            = $exeSignal.engine
                $result.engineDetectionConfidence = $exeSignal.confidence
                $result.matchedMarkers            = ($exeSignal.matchedMarkers -join ', ')
            }
        }
        $result.installCommand          = $commandPlan.installCommand
        $result.installCommandNotes     = $commandPlan.installCommandNotes
        $result.silentInstallConfidence = $commandPlan.silentInstallConfidence
        $result.uninstallCommand        = $commandPlan.uninstallCommand
        $result.uninstallCommandNotes   = $commandPlan.uninstallCommandNotes
        $result.detectionMethod         = $commandPlan.detectionMethod
        $result.detectionDetails        = $commandPlan.detectionDetails

        $result.scope = 'Recognition + heuristic command discovery. MSI install/uninstall commands and detection are derived directly from the MSI Property table (exact). EXE install/uninstall commands are inferred from installer-wrapper string markers (Inno Setup, NSIS, InstallShield, WiX Burn, Advanced Installer, Squirrel) or, for Oracle Java and Mozilla Firefox installers, from product-specific logic. All EXE-derived guidance is heuristic — verify on a test machine before production deployment.'
        return [pscustomobject]$result
    }
    catch {
        $exception = $_.Exception
        $detail = [ordered]@{}
        $detail.stage = $stage
        $detail.engine = 'RecognitionEngine'
        $detail.function = 'Invoke-InstallerRecognition'
        $detail.exceptionType = $exception.GetType().FullName
        $detail.message = $exception.Message
        $detail.scriptLine = $_.InvocationInfo.ScriptLineNumber
        $detail.positionMessage = $_.InvocationInfo.PositionMessage
        $wrapped = New-Object System.Exception("Recognition failed during '$stage': $($exception.Message)",$exception)
        $wrapped.Data['RecognitionError'] = ($detail | ConvertTo-Json -Depth 4 -Compress)
        throw $wrapped
    }
}

Export-ModuleMember -Function Invoke-InstallerRecognition, Get-MsiProperties, Get-ExeEngineSignal, Get-InstallerCommandPlan, Test-JavaInstaller, Get-JavaCommandPlan, Test-MozillaInstaller, Get-MozillaCommandPlan, Get-InstallerCandidatesInFolder
