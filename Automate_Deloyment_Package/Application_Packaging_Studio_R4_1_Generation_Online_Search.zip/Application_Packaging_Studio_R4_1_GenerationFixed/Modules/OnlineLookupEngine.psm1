Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# Community reference used for the "Find Online" fallback when local (offline) recognition
# finds nothing. This module never invents data: it only surfaces text that was literally
# present on the fetched page, verbatim, alongside a link back to the source article so the
# packaging engineer can verify it before using it.
$script:SilentInstallHqBase   = 'https://silentinstallhq.com'
$script:SilentInstallHqUserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) ApplicationPackagingStudio/4.1 (+silent-install-lookup)'

function Set-TlsForWebRequests {
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls11
    } catch {
        # Older .NET on some hosts may not expose Tls11/Tls12 flags; ignore and use host default.
    }
}

function ConvertTo-PlainTextFromHtml {
    param([Parameter(Mandatory=$true)][string]$Html)
    $t = $Html
    $t = $t -replace '(?is)<script.*?</script>', ''
    $t = $t -replace '(?is)<style.*?</style>', ''
    $t = $t -replace '(?i)<br\s*/?>', "`n"
    # Close a table row / block element with a newline so "Label: value" pairs that live in one
    # <tr> stay on a single line, while distinct rows/blocks land on separate lines.
    $t = $t -replace '(?i)</(tr|p|div|li|h[1-6])>', "`n"
    $t = $t -replace '<[^>]+>', ' '
    $t = [System.Net.WebUtility]::HtmlDecode($t)
    $t = $t -replace '[ \t]+', ' '
    $lines = ($t -split "`n") | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' }
    return ($lines -join "`n")
}

function Invoke-SilentInstallHqSearch {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Query,
        [int]$MaxResults = 5
    )
    if ([string]::IsNullOrWhiteSpace($Query)) { return @() }
    Set-TlsForWebRequests
    $endpoint = "$script:SilentInstallHqBase/wp-json/wp/v2/search?search=" + [Uri]::EscapeDataString($Query) + "&per_page=$MaxResults&subtype=post"
    $raw = Invoke-RestMethod -Uri $endpoint -Method Get -TimeoutSec 15 -Headers @{ 'User-Agent' = $script:SilentInstallHqUserAgent } -UseBasicParsing
    $items = @($raw | Where-Object { $_.url -match [regex]::Escape($script:SilentInstallHqBase) })
    $results = foreach ($item in $items) {
        [pscustomobject]@{
            title = [System.Net.WebUtility]::HtmlDecode([string]$item.title)
            url   = [string]$item.url
        }
    }
    return @($results)
}

function Get-SilentInstallHqPageContent {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Url)
    Set-TlsForWebRequests
    $response = Invoke-WebRequest -Uri $Url -Method Get -TimeoutSec 20 -Headers @{ 'User-Agent' = $script:SilentInstallHqUserAgent } -UseBasicParsing
    return [string]$response.Content
}

function Get-SilentInstallHqCommandsFromHtml {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Html,
        [Parameter(Mandatory=$true)][string]$Url
    )
    $plain = ConvertTo-PlainTextFromHtml -Html $Html

    $installCandidates = @(
        [regex]::Matches($plain, '(?im)^\s*Silent Install Switch:?\s*(.+)$') |
            ForEach-Object { $_.Groups[1].Value.Trim(' ', '`', '*') } |
            Where-Object { $_ } |
            Select-Object -Unique
    )
    $uninstallCandidates = @(
        [regex]::Matches($plain, '(?im)^\s*Silent Uninstall Switch:?\s*(.+)$') |
            ForEach-Object { $_.Groups[1].Value.Trim(' ', '`', '*') } |
            Where-Object { $_ } |
            Select-Object -Unique
    )

    $titleMatch = [regex]::Match($Html, '(?is)<title>(.*?)</title>')
    $pageTitle = if ($titleMatch.Success) {
        ([System.Net.WebUtility]::HtmlDecode($titleMatch.Groups[1].Value) -replace '\s*-\s*SILENT INSTALL HQ\s*$', '').Trim()
    } else { $Url }

    return [pscustomobject]@{
        url                 = $Url
        title               = $pageTitle
        installCandidates   = $installCandidates
        uninstallCandidates = $uninstallCandidates
        found               = (($installCandidates.Count -gt 0) -or ($uninstallCandidates.Count -gt 0))
    }
}

function Invoke-SilentInstallHqLookup {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$ProductQuery,
        [int]$MaxCandidatePages = 3
    )
    $stage = 'Search'
    try {
        $cleanQuery = $ProductQuery.Trim()
        if ([string]::IsNullOrWhiteSpace($cleanQuery)) { throw 'No product name or file name was available to search with.' }

        $searchResults = @(Invoke-SilentInstallHqSearch -Query $cleanQuery -MaxResults 5)
        if ($searchResults.Count -eq 0) {
            return [pscustomobject]@{
                success = $true
                found   = $false
                query   = $cleanQuery
                message = "No matching pages were found on Silent Install HQ for '$cleanQuery'."
                results = @()
            }
        }

        $stage = 'Extract'
        $picked = @()
        foreach ($candidate in ($searchResults | Select-Object -First $MaxCandidatePages)) {
            try {
                $html = Get-SilentInstallHqPageContent -Url $candidate.url
                $extracted = Get-SilentInstallHqCommandsFromHtml -Html $html -Url $candidate.url
                if ($extracted.found) { $picked += $extracted }
            } catch {
                # A single page failing to fetch/parse should not abort the whole lookup —
                # skip it and keep trying the remaining candidates.
                continue
            }
        }

        if ($picked.Count -eq 0) {
            return [pscustomobject]@{
                success = $true
                found   = $false
                query   = $cleanQuery
                message = "Found matching pages on Silent Install HQ for '$cleanQuery', but could not automatically extract a command from them."
                results = @($searchResults | Select-Object -First $MaxCandidatePages)
            }
        }

        return [pscustomobject]@{
            success = $true
            found   = $true
            query   = $cleanQuery
            results = $picked
        }
    }
    catch {
        $exception = $_.Exception
        $detail = [ordered]@{
            stage         = $stage
            engine        = 'OnlineLookupEngine'
            function      = 'Invoke-SilentInstallHqLookup'
            exceptionType = $exception.GetType().FullName
            message       = $exception.Message
            scriptLine    = $_.InvocationInfo.ScriptLineNumber
            positionMessage = $_.InvocationInfo.PositionMessage
        }
        $wrapped = New-Object System.Exception("Online lookup failed during '$stage': $($exception.Message)", $exception)
        $wrapped.Data['RecognitionError'] = ($detail | ConvertTo-Json -Depth 4 -Compress)
        throw $wrapped
    }
}

Export-ModuleMember -Function Invoke-SilentInstallHqLookup, Invoke-SilentInstallHqSearch, Get-SilentInstallHqPageContent, Get-SilentInstallHqCommandsFromHtml, ConvertTo-PlainTextFromHtml
