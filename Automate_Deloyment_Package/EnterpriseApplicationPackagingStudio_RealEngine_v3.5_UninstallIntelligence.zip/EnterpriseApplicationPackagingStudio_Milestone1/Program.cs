using System.Text.Json;
using EnterpriseApplicationPackagingStudio.Data;
using EnterpriseApplicationPackagingStudio.Hubs;
using EnterpriseApplicationPackagingStudio.Models;
using EnterpriseApplicationPackagingStudio.Services;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<AppDbContext>(options => options.UseSqlite(builder.Configuration.GetConnectionString("Default")));
builder.Services.AddSignalR();
builder.Services.AddProblemDetails();
builder.Services.AddSingleton<PackagingEngine>();
builder.Services.AddSingleton<AnalysisJobService>();
var app = builder.Build();
app.UseExceptionHandler(); app.UseDefaultFiles(); app.UseStaticFiles();

await using (var scope = app.Services.CreateAsyncScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    var versionFile = Path.Combine(app.Environment.ContentRootPath, ".schema-version");
    const string schemaVersion = "3";
    if (File.Exists(Path.Combine(app.Environment.ContentRootPath, "Data", "packaging-studio.db")) && (!File.Exists(versionFile) || File.ReadAllText(versionFile).Trim() != schemaVersion))
    {
        var dbPath = Path.Combine(app.Environment.ContentRootPath, "Data", "packaging-studio.db");
        if (File.Exists(dbPath)) File.Copy(dbPath, dbPath + ".milestone1.bak", true);
        await db.Database.EnsureDeletedAsync();
    }
    await db.Database.EnsureCreatedAsync(); File.WriteAllText(versionFile, schemaVersion);
    if (!await db.ClientProfiles.AnyAsync()) { db.ClientProfiles.Add(new ClientProfile()); await db.SaveChangesAsync(); }
}

app.MapGet("/api/system", () => Results.Ok(new { platform = Environment.OSVersion.ToString(), windows = OperatingSystem.IsWindows(), elevated = IsAdministrator(), laboratoryMode = true, version = "3.5.0-uninstall-intelligence" }));
app.MapGet("/api/dashboard", async (AppDbContext db) => Results.Ok(new { total = await db.Packages.CountAsync(), ready = await db.Packages.CountAsync(x => x.Status == "Ready"), testing = await db.Packages.CountAsync(x => x.Status == "Testing"), failed = await db.Packages.CountAsync(x => x.Status == "Failed"), analyzed = await db.Packages.CountAsync(x => x.Status == "Analyzed") }));
app.MapGet("/api/clients", async (AppDbContext db) => Results.Ok(await db.ClientProfiles.OrderBy(x => x.Name).ToListAsync()));
app.MapPost("/api/clients", async (ClientProfile profile, AppDbContext db) => { profile.Id=0; profile.UpdatedAtUtc=DateTime.UtcNow; db.ClientProfiles.Add(profile); await db.SaveChangesAsync(); return Results.Created($"/api/clients/{profile.Id}", profile); });
app.MapPut("/api/clients/{id:int}", async (int id, ClientProfile input, AppDbContext db) => { var p=await db.ClientProfiles.FindAsync(id); if(p is null)return Results.NotFound(); p.Name=input.Name.Trim();p.ApplicationTitle=input.ApplicationTitle.Trim();p.Subtitle=input.Subtitle.Trim();p.PrimaryColor=input.PrimaryColor;p.SecondaryColor=input.SecondaryColor;p.AccentColor=input.AccentColor;p.Theme=input.Theme;p.ReportFooter=input.ReportFooter;p.UpdatedAtUtc=DateTime.UtcNow;await db.SaveChangesAsync();return Results.Ok(p); });
app.MapPost("/api/clients/{id:int}/logo", async (int id, IFormFile file, AppDbContext db, IWebHostEnvironment env) => { var p=await db.ClientProfiles.FindAsync(id);if(p is null)return Results.NotFound();var allowed=new HashSet<string>(StringComparer.OrdinalIgnoreCase){".png",".jpg",".jpeg",".svg",".webp"};var ext=Path.GetExtension(file.FileName);if(!allowed.Contains(ext))return Results.BadRequest(new{error="Unsupported logo format."});if(file.Length>5*1024*1024)return Results.BadRequest(new{error="Logo must be 5 MB or smaller."});var uploads=Path.Combine(env.WebRootPath,"uploads");Directory.CreateDirectory(uploads);var name=$"client-{id}-{Guid.NewGuid():N}{ext.ToLowerInvariant()}";await using var stream=File.Create(Path.Combine(uploads,name));await file.CopyToAsync(stream);p.LogoPath=$"/uploads/{name}";p.UpdatedAtUtc=DateTime.UtcNow;await db.SaveChangesAsync();return Results.Ok(new{p.LogoPath}); }).DisableAntiforgery();

app.MapGet("/api/packages", async (AppDbContext db) => Results.Ok(await db.Packages.Include(x=>x.ClientProfile).OrderByDescending(x=>x.UpdatedAtUtc).ToListAsync()));
app.MapGet("/api/packages/{id:int}", async (int id, AppDbContext db) => { var p=await db.Packages.Include(x=>x.ClientProfile).FirstOrDefaultAsync(x=>x.Id==id);return p is null?Results.NotFound():Results.Ok(p); });
app.MapPost("/api/packages", async (PackageRecord p, AppDbContext db) => { if(string.IsNullOrWhiteSpace(p.ApplicationName))return Results.BadRequest(new{error="Application name is required."});if(!await db.ClientProfiles.AnyAsync(x=>x.Id==p.ClientProfileId))return Results.BadRequest(new{error="Select a valid client profile."});p.Id=0;p.ApplicationName=p.ApplicationName.Trim();p.Status="Draft";p.InstallStatus=p.UninstallStatus=p.DetectionStatus="Pending";p.CreatedAtUtc=p.UpdatedAtUtc=DateTime.UtcNow;db.Packages.Add(p);await db.SaveChangesAsync();return Results.Created($"/api/packages/{p.Id}",p); });
app.MapPut("/api/packages/{id:int}/commands", async (int id, PackageRecord input, AppDbContext db) => { var p=await db.Packages.FindAsync(id);if(p is null)return Results.NotFound();p.SelectedInstallCommand=input.SelectedInstallCommand;p.SelectedUninstallCommand=input.SelectedUninstallCommand;p.DetectionMethod=input.DetectionMethod;p.UpdatedAtUtc=DateTime.UtcNow;await db.SaveChangesAsync();return Results.Ok(p); });
app.MapDelete("/api/packages/{id:int}", async (int id, AppDbContext db) => { var p=await db.Packages.FindAsync(id);if(p is null)return Results.NotFound();db.Packages.Remove(p);await db.SaveChangesAsync();return Results.NoContent(); });

app.MapPost("/api/packages/{id:int}/analyze", async (int id, AppDbContext db, AnalysisJobService jobs, IServiceScopeFactory scopeFactory, IHubContext<ActivityHub> hub) =>
{
    var package = await db.Packages.FindAsync(id);
    if (package is null) return Results.NotFound();
    var existing = jobs.GetLatestForPackage(id);
    if (existing is not null && existing.Status is "Queued" or "Running" or "Cancelling")
        return Results.Conflict(new { error = "An analysis job is already running for this package.", jobId = existing.Id });

    var job = jobs.Create(id);
    package.Status = "Queued";
    package.UpdatedAtUtc = DateTime.UtcNow;
    await db.SaveChangesAsync();

    _ = Task.Run(async () =>
    {
        job.Status = "Running"; job.StartedAtUtc = DateTime.UtcNow;
        await hub.Clients.All.SendAsync("activity", new { packageId = id, jobId = job.Id, message = "Real installer analysis worker started", level = "info" });
        try
        {
            await using var scope = scopeFactory.CreateAsyncScope();
            var scopedDb = scope.ServiceProvider.GetRequiredService<AppDbContext>();
            var engine = scope.ServiceProvider.GetRequiredService<PackagingEngine>();
            var current = await scopedDb.Packages.FindAsync(id) ?? throw new InvalidOperationException("Package no longer exists.");
            var reporter = new Progress<AnalysisProgress>(progress =>
            {
                job.CurrentStep = progress.Step; job.TotalSteps = progress.TotalSteps; job.Progress = progress.Percent;
                job.CurrentOperation = progress.Operation;
                lock (job.Events) job.Events.Add(new AnalysisJobEvent(DateTime.UtcNow, progress.Level, progress.Operation, progress.Message, progress.Percent));
                _ = hub.Clients.All.SendAsync("analysisProgress", new { packageId = id, jobId = job.Id, progress.Step, progress.TotalSteps, progress.Percent, progress.Operation, progress.Message, progress.Level });
            });
            var analysis = await engine.AnalyzeAsync(current, reporter, job.Cancellation.Token);
            current.InstallerType=analysis.InstallerType; current.Confidence=analysis.Confidence; current.Architecture=analysis.Architecture;
            current.Vendor=analysis.Vendor; current.Version=analysis.Version; current.Sha256=analysis.Files.FirstOrDefault(x=>x.FullPath==analysis.PrimaryInstaller)?.Sha256;
            current.SignatureStatus=analysis.Files.FirstOrDefault(x=>x.FullPath==analysis.PrimaryInstaller)?.SignatureStatus;
            current.Signer=analysis.Files.FirstOrDefault(x=>x.FullPath==analysis.PrimaryInstaller)?.Signer; current.ProductCode=analysis.ProductCode;
            current.UpgradeCode=analysis.UpgradeCode; current.AnalysisJson=JsonSerializer.Serialize(analysis, new JsonSerializerOptions(JsonSerializerDefaults.Web)); current.Status="Analyzed"; current.UpdatedAtUtc=DateTime.UtcNow;
            await scopedDb.SaveChangesAsync();
            job.Status="Completed"; job.Progress=100; job.CurrentOperation="Analysis complete"; job.CompletedAtUtc=DateTime.UtcNow;
            await hub.Clients.All.SendAsync("activity",new{packageId=id,jobId=job.Id,message=$"Analysis complete: {analysis.InstallerType} ({analysis.Confidence}%)",level="success"});
        }
        catch (OperationCanceledException)
        {
            job.Status="Cancelled"; job.Error="Analysis cancelled by operator."; job.CompletedAtUtc=DateTime.UtcNow;
            await using var scope = scopeFactory.CreateAsyncScope(); var scopedDb=scope.ServiceProvider.GetRequiredService<AppDbContext>(); var current=await scopedDb.Packages.FindAsync(id);
            if(current is not null){current.Status="Draft";current.UpdatedAtUtc=DateTime.UtcNow;await scopedDb.SaveChangesAsync();}
        }
        catch(Exception ex)
        {
            job.Status="Failed"; job.Error=ex.Message; job.CurrentOperation="Analysis failed"; job.CompletedAtUtc=DateTime.UtcNow;
            lock(job.Events) job.Events.Add(new AnalysisJobEvent(DateTime.UtcNow,"error","Analysis failed",ex.ToString(),job.Progress));
            await using var scope = scopeFactory.CreateAsyncScope(); var scopedDb=scope.ServiceProvider.GetRequiredService<AppDbContext>(); var current=await scopedDb.Packages.FindAsync(id);
            if(current is not null){current.Status="Failed";current.UpdatedAtUtc=DateTime.UtcNow;await scopedDb.SaveChangesAsync();}
            await hub.Clients.All.SendAsync("activity",new{packageId=id,jobId=job.Id,message=ex.Message,level="error"});
        }
    });
    return Results.Accepted($"/api/analysis-jobs/{job.Id}", new { jobId=job.Id, status=job.Status });
});
app.MapGet("/api/analysis-jobs/{jobId}", (string jobId, AnalysisJobService jobs) =>
{
    var job=jobs.Get(jobId); if(job is null)return Results.NotFound();
    List<AnalysisJobEvent> events; lock(job.Events) events=[..job.Events];
    return Results.Ok(new{job.Id,job.PackageId,job.Status,job.Progress,job.CurrentStep,job.TotalSteps,job.CurrentOperation,job.Error,job.CreatedAtUtc,job.StartedAtUtc,job.CompletedAtUtc,events});
});
app.MapGet("/api/packages/{id:int}/analysis-job", (int id, AnalysisJobService jobs) =>
{
    var job=jobs.GetLatestForPackage(id); if(job is null)return Results.NotFound();
    List<AnalysisJobEvent> events; lock(job.Events) events=[..job.Events];
    return Results.Ok(new{job.Id,job.PackageId,job.Status,job.Progress,job.CurrentStep,job.TotalSteps,job.CurrentOperation,job.Error,job.CreatedAtUtc,job.StartedAtUtc,job.CompletedAtUtc,events});
});
app.MapPost("/api/analysis-jobs/{jobId}/cancel", (string jobId, AnalysisJobService jobs) => jobs.Cancel(jobId)?Results.Accepted():Results.NotFound());
app.MapPost("/api/packages/{id:int}/execute", async (int id, ExecuteAttemptRequest req, PackagingEngine engine, AppDbContext db, IHubContext<ActivityHub> hub, CancellationToken ct) =>
{
    if(!req.ConfirmLabMachine)return Results.BadRequest(new{error="Laboratory machine confirmation is required."});
    if(!OperatingSystem.IsWindows())return Results.BadRequest(new{error="Execution is supported only on Windows."});
    if(!IsAdministrator())return Results.BadRequest(new{error="Restart the application as Administrator before executing installers."});
    var p=await db.Packages.FindAsync(id);if(p is null)return Results.NotFound();
    var isInstall=req.Phase.Equals("Install",StringComparison.OrdinalIgnoreCase);
    p.Status="Testing";
    if(isInstall)
    {
        p.InstallStatus="Running";
        p.DetectionStatus="Capturing baseline";
        p.BaselineJson=JsonSerializer.Serialize(engine.CaptureBaseline(),new JsonSerializerOptions(JsonSerializerDefaults.Web));
        p.DetectionDiscoveryJson=null;
    }
    else p.UninstallStatus="Running";
    await db.SaveChangesAsync();
    await hub.Clients.All.SendAsync("activity",new{packageId=id,message=$"{req.Phase} attempt started",level="warning"},ct);
    var wd=Directory.Exists(p.SourcePath)?p.SourcePath!:Path.GetDirectoryName(p.SourcePath??"")??app.Environment.ContentRootPath;
    var result=await engine.ExecuteAsync(req.Command,wd,req.Phase,req.TimeoutMinutes,ct);
    var attempts=string.IsNullOrWhiteSpace(p.AttemptsJson)?new List<AttemptResult>():JsonSerializer.Deserialize<List<AttemptResult>>(p.AttemptsJson!)??[];
    attempts.Add(result);p.AttemptsJson=JsonSerializer.Serialize(attempts);
    if(isInstall)
    {
        p.SelectedInstallCommand=req.Command;p.InstallStatus=result.Outcome;
        if(result.Outcome=="Passed" && !string.IsNullOrWhiteSpace(p.BaselineJson))
        {
            var baseline=JsonSerializer.Deserialize<SystemBaseline>(p.BaselineJson,new JsonSerializerOptions(JsonSerializerDefaults.Web));
            if(baseline is not null)
            {
                var discovery=engine.DiscoverDetection(p,baseline);
                p.DetectionDiscoveryJson=JsonSerializer.Serialize(discovery,new JsonSerializerOptions(JsonSerializerDefaults.Web));
                p.DetectionStatus=discovery.InstalledStateValidated?"Installed state validated":"Candidates found";
                if(discovery.Selected is not null)
                    p.DetectionMethod=$"Registry: {discovery.Selected.RegistryPath} [{discovery.Selected.ValueName}] >= {discovery.Selected.RequiredVersion}";

                // A successful installation creates the evidence required for reliable uninstall discovery.
                var uninstallDiscovery=engine.InvestigateUninstall(p,discovery);
                p.KnowledgeJson=JsonSerializer.Serialize(uninstallDiscovery,new JsonSerializerOptions(JsonSerializerDefaults.Web));
                if(uninstallDiscovery.Candidates.Count>0)
                {
                    var currentAnalysis=string.IsNullOrWhiteSpace(p.AnalysisJson)?null:JsonSerializer.Deserialize<PackagingAnalysis>(p.AnalysisJson,new JsonSerializerOptions(JsonSerializerDefaults.Web));
                    if(currentAnalysis is not null)
                    {
                        currentAnalysis=currentAnalysis with { UninstallCandidates=uninstallDiscovery.Candidates };
                        p.AnalysisJson=JsonSerializer.Serialize(currentAnalysis,new JsonSerializerOptions(JsonSerializerDefaults.Web));
                    }
                    p.SelectedUninstallCommand=uninstallDiscovery.Candidates[0].Command;
                    p.UninstallStatus="Ready to test";
                }
            }
        }
        else p.DetectionStatus="Waiting for successful installation";
    }
    else
    {
        p.SelectedUninstallCommand=req.Command;p.UninstallStatus=result.Outcome;
        if(result.Outcome=="Passed" && !string.IsNullOrWhiteSpace(p.DetectionDiscoveryJson))
        {
            var discovery=JsonSerializer.Deserialize<DetectionDiscovery>(p.DetectionDiscoveryJson,new JsonSerializerOptions(JsonSerializerDefaults.Web));
            if(discovery?.Selected is not null)
            {
                var absent=!engine.EvaluateDetection(discovery.Selected);
                discovery=discovery with { UninstalledStateValidated=absent };
                p.DetectionDiscoveryJson=JsonSerializer.Serialize(discovery,new JsonSerializerOptions(JsonSerializerDefaults.Web));
                p.DetectionStatus=discovery.InstalledStateValidated && absent?"Validated":"Validation failed";
            }
        }
    }
    p.Status=result.Outcome=="Passed"?(p.InstallStatus=="Passed"&&p.UninstallStatus=="Passed"&&p.DetectionStatus=="Validated"?"Ready for generation":"Testing"):"Failed";
    p.UpdatedAtUtc=DateTime.UtcNow;await db.SaveChangesAsync();
    await hub.Clients.All.SendAsync("activity",new{packageId=id,message=$"{req.Phase} completed: {result.Outcome}, exit code {result.ExitCode}",level=result.Outcome=="Passed"?"success":"error"},ct);
    return Results.Ok(new{result,p.DetectionStatus,detectionDiscovery=string.IsNullOrWhiteSpace(p.DetectionDiscoveryJson)?null:JsonSerializer.Deserialize<DetectionDiscovery>(p.DetectionDiscoveryJson,new JsonSerializerOptions(JsonSerializerDefaults.Web))});
});
app.MapPost("/api/packages/{id:int}/investigate-uninstall", async (int id, PackagingEngine engine, AppDbContext db) =>
{
    var p=await db.Packages.FindAsync(id); if(p is null)return Results.NotFound();
    if(p.InstallStatus!="Passed")return Results.BadRequest(new{error="Run a successful installation test before investigating uninstall methods."});
    var detection=string.IsNullOrWhiteSpace(p.DetectionDiscoveryJson)?null:JsonSerializer.Deserialize<DetectionDiscovery>(p.DetectionDiscoveryJson,new JsonSerializerOptions(JsonSerializerDefaults.Web));
    var discovery=engine.InvestigateUninstall(p,detection);
    p.KnowledgeJson=JsonSerializer.Serialize(discovery,new JsonSerializerOptions(JsonSerializerDefaults.Web));
    if(discovery.Candidates.Count>0)
    {
        var analysis=string.IsNullOrWhiteSpace(p.AnalysisJson)?null:JsonSerializer.Deserialize<PackagingAnalysis>(p.AnalysisJson,new JsonSerializerOptions(JsonSerializerDefaults.Web));
        if(analysis is not null)
        {
            analysis=analysis with { UninstallCandidates=discovery.Candidates };
            p.AnalysisJson=JsonSerializer.Serialize(analysis,new JsonSerializerOptions(JsonSerializerDefaults.Web));
        }
        p.SelectedUninstallCommand=discovery.Candidates[0].Command;
        p.UninstallStatus="Ready to test";
        p.Status="Testing";
    }
    else p.UninstallStatus="Investigation required";
    p.UpdatedAtUtc=DateTime.UtcNow; await db.SaveChangesAsync();
    return Results.Ok(new{discovery,p.SelectedUninstallCommand,p.UninstallStatus});
});
app.MapGet("/api/packages/{id:int}/uninstall-investigation", async (int id, AppDbContext db) =>
{
    var p=await db.Packages.FindAsync(id);if(p is null)return Results.NotFound();
    if(string.IsNullOrWhiteSpace(p.KnowledgeJson))return Results.NotFound();
    return Results.Content(p.KnowledgeJson,"application/json");
});

app.MapPost("/api/packages/{id:int}/generate", async (int id, GenerateRequest req, PackagingEngine engine, AppDbContext db) =>
{
    var p = await db.Packages.FindAsync(id);
    if (p is null) return Results.NotFound();
    if (p.InstallStatus!="Passed" || p.UninstallStatus!="Passed" || p.DetectionStatus!="Validated")
        return Results.BadRequest(new { error = "Package generation is blocked. Complete installation, detection and uninstallation validation first." });
    var discovery=string.IsNullOrWhiteSpace(p.DetectionDiscoveryJson)?null:JsonSerializer.Deserialize<DetectionDiscovery>(p.DetectionDiscoveryJson,new JsonSerializerOptions(JsonSerializerDefaults.Web));
    var selected=discovery?.Selected;
    if(selected is null)return Results.BadRequest(new{error="No validated detection method is available."});
    req = req with { DetectionType=selected.Type, DetectionPath=selected.RegistryPath ?? selected.FilePath, DetectionValue=selected.ValueName, RequiredVersion=selected.RequiredVersion ?? p.Version };
    p.DetectionMethod = $"{selected.Type}: {selected.RegistryPath ?? selected.FilePath}";
    var result = engine.GenerateArtifacts(p, req);
    p.WorkspacePath = result.OutputDirectory;
    p.Status = "Ready";
    p.UpdatedAtUtc = DateTime.UtcNow;
    await db.SaveChangesAsync();
    return Results.Ok(new { workspacePath = result.OutputDirectory, files = result.Files, status = p.Status });
});
app.MapPost("/api/packages/{id:int}/open-output", async (int id, AppDbContext db) =>
{
    if (!OperatingSystem.IsWindows()) return Results.BadRequest(new { error = "Opening the output folder is supported only on Windows." });
    var p = await db.Packages.FindAsync(id);
    if (p is null) return Results.NotFound();
    if (string.IsNullOrWhiteSpace(p.WorkspacePath) || !Directory.Exists(p.WorkspacePath))
        return Results.BadRequest(new { error = "Generate the package artifacts first." });
    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe", $"\"{p.WorkspacePath}\"") { UseShellExecute = true });
    return Results.Accepted();
});
app.MapGet("/api/packages/{id:int}/artifacts", async (int id, AppDbContext db) =>
{
    var p = await db.Packages.FindAsync(id);
    if (p is null) return Results.NotFound();
    if (string.IsNullOrWhiteSpace(p.WorkspacePath) || !Directory.Exists(p.WorkspacePath))
        return Results.BadRequest(new { error = "Generated artifact folder was not found." });
    var names = new[] { "Install.ps1", "Uninstall.ps1", "Detect-Application.ps1", "Test-Package.ps1", Path.Combine("Documentation", "SCCM-Deployment-Guide.html"), Path.Combine("Documentation", "Packaging-Validation-Report.json") };
    var files = names.Select(x => Path.Combine(p.WorkspacePath, x)).Where(File.Exists).Select(x => new { name = Path.GetFileName(x), path = x, size = new FileInfo(x).Length }).ToList();
    return Results.Ok(new { outputDirectory = p.WorkspacePath, files });
});
app.MapGet("/api/knowledge", async (AppDbContext db) => Results.Ok(await db.Packages.Where(x=>x.Status=="Ready"||x.Status=="Analyzed").Select(x=>new{x.Id,x.ApplicationName,x.Vendor,x.Version,x.InstallerType,x.SelectedInstallCommand,x.SelectedUninstallCommand,x.DetectionMethod,x.ProductCode,x.UpgradeCode}).ToListAsync()));
app.MapHub<ActivityHub>("/hubs/activity");app.MapFallbackToFile("index.html");app.Run();

static bool IsAdministrator(){if(!OperatingSystem.IsWindows())return false;try{using var identity=System.Security.Principal.WindowsIdentity.GetCurrent();var principal=new System.Security.Principal.WindowsPrincipal(identity);return principal.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);}catch{return false;}}
