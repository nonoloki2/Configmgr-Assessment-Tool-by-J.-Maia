using System.Diagnostics;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Win32;
using EnterpriseApplicationPackagingStudio.Models;

namespace EnterpriseApplicationPackagingStudio.Services;

public sealed class PackagingEngine(IWebHostEnvironment environment, ILogger<PackagingEngine> logger)
{
    private static readonly string[] RelevantExtensions = [".msi", ".msp", ".exe", ".msix", ".msixbundle", ".appx", ".appxbundle", ".cab", ".mst", ".xml", ".ini", ".json", ".config", ".ps1", ".cmd", ".bat", ".vbs"];

    public async Task<PackagingAnalysis> AnalyzeAsync(PackageRecord package, IProgress<AnalysisProgress>? progress, CancellationToken cancellationToken)
    {
        void Report(int step, int percent, string operation, string message, string level = "info") => progress?.Report(new AnalysisProgress(step, 9, percent, operation, message, level));
        Report(1, 3, "Resolving source", "Validating the selected installer path.");
        var source = ResolveSource(package.SourcePath);
        Report(1, 7, "Enumerating source", "Searching for supported installer and configuration files.");
        var files = Directory.Exists(source)
            ? Directory.EnumerateFiles(source, "*", SearchOption.AllDirectories).Where(x => RelevantExtensions.Contains(Path.GetExtension(x), StringComparer.OrdinalIgnoreCase)).Take(500).ToList()
            : File.Exists(source) ? [source] : throw new DirectoryNotFoundException($"Source path not found: {source}");
        Report(1, 10, "Source discovered", $"Found {files.Count} supported source file(s).");
        if (files.Count == 0) throw new InvalidOperationException("No supported installer files were found in the selected source path.");

        Report(2, 12, "Reading file evidence", "Starting metadata and SHA-256 collection.");
        var evidence = new List<FileEvidence>();
        var fileIndex = 0;
        foreach (var file in files)
        {
            cancellationToken.ThrowIfCancellationRequested();
            fileIndex++;
            Report(2, 12 + (int)(28.0 * fileIndex / Math.Max(files.Count,1)), "Calculating SHA-256", $"Processing {Path.GetFileName(file)} ({fileIndex}/{files.Count}).");
            evidence.Add(await ReadEvidenceAsync(file, cancellationToken));
        }
        Report(3, 42, "Selecting primary installer", "Ranking installer files by type and size.");
        var primary = SelectPrimaryInstaller(evidence);
        Report(4, 50, "Detecting installer technology", $"Inspecting {primary.Name} for known installer signatures.");
        var type = DetectInstallerType(primary.FullPath, primary.Extension);
        var confidence = type == "Unknown" ? 45 : primary.Extension.Equals(".msi", StringComparison.OrdinalIgnoreCase) ? 100 : 88;
        Report(5, 60, "Reading product metadata", "Resolving vendor, version and architecture.");
        var architecture = DetectArchitecture(primary.Name, package.Architecture);
        var vendor = string.IsNullOrWhiteSpace(primary.Company) ? package.Vendor ?? "Unknown vendor" : primary.Company!;
        var version = primary.ProductVersion ?? primary.FileVersion ?? package.Version ?? "Unknown";
        Report(6, 68, "Reading installer database", primary.Extension.Equals(".msi", StringComparison.OrdinalIgnoreCase) ? "Reading MSI Property table." : "MSI database step not required for this installer type.");
        var (productCode, upgradeCode) = primary.Extension.Equals(".msi", StringComparison.OrdinalIgnoreCase) && OperatingSystem.IsWindows()
            ? await ReadMsiPropertiesAsync(primary.FullPath, cancellationToken) : (null, null);
        Report(7, 78, "Building command candidates", "Generating evidence-based silent install and uninstall commands.");
        var install = BuildInstallCandidates(type, primary.FullPath);
        var uninstall = BuildUninstallCandidates(type, primary.FullPath, productCode);
        Report(8, 88, "Building detection candidates", "Ranking MSI, registry and file detection strategies.");
        var detection = BuildDetectionCandidates(primary, productCode, vendor, package.ApplicationName, version);
        var findings = new List<string>
        {
            $"Primary installer selected: {primary.Name}",
            $"Installer technology: {type} ({confidence}% confidence)",
            $"Digital signature: {primary.SignatureStatus}",
            $"{evidence.Count} relevant source file(s) analyzed"
        };
        if (evidence.Any(x => x.Extension.Equals(".mst", StringComparison.OrdinalIgnoreCase))) findings.Add("MST transform detected in source folder.");
        if (evidence.Any(x => x.Extension.Equals(".msp", StringComparison.OrdinalIgnoreCase))) findings.Add("MSP patch detected in source folder.");
        Report(9, 100, "Analysis complete", $"Identified {type} with {confidence}% confidence.", "success");
        return new PackagingAnalysis(type, confidence, primary.FullPath, architecture, vendor, version, productCode, upgradeCode, evidence, install, uninstall, detection, findings, DateTime.UtcNow);
    }

    public async Task<AttemptResult> ExecuteAsync(string command, string workingDirectory, string phase, int timeoutMinutes, CancellationToken cancellationToken)
    {
        if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException("Controlled installer execution is available only on Windows.");
        if (string.IsNullOrWhiteSpace(command)) throw new ArgumentException("Command is required.");
        var started = DateTime.UtcNow;
        var sw = Stopwatch.StartNew();
        var (executable, arguments) = SplitCommandLine(command);
        executable = Environment.ExpandEnvironmentVariables(executable);
        arguments = Environment.ExpandEnvironmentVariables(arguments);

        var psi = new ProcessStartInfo(executable, arguments)
        {
            WorkingDirectory = Directory.Exists(workingDirectory) ? workingDirectory : environment.ContentRootPath,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };
        using var process = new Process { StartInfo = psi, EnableRaisingEvents = true };
        try
        {
            if (!process.Start())
                return new AttemptResult(phase, command, -2, false, sw.Elapsed.TotalSeconds, string.Empty, "Windows did not start the installer process.", started, "Failed");
        }
        catch (Exception ex)
        {
            sw.Stop();
            return new AttemptResult(phase, command, -2, false, sw.Elapsed.TotalSeconds, string.Empty,
                $"Unable to start '{executable}'. {ex.GetType().Name}: {ex.Message}", started, "Failed");
        }
        var stdoutTask = process.StandardOutput.ReadToEndAsync(cancellationToken);
        var stderrTask = process.StandardError.ReadToEndAsync(cancellationToken);
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeout.CancelAfter(TimeSpan.FromMinutes(Math.Clamp(timeoutMinutes, 1, 120)));
        var timedOut = false;
        try { await process.WaitForExitAsync(timeout.Token); }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            timedOut = true;
            try { process.Kill(true); } catch (Exception ex) { logger.LogWarning(ex, "Unable to terminate timed-out process tree"); }
        }
        var stdout = await stdoutTask;
        var stderr = await stderrTask;
        sw.Stop();
        var exitCode = timedOut ? -1 : process.ExitCode;
        var outcome = timedOut ? "Timed Out" : exitCode is 0 or 3010 or 1641 ? "Passed" : "Failed";
        return new AttemptResult(phase, command, exitCode, timedOut, sw.Elapsed.TotalSeconds, Trim(stdout), Trim(stderr), started, outcome);
    }


    private static (string Executable, string Arguments) SplitCommandLine(string command)
    {
        var value = command.Trim();
        if (value.Length == 0) throw new ArgumentException("Command is empty.");

        if (value[0] == '"')
        {
            var closingQuote = value.IndexOf('"', 1);
            if (closingQuote < 0) throw new ArgumentException("The executable path has an unmatched quote.");
            var executable = value[1..closingQuote];
            var arguments = value[(closingQuote + 1)..].TrimStart();
            return (executable, arguments);
        }

        var separator = value.IndexOfAny([' ', '\t']);
        return separator < 0 ? (value, string.Empty) : (value[..separator], value[(separator + 1)..].TrimStart());
    }

    public ArtifactGenerationResult GenerateArtifacts(PackageRecord package, GenerateRequest request)
    {
        var sourceRoot = Directory.Exists(package.SourcePath)
            ? Path.GetFullPath(package.SourcePath!)
            : Path.GetDirectoryName(Path.GetFullPath(package.SourcePath ?? string.Empty));

        if (string.IsNullOrWhiteSpace(sourceRoot) || !Directory.Exists(sourceRoot))
            throw new DirectoryNotFoundException("The package source folder could not be resolved.");

        // Default behavior: write SCCM scripts directly beside the installer/source files.
        // An explicit output directory may still be supplied by the operator.
        var root = string.IsNullOrWhiteSpace(request.OutputDirectory)
            ? sourceRoot
            : Path.GetFullPath(Environment.ExpandEnvironmentVariables(request.OutputDirectory));

        Directory.CreateDirectory(root);
        var docs = Path.Combine(root, "Documentation");
        var logs = Path.Combine(root, "Logs");
        Directory.CreateDirectory(docs);
        Directory.CreateDirectory(logs);

        var generated = new List<string>
        {
            WriteArtifact(root, "Install.ps1", PowerShellTemplates.Install(package)),
            WriteArtifact(root, "Uninstall.ps1", PowerShellTemplates.Uninstall(package)),
            WriteArtifact(root, "Detect-Application.ps1", PowerShellTemplates.Detect(package, request)),
            WriteArtifact(root, "Test-Package.ps1", PowerShellTemplates.Test(package)),
            WriteArtifact(docs, "SCCM-Deployment-Guide.html", PowerShellTemplates.Guide(package, request)),
            WriteArtifact(docs, "Packaging-Validation-Report.json", JsonSerializer.Serialize(package, new JsonSerializerOptions { WriteIndented = true }))
        };

        return new ArtifactGenerationResult(root, generated);
    }

    private static string WriteArtifact(string directory, string fileName, string content)
    {
        Directory.CreateDirectory(directory);
        var path = Path.Combine(directory, fileName);
        var temp = path + ".tmp";
        File.WriteAllText(temp, content, new System.Text.UTF8Encoding(false));
        File.Move(temp, path, true);
        return path;
    }

    private static string ResolveSource(string? path)
    {
        if (string.IsNullOrWhiteSpace(path)) throw new InvalidOperationException("Configure the installer source path before analysis.");
        return Environment.ExpandEnvironmentVariables(path.Trim().Trim('"'));
    }
    private static FileEvidence SelectPrimaryInstaller(List<FileEvidence> files) => files
        .OrderBy(x => x.Extension.ToLowerInvariant() switch { ".msi" => 0, ".exe" => 1, ".msix" or ".msixbundle" => 2, _ => 9 })
        .ThenByDescending(x => x.Size).First();
    private static async Task<FileEvidence> ReadEvidenceAsync(string path, CancellationToken ct)
    {
        var info = new FileInfo(path);
        string hash;
        await using (var stream = File.OpenRead(path)) hash = Convert.ToHexString(await SHA256.HashDataAsync(stream, ct));
        FileVersionInfo? vi = null;
        try { vi = FileVersionInfo.GetVersionInfo(path); } catch { }
        var signature = "Not checked"; string? signer = null;
        if (OperatingSystem.IsWindows() && new[] { ".exe", ".msi", ".msp", ".msix" }.Contains(info.Extension, StringComparer.OrdinalIgnoreCase))
        {
            try
            {
                var escaped = path.Replace("'", "''");
                var output = await RunPowerShellAsync($"$s=Get-AuthenticodeSignature -LiteralPath '{escaped}'; [pscustomobject]@{{Status=$s.Status.ToString();Signer=if($s.SignerCertificate){{$s.SignerCertificate.Subject}}else{{$null}}}} | ConvertTo-Json -Compress", ct);
                using var doc = JsonDocument.Parse(output);
                signature = doc.RootElement.GetProperty("Status").GetString() ?? "Unknown";
                if (doc.RootElement.TryGetProperty("Signer", out var s) && s.ValueKind != JsonValueKind.Null) signer = s.GetString();
            } catch { signature = "Unknown"; }
        }
        return new FileEvidence(info.Name, info.FullName, info.Length, info.Extension, hash, vi?.FileVersion, vi?.ProductVersion, vi?.CompanyName, signature, signer);
    }
    private static string DetectInstallerType(string path, string extension)
    {
        if (extension.Equals(".msi", StringComparison.OrdinalIgnoreCase)) return "Windows Installer (MSI)";
        if (extension.StartsWith(".msix", StringComparison.OrdinalIgnoreCase) || extension.StartsWith(".appx", StringComparison.OrdinalIgnoreCase)) return "MSIX / AppX";
        if (!extension.Equals(".exe", StringComparison.OrdinalIgnoreCase)) return extension.TrimStart('.').ToUpperInvariant();
        var name = Path.GetFileName(path).ToLowerInvariant();
        try
        {
            using var fs = File.OpenRead(path); var len = (int)Math.Min(fs.Length, 8 * 1024 * 1024); var bytes = new byte[len]; fs.ReadExactly(bytes); var text = System.Text.Encoding.Latin1.GetString(bytes);
            if (text.Contains("Inno Setup", StringComparison.OrdinalIgnoreCase)) return "Inno Setup";
            if (text.Contains("Nullsoft", StringComparison.OrdinalIgnoreCase) || text.Contains("NSIS", StringComparison.OrdinalIgnoreCase)) return "NSIS";
            if (text.Contains("InstallShield", StringComparison.OrdinalIgnoreCase)) return "InstallShield";
            if (text.Contains("WixBundle", StringComparison.OrdinalIgnoreCase) || text.Contains("Burn", StringComparison.OrdinalIgnoreCase)) return "WiX Burn Bootstrapper";
            if (text.Contains("Advanced Installer", StringComparison.OrdinalIgnoreCase)) return "Advanced Installer";
            if (text.Contains("Squirrel", StringComparison.OrdinalIgnoreCase)) return "Squirrel";
        } catch { }
        if (name.Contains("setup") || name.Contains("install")) return "EXE Bootstrapper";
        return "Unknown EXE Installer";
    }
    private static string DetectArchitecture(string name, string? configured) => Regex.IsMatch(name, "(x64|amd64|64-bit)", RegexOptions.IgnoreCase) ? "x64" : Regex.IsMatch(name, "(x86|32-bit)", RegexOptions.IgnoreCase) ? "x86" : configured ?? "Unknown";
    private static List<CommandCandidate> BuildInstallCandidates(string type, string path)
    {
        var q = $"\"{path}\"";
        var fileName = Path.GetFileName(path);
        if (fileName.Contains("CitrixWorkspace", StringComparison.OrdinalIgnoreCase))
            return [
                new($"{q} /silent /noreboot", 99, "Citrix Workspace documented silent installation"),
                new($"{q} /silent", 96, "Citrix Workspace documented silent installation")
            ];
        return type switch
        {
            "Windows Installer (MSI)" => [new($"msiexec.exe /i {q} /qn /norestart /L*v \"%WINDIR%\\Logs\\SoftwarePackaging\\Install.log\"", 100, "Native Windows Installer silent syntax")],
            "Inno Setup" => [new($"{q} /SP- /VERYSILENT /SUPPRESSMSGBOXES /NORESTART", 98, "Inno Setup signature"), new($"{q} /SILENT /NORESTART", 80, "Inno Setup fallback")],
            "NSIS" => [new($"{q} /S", 98, "NSIS signature; switch is case-sensitive")],
            "InstallShield" => [new($"{q} /s /v\"/qn /norestart\"", 88, "InstallShield MSI wrapper"), new($"{q} /s", 72, "InstallShield response mode", "Medium")],
            "WiX Burn Bootstrapper" => [new($"{q} /quiet /norestart", 95, "WiX Burn standard switches")],
            "Advanced Installer" => [new($"{q} /exenoui /qn APPDIR=\"C:\\Program Files\\Application\"", 84, "Advanced Installer EXE bootstrapper", "Medium"), new($"{q} /quiet", 74, "Generic vendor silent mode")],
            "Squirrel" => [new($"{q} --silent", 88, "Squirrel bootstrapper convention")],
            "MSIX / AppX" => [new($"powershell.exe -NoProfile -Command \"Add-AppxPackage -Path '{path.Replace("'", "''")}'\"", 95, "Native AppX deployment command")],
            _ => [new($"{q} /quiet /norestart", 55, "Generic quiet convention", "Medium"), new($"{q} /S", 45, "Common EXE convention", "Medium"), new($"{q} /silent", 40, "Common EXE convention", "Medium")]
        };
    }
    private static List<CommandCandidate> BuildUninstallCandidates(string type, string path, string? productCode)
    {
        if (!string.IsNullOrWhiteSpace(productCode)) return [new($"msiexec.exe /x {productCode} /qn /norestart /L*v \"%WINDIR%\\Logs\\SoftwarePackaging\\Uninstall.log\"", 100, "MSI ProductCode")];
        var q = $"\"{path}\"";
        var fileName = Path.GetFileName(path);
        if (fileName.Contains("CitrixWorkspace", StringComparison.OrdinalIgnoreCase))
            return [new($"{q} /silent /uninstall", 99, "Citrix Workspace documented silent uninstallation")];
        return type switch
        {
            "Inno Setup" => [new("\"<InstallLocation>\\unins000.exe\" /VERYSILENT /SUPPRESSMSGBOXES /NORESTART", 88, "Inno Setup uninstaller convention", "Medium")],
            "NSIS" => [new("\"<InstallLocation>\\Uninstall.exe\" /S", 88, "NSIS uninstaller convention", "Medium")],
            "WiX Burn Bootstrapper" => [new($"{q} /uninstall /quiet /norestart", 90, "WiX Burn uninstall mode")],
            "Squirrel" => [new("\"<InstallLocation>\\Update.exe\" --uninstall -s", 84, "Squirrel update executable", "Medium")],
            _ => [new("Use QuietUninstallString discovered after installation", 60, "Uninstall registry discovery required", "Low")]
        };
    }
    private static List<string> BuildDetectionCandidates(FileEvidence primary, string? productCode, string vendor, string app, string version)
    {
        var result = new List<string>();
        if (!string.IsNullOrWhiteSpace(productCode)) result.Add($"MSI ProductCode {productCode} with version >= {version}");
        result.Add($"Registry: HKLM uninstall entry matching publisher '{vendor}' and display name '{app}'");
        if (!string.IsNullOrWhiteSpace(primary.FileVersion)) result.Add($"File version: validated installed executable >= {primary.FileVersion}");
        result.Add("Custom PowerShell detection using registry and file-version corroboration");
        return result;
    }
    private static async Task<(string?, string?)> ReadMsiPropertiesAsync(string path, CancellationToken ct)
    {
        try
        {
            var escaped = path.Replace("'", "''");
            var script = "$i=New-Object -ComObject WindowsInstaller.Installer;$d=$i.OpenDatabase('" + escaped + "',0);function P($n){$v=$d.OpenView(\"SELECT `Value` FROM `Property` WHERE `Property`='$n'\");$v.Execute();$r=$v.Fetch();if($r){$r.StringData(1)}};[pscustomobject]@{ProductCode=P 'ProductCode';UpgradeCode=P 'UpgradeCode'}|ConvertTo-Json -Compress";
            var output = await RunPowerShellAsync(script, ct); using var doc = JsonDocument.Parse(output);
            return (doc.RootElement.GetProperty("ProductCode").GetString(), doc.RootElement.GetProperty("UpgradeCode").GetString());
        } catch { return (null, null); }
    }
    private static async Task<string> RunPowerShellAsync(string script, CancellationToken ct)
    {
        var psi = new ProcessStartInfo("powershell.exe", $"-NoProfile -ExecutionPolicy Bypass -Command \"{script.Replace("\"", "\\\"")}\"") { UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true, CreateNoWindow = true };
        using var p = Process.Start(psi) ?? throw new InvalidOperationException("Unable to start PowerShell.");
        var stdoutTask = p.StandardOutput.ReadToEndAsync(ct); var stderrTask = p.StandardError.ReadToEndAsync(ct);
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct); timeout.CancelAfter(TimeSpan.FromSeconds(30));
        try { await p.WaitForExitAsync(timeout.Token); } catch (OperationCanceledException) when (!ct.IsCancellationRequested) { try { p.Kill(true); } catch { } throw new TimeoutException("PowerShell metadata operation exceeded 30 seconds."); }
        var stdout = await stdoutTask; var stderr = await stderrTask;
        if (p.ExitCode != 0) throw new InvalidOperationException(stderr); return stdout.Trim();
    }

    public SystemBaseline CaptureBaseline()
    {
        if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException("Detection discovery is available only on Windows.");
        return new SystemBaseline(DateTime.UtcNow, ReadUninstallEntries());
    }

    public DetectionDiscovery DiscoverDetection(PackageRecord package, SystemBaseline baseline)
    {
        var after = ReadUninstallEntries();
        var beforeKeys = baseline.UninstallEntries.Select(x => $"{x.Hive}|{x.View}|{x.KeyPath}").ToHashSet(StringComparer.OrdinalIgnoreCase);
        var added = after.Where(x => !beforeKeys.Contains($"{x.Hive}|{x.View}|{x.KeyPath}")).ToList();
        var appTokens = (package.ApplicationName ?? string.Empty).Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        var vendorTokens = (package.Vendor ?? string.Empty).Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        int Score(UninstallRegistryEntry e)
        {
            var score = 0;
            if (added.Contains(e)) score += 45;
            if (appTokens.Any(t => (e.DisplayName ?? "").Contains(t, StringComparison.OrdinalIgnoreCase))) score += 25;
            if (vendorTokens.Any(t => (e.Publisher ?? "").Contains(t, StringComparison.OrdinalIgnoreCase))) score += 15;
            if (!string.IsNullOrWhiteSpace(e.DisplayVersion)) score += 10;
            if (!string.IsNullOrWhiteSpace(e.QuietUninstallString)) score += 5;
            return Math.Min(score, 99);
        }
        var candidates = after.Select(e => new { Entry=e, Score=Score(e) })
            .Where(x => x.Score >= 35)
            .OrderByDescending(x => x.Score)
            .Take(10)
            .Select(x => new DetectionCandidate(
                "Registry", x.Score,
                added.Contains(x.Entry) ? "New uninstall registry entry created by the successful installation" : "Installed application entry matching application metadata",
                $"Registry::{x.Entry.Hive}\\{x.Entry.KeyPath}", "DisplayVersion", null, x.Entry.ProductCode,
                x.Entry.DisplayVersion ?? package.Version, x.Entry.DisplayName ?? package.ApplicationName))
            .ToList();
        var selected = candidates.FirstOrDefault();
        var installedValidated = selected is not null && EvaluateDetection(selected);
        return new DetectionDiscovery(candidates, selected, installedValidated, false, DateTime.UtcNow);
    }

    public UninstallDiscovery InvestigateUninstall(PackageRecord package, DetectionDiscovery? detection)
    {
        if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException("Uninstall investigation is available only on Windows.");
        var evidence = new List<UninstallEvidence>();
        var candidates = new List<CommandCandidate>();
        var entries = ReadUninstallEntries();
        UninstallRegistryEntry? entry = null;

        if (detection?.Selected?.RegistryPath is { Length: > 0 } selectedPath)
        {
            var normalized = selectedPath.Replace("Registry::", "", StringComparison.OrdinalIgnoreCase);
            entry = entries.FirstOrDefault(x => $"{x.Hive}\\{x.KeyPath}".Equals(normalized, StringComparison.OrdinalIgnoreCase));
            evidence.Add(entry is null
                ? new("Registry", "Not found", "The selected detection registry entry could not be resolved.", selectedPath)
                : new("Registry", "Found", $"Uninstall entry found: {entry.DisplayName} {entry.DisplayVersion}", selectedPath));
        }

        entry ??= entries
            .Select(x => new { Entry = x, Score = ScoreUninstallEntry(package, x) })
            .OrderByDescending(x => x.Score)
            .FirstOrDefault(x => x.Score >= 35)?.Entry;

        if (entry is not null)
        {
            evidence.Add(new("QuietUninstallString", string.IsNullOrWhiteSpace(entry.QuietUninstallString) ? "Not available" : "Found",
                string.IsNullOrWhiteSpace(entry.QuietUninstallString) ? "The vendor did not register QuietUninstallString." : entry.QuietUninstallString!, entry.QuietUninstallString));
            evidence.Add(new("UninstallString", string.IsNullOrWhiteSpace(entry.UninstallString) ? "Not available" : "Found",
                string.IsNullOrWhiteSpace(entry.UninstallString) ? "The vendor did not register UninstallString." : entry.UninstallString!, entry.UninstallString));
            evidence.Add(new("InstallLocation", string.IsNullOrWhiteSpace(entry.InstallLocation) ? "Not available" : "Found",
                string.IsNullOrWhiteSpace(entry.InstallLocation) ? "InstallLocation was not registered; the engine will infer it from uninstall paths." : entry.InstallLocation!, entry.InstallLocation));

            if (!string.IsNullOrWhiteSpace(entry.QuietUninstallString))
                AddCandidate(candidates, new(entry.QuietUninstallString!, 100, "Vendor-provided QuietUninstallString", "Low"));

            if (!string.IsNullOrWhiteSpace(entry.ProductCode))
                AddCandidate(candidates, new($"msiexec.exe /x {entry.ProductCode} /qn /norestart /L*v \"%WINDIR%\\Logs\\SoftwarePackaging\\Uninstall.log\"", 100, "MSI ProductCode discovered after installation", "Low"));
        }

        var installLocation = ResolveInstallLocation(entry);
        var uninstallExecutables = new List<string>();
        if (entry?.UninstallString is { Length: > 0 })
        {
            try
            {
                var (exe, _) = SplitCommandLine(entry.UninstallString);
                exe = Environment.ExpandEnvironmentVariables(exe);
                if (File.Exists(exe)) uninstallExecutables.Add(Path.GetFullPath(exe));
            }
            catch { }
        }

        if (!string.IsNullOrWhiteSpace(installLocation) && Directory.Exists(installLocation))
        {
            var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            { "uninstall.exe", "uninstaller.exe", "unins000.exe", "unins001.exe", "remove.exe", "maintenancetool.exe", "update.exe" };
            uninstallExecutables.AddRange(Directory.EnumerateFiles(installLocation, "*.exe", SearchOption.TopDirectoryOnly)
                .Where(x => names.Contains(Path.GetFileName(x)) || Path.GetFileName(x).Contains("uninstall", StringComparison.OrdinalIgnoreCase)));
            evidence.Add(new("Application folder scan", "Completed", $"Scanned {installLocation} for product-specific uninstall executables.", installLocation));
        }

        foreach (var exe in uninstallExecutables.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            var technology = DetectInstallerType(exe, Path.GetExtension(exe));
            var info = FileVersionInfo.GetVersionInfo(exe);
            evidence.Add(new("Uninstall executable", "Found", $"{Path.GetFileName(exe)} | {info.FileDescription ?? "No description"} | {info.CompanyName ?? "Unknown company"}", exe, technology));
            foreach (var candidate in BuildDiscoveredUninstallCandidates(package, entry, exe, technology)) AddCandidate(candidates, candidate);
        }

        if (entry?.UninstallString is { Length: > 0 } raw && !candidates.Any(x => x.Command.Equals(raw, StringComparison.OrdinalIgnoreCase)))
        {
            var normalized = NormalizeRegisteredUninstall(raw, package, entry);
            foreach (var c in normalized) AddCandidate(candidates, c);
        }

        if (candidates.Count == 0)
            evidence.Add(new("Candidate generation", "No reliable candidate", "No safe silent uninstall command could be derived automatically. Manual review is required."));
        else
            evidence.Add(new("Candidate generation", "Completed", $"Generated {candidates.Count} evidence-based uninstall candidate(s)."));

        return new UninstallDiscovery(evidence, candidates.OrderByDescending(x => x.Confidence).ToList(), entry, installLocation, DateTime.UtcNow);
    }

    private static int ScoreUninstallEntry(PackageRecord package, UninstallRegistryEntry entry)
    {
        var score = 0;
        foreach (var token in (package.ApplicationName ?? "").Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
            if ((entry.DisplayName ?? "").Contains(token, StringComparison.OrdinalIgnoreCase)) score += 25;
        foreach (var token in (package.Vendor ?? "").Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
            if ((entry.Publisher ?? "").Contains(token, StringComparison.OrdinalIgnoreCase)) score += 10;
        if (!string.IsNullOrWhiteSpace(entry.UninstallString)) score += 15;
        if (!string.IsNullOrWhiteSpace(entry.QuietUninstallString)) score += 25;
        if (!string.IsNullOrWhiteSpace(entry.InstallLocation)) score += 10;
        return Math.Min(score, 100);
    }

    private static string? ResolveInstallLocation(UninstallRegistryEntry? entry)
    {
        if (!string.IsNullOrWhiteSpace(entry?.InstallLocation) && Directory.Exists(Environment.ExpandEnvironmentVariables(entry.InstallLocation)))
            return Path.GetFullPath(Environment.ExpandEnvironmentVariables(entry.InstallLocation));
        if (!string.IsNullOrWhiteSpace(entry?.UninstallString))
        {
            try
            {
                var (exe, _) = SplitCommandLine(entry.UninstallString);
                exe = Environment.ExpandEnvironmentVariables(exe);
                if (File.Exists(exe)) return Path.GetDirectoryName(Path.GetFullPath(exe));
            }
            catch { }
        }
        return null;
    }

    private static IEnumerable<CommandCandidate> BuildDiscoveredUninstallCandidates(PackageRecord package, UninstallRegistryEntry? entry, string exe, string technology)
    {
        var q = $"\"{exe}\"";
        var name = Path.GetFileName(exe);
        var product = $"{package.ApplicationName} {entry?.DisplayName}";
        if (product.Contains("7-Zip", StringComparison.OrdinalIgnoreCase) || product.Contains("7Zip", StringComparison.OrdinalIgnoreCase))
        {
            yield return new($"{q} /S", 99, "7-Zip product-specific uninstaller discovered in InstallLocation; /S is the silent switch", "Low");
            yield break;
        }
        if (Regex.IsMatch(name, @"^unins\d+\.exe$", RegexOptions.IgnoreCase) || technology == "Inno Setup")
        {
            yield return new($"{q} /VERYSILENT /SUPPRESSMSGBOXES /NORESTART", 97, "Inno Setup uninstaller signature", "Low");
            yield break;
        }
        if (technology == "NSIS")
        {
            yield return new($"{q} /S", 97, "NSIS uninstaller signature; /S is case-sensitive", "Low");
            yield break;
        }
        if (name.Equals("Update.exe", StringComparison.OrdinalIgnoreCase) || technology == "Squirrel")
        {
            yield return new($"{q} --uninstall -s", 90, "Squirrel uninstall executable convention", "Medium");
            yield break;
        }
        if (technology == "WiX Burn Bootstrapper")
        {
            yield return new($"{q} /uninstall /quiet /norestart", 92, "WiX Burn uninstall mode", "Low");
            yield break;
        }
        yield return new($"{q} /S", 72, "Product-specific uninstall executable found; common silent switch", "Medium");
        yield return new($"{q} /silent", 58, "Product-specific uninstall executable found; generic silent convention", "Medium");
        yield return new($"{q} /quiet", 52, "Product-specific uninstall executable found; generic quiet convention", "Medium");
    }

    private static IReadOnlyList<CommandCandidate> NormalizeRegisteredUninstall(string raw, PackageRecord package, UninstallRegistryEntry entry)
    {
        var result = new List<CommandCandidate>();
        if (raw.Contains("msiexec", StringComparison.OrdinalIgnoreCase))
        {
            var guid = Regex.Match(raw, @"\{[0-9A-F-]{36}\}", RegexOptions.IgnoreCase).Value;
            if (!string.IsNullOrWhiteSpace(guid)) result.Add(new($"msiexec.exe /x {guid} /qn /norestart /L*v \"%WINDIR%\\Logs\\SoftwarePackaging\\Uninstall.log\"", 98, "Normalized MSI UninstallString", "Low"));
            return result;
        }
        try
        {
            var (exe, _) = SplitCommandLine(raw);
            exe = Environment.ExpandEnvironmentVariables(exe);
            if (File.Exists(exe)) result.AddRange(BuildDiscoveredUninstallCandidates(package, entry, exe, DetectInstallerType(exe, Path.GetExtension(exe))));
        }
        catch { }
        return result;
    }

    private static void AddCandidate(List<CommandCandidate> list, CommandCandidate candidate)
    {
        if (!list.Any(x => x.Command.Equals(candidate.Command, StringComparison.OrdinalIgnoreCase))) list.Add(candidate);
    }

    public bool EvaluateDetection(DetectionCandidate candidate)
    {
        if (!OperatingSystem.IsWindows()) return false;
        try
        {
            if (candidate.Type.Equals("Registry", StringComparison.OrdinalIgnoreCase) && !string.IsNullOrWhiteSpace(candidate.RegistryPath))
            {
                var normalized = candidate.RegistryPath.Replace("Registry::", "", StringComparison.OrdinalIgnoreCase);
                var split = normalized.IndexOf('\\');
                if (split < 0) return false;
                var hiveName = normalized[..split]; var subKey = normalized[(split+1)..];
                var hive = hiveName.Equals("HKEY_LOCAL_MACHINE", StringComparison.OrdinalIgnoreCase) ? RegistryHive.LocalMachine : RegistryHive.CurrentUser;
                foreach (var view in new[] { RegistryView.Registry64, RegistryView.Registry32 })
                {
                    using var baseKey = RegistryKey.OpenBaseKey(hive, view);
                    using var key = baseKey.OpenSubKey(subKey);
                    if (key is null) continue;
                    var raw = key.GetValue(candidate.ValueName ?? "DisplayVersion")?.ToString();
                    if (string.IsNullOrWhiteSpace(raw)) continue;
                    if (string.IsNullOrWhiteSpace(candidate.RequiredVersion)) return true;
                    if (Version.TryParse(NormalizeVersion(raw), out var found) && Version.TryParse(NormalizeVersion(candidate.RequiredVersion), out var required)) return found >= required;
                    return string.Equals(raw, candidate.RequiredVersion, StringComparison.OrdinalIgnoreCase);
                }
            }
        }
        catch (Exception ex) { logger.LogWarning(ex, "Detection evaluation failed"); }
        return false;
    }

    private static List<UninstallRegistryEntry> ReadUninstallEntries()
    {
        var result = new List<UninstallRegistryEntry>();
        foreach (var view in new[] { RegistryView.Registry64, RegistryView.Registry32 })
        {
            using var baseKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, view);
            const string root = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall";
            using var uninstall = baseKey.OpenSubKey(root);
            if (uninstall is null) continue;
            foreach (var name in uninstall.GetSubKeyNames())
            {
                using var key = uninstall.OpenSubKey(name); if (key is null) continue;
                var displayName = key.GetValue("DisplayName")?.ToString();
                if (string.IsNullOrWhiteSpace(displayName)) continue;
                var productCode = Regex.IsMatch(name, "^\\{[0-9A-F-]{36}\\}$", RegexOptions.IgnoreCase) ? name : null;
                result.Add(new UninstallRegistryEntry("HKEY_LOCAL_MACHINE", view.ToString(), $@"{root}\{name}", name, displayName,
                    key.GetValue("DisplayVersion")?.ToString(), key.GetValue("Publisher")?.ToString(), key.GetValue("InstallLocation")?.ToString(),
                    key.GetValue("UninstallString")?.ToString(), key.GetValue("QuietUninstallString")?.ToString(), productCode));
            }
        }
        return result;
    }

    private static string NormalizeVersion(string value)
    {
        var m = Regex.Match(value ?? string.Empty, @"\d+(?:\.\d+){0,3}");
        return m.Success ? m.Value : "0.0";
    }

    private static string SafeName(string value) => Regex.Replace(value, "[^A-Za-z0-9._-]", "_");
    private static string Trim(string value) => value.Length > 12000 ? value[..12000] + "\n[output truncated]" : value;
}

public sealed record ArtifactGenerationResult(string OutputDirectory, IReadOnlyList<string> Files);
