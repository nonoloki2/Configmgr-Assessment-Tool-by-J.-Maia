# Enterprise Application Packaging Studio — Real Engine v3

This build replaces the simulated analysis screen with a real background analysis worker.

## What can be tested now

- Source path validation and file enumeration
- Real SHA-256 calculation for every supported file
- File and product metadata collection
- Authenticode signature validation on Windows
- Installer technology detection
- MSI ProductCode and UpgradeCode extraction
- Silent command candidate generation
- Detection candidate generation
- Live backend progress, timestamps, job ID and event console
- Cancel operation
- Explicit failure messages instead of an endless animated bar

## Run

Open PowerShell as Administrator:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\run.ps1
```

Open `http://127.0.0.1:5188`.

## Independent proof test

This verifies the analysis functions without the browser:

```powershell
.\Test-InstallerAnalysis.ps1 -Path 'C:\Packaging\CitrixWorkspaceApp.exe'
```

It calculates real hashes, reads metadata and signature information, and creates `InstallerAnalysis-Proof.json`.

## Expected visible processes

The web backend runs as `dotnet.exe`. During Authenticode and MSI metadata checks, short-lived `powershell.exe` processes may appear. Static analysis does not start `msiexec.exe`; that process is used only during an actual installation or uninstall test.

## v3.1 hotfix

Fixes an analysis-result serialization mismatch that caused the Overview tab to show a completed job while Install, Uninstall and Detection still displayed "Run package analysis first." Existing analyzed packages are supported; no package recreation is required.


## v3.2 execution fix

- Starts quoted installer paths directly instead of wrapping them in a malformed `cmd.exe /c` command.
- Returns a visible startup error when Windows cannot launch the installer.
- Adds Citrix Workspace documented install candidates: `/silent /noreboot` and `/silent`.
- Adds Citrix Workspace documented silent uninstall candidate: `/silent /uninstall`.
- Existing packages should be analyzed again so the updated candidates are generated.


## v3.3 artifact output behavior
Generated SCCM scripts are written directly into the selected application source folder by default:

- Install.ps1
- Uninstall.ps1
- Detect-Application.ps1
- Test-Package.ps1
- Documentation\SCCM-Deployment-Guide.html
- Documentation\Packaging-Validation-Report.json

The PowerShell & Reports tab displays the exact output folder, verifies every generated file, and can open the folder in Windows File Explorer.

## Version 3.5 — Detection Lifecycle Engine

This release changes detection from a static installer guess into a validated lifecycle:

1. Initial analysis discovers install and uninstall commands only.
2. Before an install test, the engine captures the Windows uninstall-registry baseline.
3. After a successful installation, it compares the new registry state and ranks detection candidates.
4. The best candidate is validated while the application is installed.
5. After a successful uninstall, the same candidate is validated again and must report the application as absent.
6. PowerShell and report generation remains blocked until Install = Passed, Uninstall = Passed and Detection = Validated.

Because the local schema changed, start this version in a new folder and recreate the test package. The prior database is backed up automatically when present.


## v3.5 — Uninstall Intelligence Engine

After a successful installation, the application now investigates the installed product instead of relying only on the original installer. It reads `QuietUninstallString`, `UninstallString`, `InstallLocation`, MSI ProductCode, and scans the application directory for product-specific uninstall executables.

The Uninstall tab displays an evidence trail and ranked commands. For 7-Zip, the expected discovered command is:

```text
"C:\Program Files\7-Zip\Uninstall.exe" /S
```

The selected detection method is tested after uninstall to confirm that the application is absent.
