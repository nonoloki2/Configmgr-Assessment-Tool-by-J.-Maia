using System.Text.Json;
using EnterpriseApplicationPackagingStudio.Data;
using EnterpriseApplicationPackagingStudio.Hubs;
using EnterpriseApplicationPackagingStudio.Models;
using EnterpriseApplicationPackagingStudio.Services;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<AppDbContext>(options => options.UseSqlite(builder.Configuration.GetConnectionString("Default")));
builder.Services.AddSignalR();
builder.Services.AddProblemDetails();
builder.Services.AddSingleton<PackagingEngine>();
var app = builder.Build();
app.UseExceptionHandler(); app.UseDefaultFiles(); app.UseStaticFiles();

await using (var scope = app.Services.CreateAsyncScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    var versionFile = Path.Combine(app.Environment.ContentRootPath, ".schema-version");
    const string schemaVersion = "2";
    if (File.Exists(Path.Combine(app.Environment.ContentRootPath, "Data", "packaging-studio.db")) && (!File.Exists(versionFile) || File.ReadAllText(versionFile).Trim() != schemaVersion))
    {
        var dbPath = Path.Combine(app.Environment.ContentRootPath, "Data", "packaging-studio.db");
        if (File.Exists(dbPath)) File.Copy(dbPath, dbPath + ".milestone1.bak", true);
        await db.Database.EnsureDeletedAsync();
    }
    await db.Database.EnsureCreatedAsync(); File.WriteAllText(versionFile, schemaVersion);
    if (!await db.ClientProfiles.AnyAsync()) { db.ClientProfiles.Add(new ClientProfile()); await db.SaveChangesAsync(); }
}

app.MapGet("/api/system", () => Results.Ok(new { platform = Environment.OSVersion.ToString(), windows = OperatingSystem.IsWindows(), elevated = IsAdministrator(), laboratoryMode = true, version = "2.0.0-lab" }));
app.MapGet("/api/dashboard", async (AppDbContext db) => Results.Ok(new { total = await db.Packages.CountAsync(), ready = await db.Packages.CountAsync(x => x.Status == "Ready"), testing = await db.Packages.CountAsync(x => x.Status == "Testing"), failed = await db.Packages.CountAsync(x => x.Status == "Failed"), analyzed = await db.Packages.CountAsync(x => x.Status == "Analyzed") }));
app.MapGet("/api/clients", async (AppDbContext db) => Results.Ok(await db.ClientProfiles.OrderBy(x => x.Name).ToListAsync()));
app.MapPost("/api/clients", async (ClientProfile profile, AppDbContext db) => { profile.Id=0; profile.UpdatedAtUtc=DateTime.UtcNow; db.ClientProfiles.Add(profile); await db.SaveChangesAsync(); return Results.Created($"/api/clients/{profile.Id}", profile); });
app.MapPut("/api/clients/{id:int}", async (int id, ClientProfile input, AppDbContext db) => { var p=await db.ClientProfiles.FindAsync(id); if(p is null)return Results.NotFound(); p.Name=input.Name.Trim();p.ApplicationTitle=input.ApplicationTitle.Trim();p.Subtitle=input.Subtitle.Trim();p.PrimaryColor=input.PrimaryColor;p.SecondaryColor=input.SecondaryColor;p.AccentColor=input.AccentColor;p.Theme=input.Theme;p.ReportFooter=input.ReportFooter;p.UpdatedAtUtc=DateTime.UtcNow;await db.SaveChangesAsync();return Results.Ok(p); });
app.MapPost("/api/clients/{id:int}/logo", async (int id, IFormFile file, AppDbContext db, IWebHostEnvironment env) => { var p=await db.ClientProfiles.FindAsync(id);if(p is null)return Results.NotFound();var allowed=new HashSet<string>(StringComparer.OrdinalIgnoreCase){".png",".jpg",".jpeg",".svg",".webp"};var ext=Path.GetExtension(file.FileName);if(!allowed.Contains(ext))return Results.BadRequest(new{error="Unsupported logo format."});if(file.Length>5*1024*1024)return Results.BadRequest(new{error="Logo must be 5 MB or smaller."});var uploads=Path.Combine(env.WebRootPath,"uploads");Directory.CreateDirectory(uploads);var name=$"client-{id}-{Guid.NewGuid():N}{ext.ToLowerInvariant()}";await using var stream=File.Create(Path.Combine(uploads,name));await file.CopyToAsync(stream);p.LogoPath=$"/uploads/{name}";p.UpdatedAtUtc=DateTime.UtcNow;await db.SaveChangesAsync();return Results.Ok(new{p.LogoPath}); }).DisableAntiforgery();

app.MapGet("/api/packages", async (AppDbContext db) => Results.Ok(await db.Packages.Include(x=>x.ClientProfile).OrderByDescending(x=>x.UpdatedAtUtc).ToListAsync()));
app.MapGet("/api/packages/{id:int}", async (int id, AppDbContext db) => { var p=await db.Packages.Include(x=>x.ClientProfile).FirstOrDefaultAsync(x=>x.Id==id);return p is null?Results.NotFound():Results.Ok(p); });
app.MapPost("/api/packages", async (PackageRecord p, AppDbContext db) => { if(string.IsNullOrWhiteSpace(p.ApplicationName))return Results.BadRequest(new{error="Application name is required."});if(!await db.ClientProfiles.AnyAsync(x=>x.Id==p.ClientProfileId))return Results.BadRequest(new{error="Select a valid client profile."});p.Id=0;p.ApplicationName=p.ApplicationName.Trim();p.Status="Draft";p.InstallStatus=p.UninstallStatus=p.DetectionStatus="Pending";p.CreatedAtUtc=p.UpdatedAtUtc=DateTime.UtcNow;db.Packages.Add(p);await db.SaveChangesAsync();return Results.Created($"/api/packages/{p.Id}",p); });
app.MapPut("/api/packages/{id:int}/commands", async (int id, PackageRecord input, AppDbContext db) => { var p=await db.Packages.FindAsync(id);if(p is null)return Results.NotFound();p.SelectedInstallCommand=input.SelectedInstallCommand;p.SelectedUninstallCommand=input.SelectedUninstallCommand;p.DetectionMethod=input.DetectionMethod;p.UpdatedAtUtc=DateTime.UtcNow;await db.SaveChangesAsync();return Results.Ok(p); });
app.MapDelete("/api/packages/{id:int}", async (int id, AppDbContext db) => { var p=await db.Packages.FindAsync(id);if(p is null)return Results.NotFound();db.Packages.Remove(p);await db.SaveChangesAsync();return Results.NoContent(); });

app.MapPost("/api/packages/{id:int}/analyze", async (int id, PackagingEngine engine, AppDbContext db, IHubContext<ActivityHub> hub, CancellationToken ct) =>
{
    var p=await db.Packages.FindAsync(id);if(p is null)return Results.NotFound();p.Status="Analyzing";p.UpdatedAtUtc=DateTime.UtcNow;await db.SaveChangesAsync();await hub.Clients.All.SendAsync("activity",new{packageId=id,message="Installer analysis started",level="info"},ct);
    try { var a=await engine.AnalyzeAsync(p,ct);p.InstallerType=a.InstallerType;p.Confidence=a.Confidence;p.Architecture=a.Architecture;p.Vendor=a.Vendor;p.Version=a.Version;p.Sha256=a.Files.FirstOrDefault(x=>x.FullPath==a.PrimaryInstaller)?.Sha256;p.SignatureStatus=a.Files.FirstOrDefault(x=>x.FullPath==a.PrimaryInstaller)?.SignatureStatus;p.Signer=a.Files.FirstOrDefault(x=>x.FullPath==a.PrimaryInstaller)?.Signer;p.ProductCode=a.ProductCode;p.UpgradeCode=a.UpgradeCode;p.AnalysisJson=JsonSerializer.Serialize(a);p.Status="Analyzed";p.UpdatedAtUtc=DateTime.UtcNow;await db.SaveChangesAsync();await hub.Clients.All.SendAsync("activity",new{packageId=id,message=$"Analysis complete: {a.InstallerType} ({a.Confidence}%)",level="success"},ct);return Results.Ok(a); }
    catch(Exception ex){p.Status="Failed";p.UpdatedAtUtc=DateTime.UtcNow;await db.SaveChangesAsync();await hub.Clients.All.SendAsync("activity",new{packageId=id,message=ex.Message,level="error"},ct);return Results.BadRequest(new{error=ex.Message});}
});
app.MapPost("/api/packages/{id:int}/execute", async (int id, ExecuteAttemptRequest req, PackagingEngine engine, AppDbContext db, IHubContext<ActivityHub> hub, CancellationToken ct) =>
{
    if(!req.ConfirmLabMachine)return Results.BadRequest(new{error="Laboratory machine confirmation is required."});if(!OperatingSystem.IsWindows())return Results.BadRequest(new{error="Execution is supported only on Windows."});if(!IsAdministrator())return Results.BadRequest(new{error="Restart the application as Administrator before executing installers."});
    var p=await db.Packages.FindAsync(id);if(p is null)return Results.NotFound();p.Status="Testing";if(req.Phase.Equals("Install",StringComparison.OrdinalIgnoreCase))p.InstallStatus="Running";else p.UninstallStatus="Running";await db.SaveChangesAsync();await hub.Clients.All.SendAsync("activity",new{packageId=id,message=$"{req.Phase} attempt started",level="warning"},ct);
    var wd=Directory.Exists(p.SourcePath)?p.SourcePath!:Path.GetDirectoryName(p.SourcePath??"")??app.Environment.ContentRootPath;var result=await engine.ExecuteAsync(req.Command,wd,req.Phase,req.TimeoutMinutes,ct);var attempts=string.IsNullOrWhiteSpace(p.AttemptsJson)?new List<AttemptResult>():JsonSerializer.Deserialize<List<AttemptResult>>(p.AttemptsJson!)??[];attempts.Add(result);p.AttemptsJson=JsonSerializer.Serialize(attempts);if(req.Phase.Equals("Install",StringComparison.OrdinalIgnoreCase)){p.SelectedInstallCommand=req.Command;p.InstallStatus=result.Outcome;}else{p.SelectedUninstallCommand=req.Command;p.UninstallStatus=result.Outcome;}p.Status=result.Outcome=="Passed"?"Testing":"Failed";p.UpdatedAtUtc=DateTime.UtcNow;await db.SaveChangesAsync();await hub.Clients.All.SendAsync("activity",new{packageId=id,message=$"{req.Phase} completed: {result.Outcome}, exit code {result.ExitCode}",level=result.Outcome=="Passed"?"success":"error"},ct);return Results.Ok(result);
});
app.MapPost("/api/packages/{id:int}/generate", async (int id, GenerateRequest req, PackagingEngine engine, AppDbContext db) => { var p=await db.Packages.FindAsync(id);if(p is null)return Results.NotFound();p.DetectionMethod=$"{req.DetectionType}: {req.DetectionPath ?? p.ProductCode}";var root=engine.GenerateArtifacts(p,req);p.WorkspacePath=root;p.DetectionStatus="Generated";if(p.InstallStatus=="Passed"&&p.UninstallStatus=="Passed")p.Status="Ready";p.UpdatedAtUtc=DateTime.UtcNow;await db.SaveChangesAsync();return Results.Ok(new{workspacePath=root,status=p.Status}); });
app.MapGet("/api/knowledge", async (AppDbContext db) => Results.Ok(await db.Packages.Where(x=>x.Status=="Ready"||x.Status=="Analyzed").Select(x=>new{x.Id,x.ApplicationName,x.Vendor,x.Version,x.InstallerType,x.SelectedInstallCommand,x.SelectedUninstallCommand,x.DetectionMethod,x.ProductCode,x.UpgradeCode}).ToListAsync()));
app.MapHub<ActivityHub>("/hubs/activity");app.MapFallbackToFile("index.html");app.Run();

static bool IsAdministrator(){if(!OperatingSystem.IsWindows())return false;try{using var identity=System.Security.Principal.WindowsIdentity.GetCurrent();var principal=new System.Security.Principal.WindowsPrincipal(identity);return principal.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);}catch{return false;}}
