# Enterprise Application Packaging Studio — Laboratory Edition

Local ASP.NET Core application for analyzing Windows software installers, discovering silent command candidates, running controlled install/uninstall tests, building SCCM detection methods, generating PowerShell scripts and preserving reusable packaging knowledge.

## Requirements

- Windows 10/11 or Windows Server test VM
- .NET 8 SDK
- PowerShell 5.1
- Administrator privileges for installer execution
- A VM snapshot before every install/uninstall test

## Start

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\run.ps1
```

Open `http://127.0.0.1:5188`.

## Implemented

- Client branding profiles and custom logo
- Local SQLite persistence
- Package workspaces
- Installer metadata, SHA-256 and Authenticode analysis
- MSI ProductCode and UpgradeCode extraction
- Installer technology recognition
- Ranked silent install/uninstall candidates
- Explicitly confirmed controlled execution with timeout
- Attempt history and output capture
- Detection builder
- Generated Install.ps1, Uninstall.ps1, Detect-Application.ps1 and Test-Package.ps1
- SCCM HTML deployment guide and JSON validation report
- Packaging Knowledge Base
- Real-time SignalR-ready activity backend

## Important safety note

This application executes installer commands on the local Windows machine. Use only on a disposable laboratory VM. It intentionally requires an administrator session and explicit confirmation before every command execution.
