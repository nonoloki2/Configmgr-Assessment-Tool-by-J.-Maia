using System.Net;
using EnterpriseApplicationPackagingStudio.Models;

namespace EnterpriseApplicationPackagingStudio.Services;

public static class PowerShellTemplates
{
    public static string Install(PackageRecord p) => Header(p, "Install") + $$"""
$ErrorActionPreference = 'Stop'
$LogRoot = Join-Path $env:WINDIR 'Logs\SoftwarePackaging\{{Safe(p.ApplicationName)}}'
New-Item -Path $LogRoot -ItemType Directory -Force | Out-Null
$Transcript = Join-Path $LogRoot ('Install_{0:yyyyMMdd_HHmmss}.log' -f (Get-Date))
try { Start-Transcript -Path $Transcript -Force | Out-Null } catch {}
try {
    $CommandLine = @'
{{p.SelectedInstallCommand ?? "# No validated install command selected."}}
'@.Trim()
    if ($CommandLine.StartsWith('#') -or [string]::IsNullOrWhiteSpace($CommandLine)) { throw 'No validated install command is configured.' }
    Write-Output "Executing: $CommandLine"
    $process = Start-Process -FilePath 'cmd.exe' -ArgumentList '/d','/s','/c',('"' + $CommandLine + '"') -Wait -PassThru -WindowStyle Hidden
    Write-Output "Installer exit code: $($process.ExitCode)"
    if ($process.ExitCode -notin 0,3010,1641) { exit $process.ExitCode }
    & (Join-Path $PSScriptRoot 'Detect-Application.ps1')
    if (-not $LASTEXITCODE -eq 0) { throw 'Detection script execution failed.' }
    exit $process.ExitCode
}
catch { Write-Error $_; exit 1 }
finally { try { Stop-Transcript | Out-Null } catch {} }
""";

    public static string Uninstall(PackageRecord p) => Header(p, "Uninstall") + $$"""
$ErrorActionPreference = 'Stop'
$LogRoot = Join-Path $env:WINDIR 'Logs\SoftwarePackaging\{{Safe(p.ApplicationName)}}'
New-Item -Path $LogRoot -ItemType Directory -Force | Out-Null
$Transcript = Join-Path $LogRoot ('Uninstall_{0:yyyyMMdd_HHmmss}.log' -f (Get-Date))
try { Start-Transcript -Path $Transcript -Force | Out-Null } catch {}
try {
    $CommandLine = @'
{{p.SelectedUninstallCommand ?? "# No validated uninstall command selected."}}
'@.Trim()
    if ($CommandLine.StartsWith('#') -or [string]::IsNullOrWhiteSpace($CommandLine)) { throw 'No validated uninstall command is configured.' }
    Write-Output "Executing: $CommandLine"
    $process = Start-Process -FilePath 'cmd.exe' -ArgumentList '/d','/s','/c',('"' + $CommandLine + '"') -Wait -PassThru -WindowStyle Hidden
    Write-Output "Uninstaller exit code: $($process.ExitCode)"
    if ($process.ExitCode -notin 0,3010,1641) { exit $process.ExitCode }
    exit $process.ExitCode
}
catch { Write-Error $_; exit 1 }
finally { try { Stop-Transcript | Out-Null } catch {} }
""";

    public static string Detect(PackageRecord p, GenerateRequest r)
    {
        var body = r.DetectionType switch
        {
            "MSI" when !string.IsNullOrWhiteSpace(p.ProductCode) => $$"""
$ProductCode = '{{p.ProductCode}}'
$RequiredVersion = [version]'{{r.RequiredVersion ?? p.Version ?? "0.0"}}'
$apps = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue
$app = $apps | Where-Object { $_.PSChildName -eq $ProductCode -or $_.ProductCode -eq $ProductCode } | Select-Object -First 1
if ($app -and $app.DisplayVersion) { try { if ([version]$app.DisplayVersion -ge $RequiredVersion) { Write-Output "{{p.ApplicationName}} detected: $($app.DisplayVersion)" } } catch {} }
exit 0
""",
            "Registry" => $$"""
$Path = '{{EscapePs(r.DetectionPath)}}'
$ValueName = '{{EscapePs(r.DetectionValue)}}'
$RequiredVersion = [version]'{{r.RequiredVersion ?? p.Version ?? "0.0"}}'
try { $value = Get-ItemPropertyValue -LiteralPath $Path -Name $ValueName -ErrorAction Stop; if ([version]$value -ge $RequiredVersion) { Write-Output "{{p.ApplicationName}} detected: $value" } } catch {}
exit 0
""",
            _ => $$"""
$Path = '{{EscapePs(r.DetectionPath)}}'
$RequiredVersion = [version]'{{r.RequiredVersion ?? p.Version ?? "0.0"}}'
if (Test-Path -LiteralPath $Path) { try { $v=[version](Get-Item -LiteralPath $Path).VersionInfo.FileVersion; if ($v -ge $RequiredVersion) { Write-Output "{{p.ApplicationName}} detected: $v" } } catch {} }
exit 0
"""
        };
        return Header(p, "Detection") + body;
    }

    public static string Test(PackageRecord p) => Header(p, "Lifecycle Test") + """
$ErrorActionPreference = 'Stop'
$Results = [System.Collections.Generic.List[object]]::new()
function Add-Result($Stage,$Passed,$Details){$Results.Add([pscustomobject]@{Stage=$Stage;Passed=$Passed;Details=$Details;Timestamp=(Get-Date)})}
function Is-Detected { $o=& (Join-Path $PSScriptRoot 'Detect-Application.ps1') 2>&1; return -not [string]::IsNullOrWhiteSpace(($o|Out-String).Trim()) }
try {
 Add-Result 'Pre-install detection' (-not (Is-Detected)) 'Application should be absent.'
 & (Join-Path $PSScriptRoot 'Install.ps1'); Add-Result 'Install' ($LASTEXITCODE -in 0,3010,1641) "Exit code $LASTEXITCODE"
 Add-Result 'Post-install detection' (Is-Detected) 'Application should be present.'
 & (Join-Path $PSScriptRoot 'Install.ps1'); Add-Result 'Idempotency' ($LASTEXITCODE -in 0,3010,1641) "Second install exit code $LASTEXITCODE"
 & (Join-Path $PSScriptRoot 'Uninstall.ps1'); Add-Result 'Uninstall' ($LASTEXITCODE -in 0,3010,1641) "Exit code $LASTEXITCODE"
 Add-Result 'Post-uninstall detection' (-not (Is-Detected)) 'Application should be absent.'
}
finally {
 $root=Split-Path $PSScriptRoot; $json=Join-Path $root 'Documentation\Lifecycle-Test.json'; $Results|ConvertTo-Json -Depth 4|Set-Content $json -Encoding UTF8
 $Results|Format-Table -AutoSize
}
if ($Results.Passed -contains $false) { exit 1 } else { exit 0 }
""";

    public static string Guide(PackageRecord p, GenerateRequest r) => $$"""
<!doctype html><html><head><meta charset="utf-8"><title>{{WebUtility.HtmlEncode(p.ApplicationName)}} SCCM Deployment Guide</title><style>body{font-family:Segoe UI,Arial;margin:40px;color:#132238}h1{color:#0b5fff}.card{border:1px solid #d9e2ef;border-radius:12px;padding:18px;margin:14px 0}code{background:#f1f5f9;padding:3px 6px;border-radius:5px}</style></head><body>
<h1>{{WebUtility.HtmlEncode(p.ApplicationName)}} — SCCM Deployment Guide</h1>
<div class="card"><b>Vendor:</b> {{WebUtility.HtmlEncode(p.Vendor)}}<br><b>Version:</b> {{WebUtility.HtmlEncode(p.Version)}}<br><b>Architecture:</b> {{WebUtility.HtmlEncode(p.Architecture)}}<br><b>Installer technology:</b> {{WebUtility.HtmlEncode(p.InstallerType)}}</div>
<div class="card"><h2>Programs</h2><p><b>Install:</b> <code>powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\Scripts\Install.ps1"</code></p><p><b>Uninstall:</b> <code>powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\Scripts\Uninstall.ps1"</code></p></div>
<div class="card"><h2>Detection</h2><p>{{WebUtility.HtmlEncode(r.DetectionType)}} — {{WebUtility.HtmlEncode(p.DetectionMethod)}}</p></div>
<div class="card"><h2>Return Codes</h2><p>0 = Success; 3010 = Soft reboot; 1641 = Hard reboot; other = Failure.</p></div>
<div class="card"><h2>User Experience</h2><p>Install for system, whether or not a user is logged on, hidden visibility, Configuration Manager controls restart.</p></div>
</body></html>
""";

    private static string Header(PackageRecord p, string purpose) => $$"""
<#
.SYNOPSIS
  {{purpose}} script for {{p.ApplicationName}} {{p.Version}}.
.DESCRIPTION
  Generated by Enterprise Application Packaging Studio for SCCM/MECM laboratory validation.
#>

""";
    private static string EscapePs(string? value) => (value ?? string.Empty).Replace("'", "''");
    private static string Safe(string value) => string.Concat(value.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c));
}
