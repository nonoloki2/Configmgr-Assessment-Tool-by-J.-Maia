$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    Write-Host 'The .NET 8 SDK is required.' -ForegroundColor Red
    Write-Host 'Install it, reopen PowerShell, and run this script again.'
    exit 1
}
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) { Write-Warning 'Static analysis will work, but installer execution requires Run as Administrator.' }
$env:ASPNETCORE_URLS = 'http://127.0.0.1:5188'
Start-Process 'http://127.0.0.1:5188'
dotnet run
