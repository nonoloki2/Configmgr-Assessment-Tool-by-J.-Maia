namespace EnterpriseApplicationPackagingStudio.Models;

public sealed class AnalysisJob
{
    public string Id { get; init; } = Guid.NewGuid().ToString("N");
    public int PackageId { get; init; }
    public string Status { get; set; } = "Queued";
    public int Progress { get; set; }
    public int CurrentStep { get; set; }
    public int TotalSteps { get; set; } = 9;
    public string CurrentOperation { get; set; } = "Waiting for worker";
    public string? Error { get; set; }
    public DateTime CreatedAtUtc { get; init; } = DateTime.UtcNow;
    public DateTime? StartedAtUtc { get; set; }
    public DateTime? CompletedAtUtc { get; set; }
    public List<AnalysisJobEvent> Events { get; } = [];
    public CancellationTokenSource Cancellation { get; } = new();
}

public sealed record AnalysisJobEvent(DateTime TimestampUtc, string Level, string Step, string Message, int Progress);
public sealed record AnalysisProgress(int Step, int TotalSteps, int Percent, string Operation, string Message, string Level = "info");
