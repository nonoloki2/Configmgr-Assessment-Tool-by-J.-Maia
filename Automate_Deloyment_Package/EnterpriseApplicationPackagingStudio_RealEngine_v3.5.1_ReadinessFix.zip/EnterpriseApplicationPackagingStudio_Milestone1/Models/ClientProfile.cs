namespace EnterpriseApplicationPackagingStudio.Models;

public sealed class ClientProfile
{
    public int Id { get; set; }
    public string Name { get; set; } = "Default Corporate";
    public string ApplicationTitle { get; set; } = "Enterprise Application Packaging Studio";
    public string Subtitle { get; set; } = "Silent Installation Discovery and SCCM Deployment Builder";
    public string PrimaryColor { get; set; } = "#0B5FFF";
    public string SecondaryColor { get; set; } = "#102A43";
    public string AccentColor { get; set; } = "#14B8A6";
    public string Theme { get; set; } = "dark";
    public string? LogoPath { get; set; }
    public string? ReportFooter { get; set; }
    public DateTime UpdatedAtUtc { get; set; } = DateTime.UtcNow;
}
