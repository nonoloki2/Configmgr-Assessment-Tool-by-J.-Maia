namespace EnterpriseApplicationPackagingStudio.Models;

public sealed class PackageRecord
{
    public int Id { get; set; }
    public string ApplicationName { get; set; } = string.Empty;
    public string? Vendor { get; set; }
    public string? Version { get; set; }
    public string? Architecture { get; set; }
    public string? SourcePath { get; set; }
    public string Status { get; set; } = "Draft";
    public string InstallStatus { get; set; } = "Pending";
    public string UninstallStatus { get; set; } = "Pending";
    public string DetectionStatus { get; set; } = "Pending";
    public string InstallerType { get; set; } = "Unknown";
    public int Confidence { get; set; }
    public string? Sha256 { get; set; }
    public string? SignatureStatus { get; set; }
    public string? Signer { get; set; }
    public string? ProductCode { get; set; }
    public string? UpgradeCode { get; set; }
    public string? SelectedInstallCommand { get; set; }
    public string? SelectedUninstallCommand { get; set; }
    public string? DetectionMethod { get; set; }
    public string? AnalysisJson { get; set; }
    public string? AttemptsJson { get; set; }
    public string? KnowledgeJson { get; set; }
    public string? WorkspacePath { get; set; }
    public string? BaselineJson { get; set; }
    public string? DetectionDiscoveryJson { get; set; }
    public int ClientProfileId { get; set; }
    public ClientProfile? ClientProfile { get; set; }
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAtUtc { get; set; } = DateTime.UtcNow;
}
