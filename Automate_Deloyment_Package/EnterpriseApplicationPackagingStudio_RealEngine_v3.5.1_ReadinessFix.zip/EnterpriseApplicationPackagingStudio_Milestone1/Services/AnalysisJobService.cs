using System.Collections.Concurrent;
using EnterpriseApplicationPackagingStudio.Models;

namespace EnterpriseApplicationPackagingStudio.Services;

public sealed class AnalysisJobService
{
    private readonly ConcurrentDictionary<string, AnalysisJob> _jobs = new();
    public AnalysisJob Create(int packageId)
    {
        var job = new AnalysisJob { PackageId = packageId };
        _jobs[job.Id] = job;
        return job;
    }
    public AnalysisJob? Get(string id) => _jobs.TryGetValue(id, out var job) ? job : null;
    public AnalysisJob? GetLatestForPackage(int packageId) => _jobs.Values.Where(x => x.PackageId == packageId).OrderByDescending(x => x.CreatedAtUtc).FirstOrDefault();
    public bool Cancel(string id)
    {
        var job = Get(id); if (job is null || job.Status is "Completed" or "Failed" or "Cancelled") return false;
        job.Cancellation.Cancel(); job.Status = "Cancelling"; return true;
    }
}
