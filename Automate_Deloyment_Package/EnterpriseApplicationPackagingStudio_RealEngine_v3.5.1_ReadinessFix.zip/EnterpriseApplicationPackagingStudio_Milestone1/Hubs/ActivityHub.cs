using Microsoft.AspNetCore.SignalR;

namespace EnterpriseApplicationPackagingStudio.Hubs;

public sealed class ActivityHub : Hub { }
