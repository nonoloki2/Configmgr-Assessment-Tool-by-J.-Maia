using EnterpriseApplicationPackagingStudio.Models;
using Microsoft.EntityFrameworkCore;

namespace EnterpriseApplicationPackagingStudio.Data;

public sealed class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<ClientProfile> ClientProfiles => Set<ClientProfile>();
    public DbSet<PackageRecord> Packages => Set<PackageRecord>();
}
