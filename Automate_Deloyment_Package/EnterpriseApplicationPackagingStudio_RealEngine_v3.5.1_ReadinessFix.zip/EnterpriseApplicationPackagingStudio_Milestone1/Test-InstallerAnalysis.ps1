[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string]$Path
)
$ErrorActionPreference='Stop'
$resolved=(Resolve-Path -LiteralPath $Path).Path
$files=if(Test-Path -LiteralPath $resolved -PathType Container){Get-ChildItem -LiteralPath $resolved -File -Recurse | Where-Object Extension -in '.exe','.msi','.msp','.msix','.msixbundle','.appx','.appxbundle'}else{Get-Item -LiteralPath $resolved}
if(-not $files){throw 'No supported installer files found.'}
$i=0
$result=foreach($file in $files){
 $i++; Write-Progress -Activity 'Real installer analysis' -Status "Hashing $($file.Name)" -PercentComplete (($i/$files.Count)*100)
 $hash=Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256
 $version=$file.VersionInfo
 $signature=if($file.Extension -in '.exe','.msi','.msp','.msix'){Get-AuthenticodeSignature -LiteralPath $file.FullName}else{$null}
 [pscustomobject]@{Name=$file.Name;FullPath=$file.FullName;Size=$file.Length;SHA256=$hash.Hash;FileVersion=$version.FileVersion;ProductVersion=$version.ProductVersion;Company=$version.CompanyName;SignatureStatus=$signature.Status;Signer=$signature.SignerCertificate.Subject}
}
Write-Progress -Activity 'Real installer analysis' -Completed
$result | Format-List
$result | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'InstallerAnalysis-Proof.json') -Encoding UTF8
Write-Host "`nProof report created: $(Join-Path $PSScriptRoot 'InstallerAnalysis-Proof.json')" -ForegroundColor Green
