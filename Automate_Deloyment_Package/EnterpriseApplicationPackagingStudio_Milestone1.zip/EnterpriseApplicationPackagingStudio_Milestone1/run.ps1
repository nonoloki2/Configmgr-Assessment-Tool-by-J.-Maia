# Run from an elevated PowerShell terminal on the Windows laboratory machine.
$ErrorActionPreference = 'Stop'
$project = Join-Path $PSScriptRoot 'EnterpriseApplicationPackagingStudio.csproj'
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    Write-Host 'The .NET 8 SDK is required.' -ForegroundColor Yellow
    Write-Host 'Install it from the official Microsoft .NET download page, then run this script again.'
    exit 1
}
Start-Process 'http://127.0.0.1:5188'
dotnet restore $project
dotnet run --project $project
