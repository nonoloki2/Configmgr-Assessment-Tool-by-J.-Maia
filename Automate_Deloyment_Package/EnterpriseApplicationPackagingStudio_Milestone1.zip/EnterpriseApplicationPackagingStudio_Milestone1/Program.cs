using EnterpriseApplicationPackagingStudio.Data;
using EnterpriseApplicationPackagingStudio.Hubs;
using EnterpriseApplicationPackagingStudio.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("Default")));
builder.Services.AddSignalR();
builder.Services.AddProblemDetails();

var app = builder.Build();
app.UseExceptionHandler();
app.UseDefaultFiles();
app.UseStaticFiles();

await using (var scope = app.Services.CreateAsyncScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    await db.Database.EnsureCreatedAsync();
    if (!await db.ClientProfiles.AnyAsync())
    {
        db.ClientProfiles.Add(new ClientProfile());
        await db.SaveChangesAsync();
    }
}

app.MapGet("/api/dashboard", async (AppDbContext db) =>
{
    var total = await db.Packages.CountAsync();
    var ready = await db.Packages.CountAsync(x => x.Status == "Ready");
    var testing = await db.Packages.CountAsync(x => x.Status == "Testing");
    var failed = await db.Packages.CountAsync(x => x.Status == "Failed");
    return Results.Ok(new { total, ready, testing, failed });
});

app.MapGet("/api/clients", async (AppDbContext db) =>
    Results.Ok(await db.ClientProfiles.OrderBy(x => x.Name).ToListAsync()));

app.MapPost("/api/clients", async (ClientProfile profile, AppDbContext db) =>
{
    profile.Id = 0;
    profile.UpdatedAtUtc = DateTime.UtcNow;
    db.ClientProfiles.Add(profile);
    await db.SaveChangesAsync();
    return Results.Created($"/api/clients/{profile.Id}", profile);
});

app.MapPut("/api/clients/{id:int}", async (int id, ClientProfile input, AppDbContext db) =>
{
    var profile = await db.ClientProfiles.FindAsync(id);
    if (profile is null) return Results.NotFound();
    profile.Name = input.Name.Trim();
    profile.ApplicationTitle = input.ApplicationTitle.Trim();
    profile.Subtitle = input.Subtitle.Trim();
    profile.PrimaryColor = input.PrimaryColor;
    profile.SecondaryColor = input.SecondaryColor;
    profile.AccentColor = input.AccentColor;
    profile.Theme = input.Theme;
    profile.ReportFooter = input.ReportFooter;
    profile.UpdatedAtUtc = DateTime.UtcNow;
    await db.SaveChangesAsync();
    return Results.Ok(profile);
});

app.MapPost("/api/clients/{id:int}/logo", async (int id, IFormFile file, AppDbContext db, IWebHostEnvironment env) =>
{
    var profile = await db.ClientProfiles.FindAsync(id);
    if (profile is null) return Results.NotFound();
    var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { ".png", ".jpg", ".jpeg", ".svg", ".webp" };
    var ext = Path.GetExtension(file.FileName);
    if (!allowed.Contains(ext)) return Results.BadRequest(new { error = "Unsupported logo format." });
    if (file.Length > 5 * 1024 * 1024) return Results.BadRequest(new { error = "Logo must be 5 MB or smaller." });
    var uploads = Path.Combine(env.WebRootPath, "uploads");
    Directory.CreateDirectory(uploads);
    var name = $"client-{id}-{Guid.NewGuid():N}{ext.ToLowerInvariant()}";
    var target = Path.Combine(uploads, name);
    await using var stream = File.Create(target);
    await file.CopyToAsync(stream);
    profile.LogoPath = $"/uploads/{name}";
    profile.UpdatedAtUtc = DateTime.UtcNow;
    await db.SaveChangesAsync();
    return Results.Ok(new { profile.LogoPath });
}).DisableAntiforgery();

app.MapGet("/api/packages", async (AppDbContext db) =>
    Results.Ok(await db.Packages.Include(x => x.ClientProfile).OrderByDescending(x => x.UpdatedAtUtc).ToListAsync()));

app.MapPost("/api/packages", async (PackageRecord package, AppDbContext db) =>
{
    if (string.IsNullOrWhiteSpace(package.ApplicationName))
        return Results.BadRequest(new { error = "Application name is required." });
    if (!await db.ClientProfiles.AnyAsync(x => x.Id == package.ClientProfileId))
        return Results.BadRequest(new { error = "Select a valid client profile." });
    package.Id = 0;
    package.ApplicationName = package.ApplicationName.Trim();
    package.Status = "Draft";
    package.InstallStatus = "Pending";
    package.UninstallStatus = "Pending";
    package.DetectionStatus = "Pending";
    package.CreatedAtUtc = DateTime.UtcNow;
    package.UpdatedAtUtc = DateTime.UtcNow;
    db.Packages.Add(package);
    await db.SaveChangesAsync();
    return Results.Created($"/api/packages/{package.Id}", package);
});

app.MapDelete("/api/packages/{id:int}", async (int id, AppDbContext db) =>
{
    var package = await db.Packages.FindAsync(id);
    if (package is null) return Results.NotFound();
    db.Packages.Remove(package);
    await db.SaveChangesAsync();
    return Results.NoContent();
});

app.MapHub<ActivityHub>("/hubs/activity");
app.MapFallbackToFile("index.html");
app.Run();
