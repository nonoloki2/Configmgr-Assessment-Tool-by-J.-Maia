namespace EnterpriseApplicationPackagingStudio.Models;

public sealed class PackageRecord
{
    public int Id { get; set; }
    public string ApplicationName { get; set; } = string.Empty;
    public string? Vendor { get; set; }
    public string? Version { get; set; }
    public string? Architecture { get; set; }
    public string? SourcePath { get; set; }
    public string Status { get; set; } = "Draft";
    public string InstallStatus { get; set; } = "Pending";
    public string UninstallStatus { get; set; } = "Pending";
    public string DetectionStatus { get; set; } = "Pending";
    public int ClientProfileId { get; set; }
    public ClientProfile? ClientProfile { get; set; }
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAtUtc { get; set; } = DateTime.UtcNow;
}
