# Enterprise Application Packaging Studio — Milestone 1

Local ASP.NET Core foundation for a future SCCM silent software packaging and validation engine.

## Included now

- Modern local web interface
- Dashboard and package workspace list
- New Package workflow
- Multiple client branding profiles
- Client logo upload
- Custom colors and light/dark theme
- Local SQLite database
- Activity log
- Localhost-only web server

## Not included yet

Milestone 1 does not execute installers. Silent switch discovery, PowerShell execution, Local System validation, baseline comparison, uninstall discovery and SCCM script generation will be added in later milestones.

## Requirements

- Dedicated Windows 10/11 or Windows Server laboratory VM
- .NET 8 SDK
- PowerShell 5.1 or later
- Administrator privileges recommended

## Start

1. Extract the ZIP to a local folder, for example `C:\PackagingStudio`.
2. Open an elevated PowerShell window.
3. Run:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\run.ps1
```

4. Open `http://127.0.0.1:5188` if the browser does not open automatically.

The SQLite database is created automatically in `Data\packaging-studio.db`.

## First validation

1. Open **Client Branding**.
2. Create a client profile.
3. Upload a logo.
4. Change the interface colors and theme.
5. Return to **Dashboard**.
6. Select **New Package** and create a test workspace.
7. Restart the application and confirm the data remains saved.
