Set-StrictMode -Version 2.0

function Get-SafeText {
    param([object]$Value,[string]$Fallback='Unknown')
    if ($null -eq $Value) { return $Fallback }
    $text = [string]$Value
    if ([string]::IsNullOrWhiteSpace($text)) { return $Fallback }
    return $text.Trim()
}

function Get-PeArchitecture {
    param([Parameter(Mandatory=$true)][string]$Path)
    try {
        $stream = [System.IO.File]::Open($Path,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Read,[System.IO.FileShare]::ReadWrite)
        try {
            $reader = New-Object System.IO.BinaryReader($stream)
            if ($reader.ReadUInt16() -ne 0x5A4D) { return 'Unknown' }
            $stream.Position = 0x3C
            $peOffset = $reader.ReadInt32()
            if ($peOffset -lt 0 -or $peOffset -gt ($stream.Length - 6)) { return 'Unknown' }
            $stream.Position = $peOffset
            if ($reader.ReadUInt32() -ne 0x00004550) { return 'Unknown' }
            $machine = $reader.ReadUInt16()
            switch ($machine) {
                0x014c { return 'x86' }
                0x8664 { return 'x64' }
                0xAA64 { return 'ARM64' }
                default { return ('Unknown (0x{0:X4})' -f $machine) }
            }
        } finally { $stream.Dispose() }
    } catch { return 'Unknown' }
}

function Get-SignerName {
    param($Signature)
    try {
        if ($null -eq $Signature -or $null -eq $Signature.SignerCertificate) { return 'Not available' }
        $simple = $Signature.SignerCertificate.GetNameInfo([System.Security.Cryptography.X509Certificates.X509NameType]::SimpleName,$false)
        return Get-SafeText $simple 'Not available'
    } catch { return 'Not available' }
}

function Invoke-InstallerRecognition {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Path)

    $stage = 'Input validation'
    try {
        $cleanPath = [Environment]::ExpandEnvironmentVariables((Get-SafeText $Path '').Trim('"'))
        if ([string]::IsNullOrWhiteSpace($cleanPath)) { throw 'Installer path is empty.' }
        if (-not (Test-Path -LiteralPath $cleanPath -PathType Leaf)) { throw "Installer not found: $cleanPath" }

        $file = Get-Item -LiteralPath $cleanPath -ErrorAction Stop
        $extension = $file.Extension.ToLowerInvariant()
        if ($extension -ne '.exe' -and $extension -ne '.msi') { throw 'This milestone supports only EXE and MSI files.' }

        $stage = 'File metadata collection'
        $versionInfo = $file.VersionInfo
        $publisher = Get-SafeText $versionInfo.CompanyName 'Unknown publisher'
        $product = Get-SafeText $versionInfo.ProductName (Get-SafeText $versionInfo.FileDescription $file.BaseName)
        $productVersion = Get-SafeText $versionInfo.ProductVersion (Get-SafeText $versionInfo.FileVersion 'Unknown')
        $fileVersion = Get-SafeText $versionInfo.FileVersion 'Unknown'
        $description = Get-SafeText $versionInfo.FileDescription 'Unknown'
        $originalFilename = Get-SafeText $versionInfo.OriginalFilename 'Unknown'
        $language = Get-SafeText $versionInfo.Language 'Unknown'

        $stage = 'Integrity collection'
        $sha256 = (Get-FileHash -LiteralPath $cleanPath -Algorithm SHA256 -ErrorAction Stop).Hash

        $stage = 'Signature inspection'
        $signatureStatus = 'Not checked'
        $signer = 'Not available'
        try {
            $signature = Get-AuthenticodeSignature -LiteralPath $cleanPath -ErrorAction Stop
            $signatureStatus = Get-SafeText $signature.Status 'Unknown'
            $signer = Get-SignerName $signature
            if ($publisher -eq 'Unknown publisher' -and $signer -ne 'Not available') { $publisher = $signer }
        } catch {
            $signatureStatus = 'Unable to inspect'
        }

        $stage = 'Installer classification'
        if ($extension -eq '.msi') {
            $installerType = 'Windows Installer Package (MSI)'
            $architecture = 'Database-defined / not evaluated in this milestone'
        } else {
            $installerType = 'Windows Executable Installer (EXE)'
            $architecture = Get-PeArchitecture -Path $cleanPath
        }

        $result = [ordered]@{}
        $result.success = $true
        $result.path = $file.FullName
        $result.fileName = $file.Name
        $result.extension = $extension
        $result.sizeBytes = [Int64]$file.Length
        $result.sizeDisplay = ('{0:N2} MB' -f ($file.Length / 1MB))
        $result.createdUtc = $file.CreationTimeUtc.ToString('o')
        $result.modifiedUtc = $file.LastWriteTimeUtc.ToString('o')
        $result.publisher = $publisher
        $result.product = $product
        $result.productVersion = $productVersion
        $result.fileVersion = $fileVersion
        $result.description = $description
        $result.originalFilename = $originalFilename
        $result.language = $language
        $result.architecture = $architecture
        $result.installerType = $installerType
        $result.signatureStatus = $signatureStatus
        $result.signer = $signer
        $result.sha256 = $sha256
        $result.scope = 'Recognition only. No command discovery, execution, confidence scoring, vendor rules or product-specific logic is active in this milestone.'
        return [pscustomobject]$result
    }
    catch {
        $exception = $_.Exception
        $detail = [ordered]@{}
        $detail.stage = $stage
        $detail.engine = 'RecognitionEngine'
        $detail.function = 'Invoke-InstallerRecognition'
        $detail.exceptionType = $exception.GetType().FullName
        $detail.message = $exception.Message
        $detail.scriptLine = $_.InvocationInfo.ScriptLineNumber
        $detail.positionMessage = $_.InvocationInfo.PositionMessage
        $wrapped = New-Object System.Exception("Recognition failed during '$stage': $($exception.Message)",$exception)
        $wrapped.Data['RecognitionError'] = ($detail | ConvertTo-Json -Depth 4 -Compress)
        throw $wrapped
    }
}

Export-ModuleMember -Function Invoke-InstallerRecognition
