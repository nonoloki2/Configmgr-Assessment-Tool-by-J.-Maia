﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
try { Add-Type -AssemblyName System.Net.Http -ErrorAction Stop } catch { }

$script:SilentInstallHqBase = 'https://silentinstallhq.com'
$script:SilentInstallHqUserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36'

function Set-TlsForWebRequests {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }
}

function Invoke-HttpGetWithHardTimeout {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Url,[int]$TimeoutSeconds=12)
    Set-TlsForWebRequests
    $handler = New-Object System.Net.Http.HttpClientHandler
    $handler.AllowAutoRedirect = $true
    $handler.AutomaticDecompression = [System.Net.DecompressionMethods]::GZip -bor [System.Net.DecompressionMethods]::Deflate
    $client = New-Object System.Net.Http.HttpClient($handler)
    try {
        $client.Timeout=[TimeSpan]::FromSeconds($TimeoutSeconds)
        $client.DefaultRequestHeaders.UserAgent.ParseAdd($script:SilentInstallHqUserAgent)
        $client.DefaultRequestHeaders.Accept.ParseAdd('text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8')
        $response=$client.GetAsync($Url).GetAwaiter().GetResult()
        if(-not $response.IsSuccessStatusCode){ throw "HTTP $([int]$response.StatusCode) ($($response.ReasonPhrase)) from $Url" }
        return $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
    } catch [System.Threading.Tasks.TaskCanceledException] {
        throw "Request to $Url timed out after $TimeoutSeconds seconds. Check proxy, firewall or Internet access."
    } finally { $client.Dispose(); $handler.Dispose() }
}

function ConvertTo-PlainTextFromHtml {
    param([Parameter(Mandatory=$true)][string]$Html)
    $t=$Html -replace '(?is)<script.*?</script>','' -replace '(?is)<style.*?</style>',''
    $t=$t -replace '(?i)<br\s*/?>',"`n" -replace '(?i)</(tr|td|th|p|div|li|h[1-6]|pre|code)>',"`n"
    $t=$t -replace '<[^>]+>',' '
    $t=[System.Net.WebUtility]::HtmlDecode($t) -replace "\u00a0",' '
    $lines=($t -split "`r?`n") | ForEach-Object { ($_ -replace '[ \t]+',' ').Trim() } | Where-Object { $_ }
    return ($lines -join "`n")
}

function ConvertTo-CleanCommand {
    param([string]$Value)
    if([string]::IsNullOrWhiteSpace($Value)){ return $null }
    $v=[System.Net.WebUtility]::HtmlDecode($Value)
    $v=$v -replace '(?is)<br\s*/?>',' ' -replace '<[^>]+>',' '
    $v=($v -replace '[\r\n\t]+',' ' -replace ' {2,}',' ').Trim(' ','`','*',[char]0x201c,[char]0x201d)
    $v=$v -replace '\s+(Silent Uninstall Switch|Repair Command|Download Link|PowerShell Script|Detection Script|PSADT.*)$',''
    if($v.Length -lt 3){ return $null }
    return $v
}

function Get-SearchResultsFromHtml {
    param([Parameter(Mandatory=$true)][string]$Html,[int]$MaxResults=8)
    $seen=@{}; $results=@()
    $rx='(?is)<a\b[^>]*href=["''](?<url>https?://silentinstallhq\.com/[^"''#?]+/)["''][^>]*>(?<text>.*?)</a>'
    foreach($m in [regex]::Matches($Html,$rx)){
        $url=$m.Groups['url'].Value.TrimEnd('/')+'/'
        if($url -notmatch 'silent-install|silent-uninstall|how-to-guide'){ continue }
        if($seen.ContainsKey($url)){ continue }
        $title=ConvertTo-PlainTextFromHtml $m.Groups['text'].Value
        if([string]::IsNullOrWhiteSpace($title)){ continue }
        $seen[$url]=$true
        $results += [pscustomobject]@{title=$title;url=$url}
        if($results.Count -ge $MaxResults){ break }
    }
    return @($results)
}

function Invoke-SilentInstallHqSearch {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Query,[int]$MaxResults=8,[int]$TimeoutSeconds=12)
    if([string]::IsNullOrWhiteSpace($Query)){ return @() }
    $encoded=[Uri]::EscapeDataString($Query.Trim())
    # Primary: WordPress REST search. Secondary: public website search page.
    try {
        $endpoint="$script:SilentInstallHqBase/wp-json/wp/v2/search?search=$encoded&per_page=$MaxResults&subtype=post"
        $raw=(Invoke-HttpGetWithHardTimeout -Url $endpoint -TimeoutSeconds $TimeoutSeconds) | ConvertFrom-Json
        $items=@($raw | Where-Object { $_.url -like "$script:SilentInstallHqBase/*" })
        if($items.Count -gt 0){
            return @($items | ForEach-Object { [pscustomobject]@{title=[System.Net.WebUtility]::HtmlDecode([string]$_.title);url=[string]$_.url} })
        }
    } catch { }
    $html=Invoke-HttpGetWithHardTimeout -Url "$script:SilentInstallHqBase/?s=$encoded" -TimeoutSeconds $TimeoutSeconds
    return @(Get-SearchResultsFromHtml -Html $html -MaxResults $MaxResults)
}

function Get-SilentInstallHqPageContent {
    [CmdletBinding()] param([Parameter(Mandatory=$true)][string]$Url,[int]$TimeoutSeconds=12)
    if($Url -notlike "$script:SilentInstallHqBase/*"){ throw 'Only silentinstallhq.com URLs are allowed.' }
    Invoke-HttpGetWithHardTimeout -Url $Url -TimeoutSeconds $TimeoutSeconds
}

function Get-CommandsForLabelFromHtml {
    param([string]$Html,[string]$LabelPattern)
    $found=@()
    foreach($row in [regex]::Matches($Html,'(?is)<tr\b[^>]*>(?<row>.*?)</tr>')){
        $rowHtml=$row.Groups['row'].Value
        $rowText=ConvertTo-PlainTextFromHtml $rowHtml
        if($rowText -notmatch "(?i)$LabelPattern"){ continue }
        $codes=@([regex]::Matches($rowHtml,'(?is)<(?:code|pre)\b[^>]*>(?<cmd>.*?)</(?:code|pre)>') | ForEach-Object { ConvertTo-CleanCommand $_.Groups['cmd'].Value } | Where-Object { $_ })
        if($codes.Count -eq 0){
            $candidate=$rowText -replace "(?is)^.*?$LabelPattern\s*:?\s*",''
            $candidate=ConvertTo-CleanCommand $candidate
            if($candidate){ $codes=@($candidate) }
        }
        $found += $codes
    }
    # Some articles use paragraphs instead of tables.
    $plain=ConvertTo-PlainTextFromHtml $Html
    $lines=@($plain -split "`n")
    for($i=0;$i -lt $lines.Count;$i++){
        if($lines[$i] -match "(?i)^\s*$LabelPattern\s*:?\s*(.*)$"){
            $candidate=$Matches[1]
            if([string]::IsNullOrWhiteSpace($candidate) -and $i+1 -lt $lines.Count){ $candidate=$lines[$i+1] }
            $candidate=ConvertTo-CleanCommand $candidate
            if($candidate){ $found += $candidate }
        }
    }
    return @($found | Where-Object { $_ } | Select-Object -Unique)
}

function Get-SilentInstallHqCommandsFromHtml {
    [CmdletBinding()] param([Parameter(Mandatory=$true)][string]$Html,[Parameter(Mandatory=$true)][string]$Url)
    $installs=Get-CommandsForLabelFromHtml -Html $Html -LabelPattern 'Silent Install Switch(?:\s*\([^)]*\))?'
    $uninstalls=Get-CommandsForLabelFromHtml -Html $Html -LabelPattern 'Silent Uninstall Switch(?:\s*\([^)]*\))?'
    $titleMatch=[regex]::Match($Html,'(?is)<title>(.*?)</title>')
    $title=if($titleMatch.Success){ (ConvertTo-PlainTextFromHtml $titleMatch.Groups[1].Value) -replace '\s*[-|]\s*Silent Install HQ\s*$','' }else{$Url}
    [pscustomobject]@{url=$Url;title=$title.Trim();installCandidates=@($installs);uninstallCandidates=@($uninstalls);found=(($installs.Count+$uninstalls.Count)-gt 0)}
}

function Invoke-SilentInstallHqLookup {
    [CmdletBinding()] param([Parameter(Mandatory=$true)][string]$ProductQuery,[int]$MaxCandidatePages=5)
    $stage='Search'
    try {
        $clean=$ProductQuery.Trim()
        if([string]::IsNullOrWhiteSpace($clean)){ throw 'Enter a product name to search.' }
        $search=@(Invoke-SilentInstallHqSearch -Query $clean -MaxResults 10)
        if($search.Count -eq 0){ return [pscustomobject]@{success=$true;found=$false;query=$clean;message="No Silent Install HQ article was found for '$clean'.";results=@()} }
        $stage='Extract'; $picked=@(); $visited=0
        foreach($candidate in $search){
            if($visited -ge $MaxCandidatePages){ break }; $visited++
            try {
                $parsed=Get-SilentInstallHqCommandsFromHtml -Html (Get-SilentInstallHqPageContent -Url $candidate.url) -Url $candidate.url
                if($parsed.found){ $picked += $parsed }
            } catch { continue }
        }
        if($picked.Count -eq 0){ return [pscustomobject]@{success=$true;found=$false;query=$clean;message="Articles were found for '$clean', but no labeled Silent Install/Uninstall Switch could be extracted automatically.";results=@($search | Select-Object -First $MaxCandidatePages)} }
        return [pscustomobject]@{success=$true;found=$true;query=$clean;results=@($picked)}
    } catch {
        $ex=$_.Exception
        $detail=[ordered]@{stage=$stage;engine='OnlineLookupEngine';function='Invoke-SilentInstallHqLookup';exceptionType=$ex.GetType().FullName;message=$ex.Message;scriptLine=$_.InvocationInfo.ScriptLineNumber;positionMessage=$_.InvocationInfo.PositionMessage}
        $wrapped=New-Object System.Exception("Online lookup failed during '$stage': $($ex.Message)",$ex)
        $wrapped.Data['RecognitionError']=($detail|ConvertTo-Json -Depth 4 -Compress)
        throw $wrapped
    }
}

Export-ModuleMember -Function Invoke-SilentInstallHqLookup,Invoke-SilentInstallHqSearch,Get-SilentInstallHqPageContent,Get-SilentInstallHqCommandsFromHtml,ConvertTo-PlainTextFromHtml
