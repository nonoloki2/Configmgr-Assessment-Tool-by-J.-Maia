﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function ConvertTo-SafeFolderName {
    param([string]$Value)
    $name = if ([string]::IsNullOrWhiteSpace($Value)) { 'Application_Package' } else { $Value.Trim() }
    foreach ($c in [IO.Path]::GetInvalidFileNameChars()) { $name = $name.Replace([string]$c, '_') }
    $name = ($name -replace '\s+', '_') -replace '_+', '_'
    $name = $name.Trim(' ','.','_')
    if ([string]::IsNullOrWhiteSpace($name)) { return 'Application_Package' }
    return $name
}

function ConvertTo-PowerShellSingleQuotedLiteral {
    param([AllowNull()][string]$Value)
    if ($null -eq $Value) { return "''" }
    return "'" + $Value.Replace("'", "''") + "'"
}

function Get-CommandExecutableAndArguments {
    param([Parameter(Mandatory)][string]$Command)
    $trimmed = $Command.Trim()
    if ($trimmed -match '^"([^"]+)"\s*(.*)$') {
        return [pscustomobject]@{ Executable=$matches[1]; Arguments=$matches[2] }
    }
    if ($trimmed -match '^(\S+)\s*(.*)$') {
        return [pscustomobject]@{ Executable=$matches[1]; Arguments=$matches[2] }
    }
    throw 'Unable to split the command into executable and arguments.'
}

function New-InstallScriptContent {
    param(
        [Parameter(Mandatory)][string]$InstallerFileName,
        [Parameter(Mandatory)][string]$InstallCommand
    )
    $split = Get-CommandExecutableAndArguments -Command $InstallCommand
    $originalExe = [IO.Path]::GetFileName($split.Executable)
    $relativeExe = if ($originalExe -ieq $InstallerFileName) { "Join-Path `$PSScriptRoot 'Source\\$InstallerFileName'" } else { ConvertTo-PowerShellSingleQuotedLiteral $split.Executable }
    $argsLiteral = ConvertTo-PowerShellSingleQuotedLiteral $split.Arguments
@"
#requires -Version 5.1
[CmdletBinding()]
param()

Set-StrictMode -Version Latest
`$ErrorActionPreference = 'Stop'
`$logDirectory = Join-Path `$PSScriptRoot 'Logs'
New-Item -ItemType Directory -Path `$logDirectory -Force | Out-Null
`$logFile = Join-Path `$logDirectory 'Install.log'

function Write-PackageLog {
    param([string]`$Message)
    Add-Content -LiteralPath `$logFile -Value ("{0:u} {1}" -f (Get-Date), `$Message) -Encoding UTF8
}

try {
    `$installer = $relativeExe
    `$arguments = $argsLiteral
    if (-not (Test-Path -LiteralPath `$installer -PathType Leaf)) {
        throw "Installer not found: `$installer"
    }

    Write-PackageLog "Starting: `"`$installer`" `$arguments"
    `$process = Start-Process -FilePath `$installer -ArgumentList `$arguments -Wait -PassThru -WindowStyle Hidden
    Write-PackageLog "Installer exit code: `$(`$process.ExitCode)"

    if (`$process.ExitCode -in @(0,1641,3010)) {
        exit `$process.ExitCode
    }

    throw "Installation failed with exit code `$(`$process.ExitCode)."
}
catch {
    Write-PackageLog "ERROR: `$(`$_.Exception.Message)"
    exit 1
}
"@
}

function New-UninstallScriptContent {
    param([Parameter(Mandatory)][string]$UninstallCommand)
    $split = Get-CommandExecutableAndArguments -Command $UninstallCommand
    $exeLiteral = ConvertTo-PowerShellSingleQuotedLiteral $split.Executable
    $argsLiteral = ConvertTo-PowerShellSingleQuotedLiteral $split.Arguments
@"
#requires -Version 5.1
[CmdletBinding()]
param()

Set-StrictMode -Version Latest
`$ErrorActionPreference = 'Stop'
`$logDirectory = Join-Path `$PSScriptRoot 'Logs'
New-Item -ItemType Directory -Path `$logDirectory -Force | Out-Null
`$logFile = Join-Path `$logDirectory 'Uninstall.log'

function Write-PackageLog {
    param([string]`$Message)
    Add-Content -LiteralPath `$logFile -Value ("{0:u} {1}" -f (Get-Date), `$Message) -Encoding UTF8
}

try {
    `$executable = $exeLiteral
    `$arguments = $argsLiteral
    Write-PackageLog "Starting: `"`$executable`" `$arguments"
    `$process = Start-Process -FilePath `$executable -ArgumentList `$arguments -Wait -PassThru -WindowStyle Hidden
    Write-PackageLog "Uninstaller exit code: `$(`$process.ExitCode)"

    if (`$process.ExitCode -in @(0,1605,1614,1641,3010)) {
        exit `$process.ExitCode
    }

    throw "Uninstallation failed with exit code `$(`$process.ExitCode)."
}
catch {
    Write-PackageLog "ERROR: `$(`$_.Exception.Message)"
    exit 1
}
"@
}

function New-PackageReportHtml {
    param(
        [Parameter(Mandatory)]$Recognition,
        [Parameter(Mandatory)]$Evidence,
        [Parameter(Mandatory)][string]$PackageName,
        [string]$ClientName,
        [string]$PreparedBy
    )
    function ConvertTo-HtmlSafe {
        param([AllowNull()][object]$Value)
        return [Net.WebUtility]::HtmlEncode([string]$Value)
    }
    $best = $Evidence.bestMatch
    $javaRows = @($Evidence.javaEvidence | ForEach-Object { "<tr><td>$(ConvertTo-HtmlSafe $_.path)</td><td>$(ConvertTo-HtmlSafe $_.currentVersion)</td><td>$(ConvertTo-HtmlSafe $_.javaHome)</td></tr>" }) -join "`n"
    if ([string]::IsNullOrWhiteSpace($javaRows)) { $javaRows = '<tr><td colspan="3">No JavaSoft evidence captured.</td></tr>' }
    $detection = ConvertTo-HtmlSafe $Evidence.detectionScript
@"
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>$(ConvertTo-HtmlSafe $PackageName) - Packaging Report</title>
<style>
body{font-family:Segoe UI,Arial;background:#071525;color:#edf6ff;margin:0;padding:32px}main{max-width:1100px;margin:auto}.card{background:#0d2137;border:1px solid #1c3b59;border-radius:16px;padding:22px;margin-bottom:18px}h1,h2{margin-top:0}.meta{color:#8fa8c2}table{width:100%;border-collapse:collapse}th,td{text-align:left;border-bottom:1px solid #1c3b59;padding:10px;vertical-align:top}code,pre{background:#061624;border:1px solid #1c3b59;border-radius:9px;padding:12px;display:block;overflow:auto;color:#8be9fd;white-space:pre-wrap}.ok{color:#63e6ad}.warn{color:#ffd88f}footer{color:#8fa8c2;font-size:12px;margin-top:24px}
</style></head><body><main>
<div class="card"><h1>$(ConvertTo-HtmlSafe $PackageName)</h1><div class="meta">Enterprise Application Packaging Report</div><p>Client: <b>$(ConvertTo-HtmlSafe $ClientName)</b><br>Prepared by: <b>$(ConvertTo-HtmlSafe $PreparedBy)</b><br>Generated: <b>$(ConvertTo-HtmlSafe (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))</b></p></div>
<div class="card"><h2>Recognition</h2><table>
<tr><th>Product</th><td>$(ConvertTo-HtmlSafe $Recognition.product)</td><th>Version</th><td>$(ConvertTo-HtmlSafe $Recognition.productVersion)</td></tr>
<tr><th>Publisher</th><td>$(ConvertTo-HtmlSafe $Recognition.publisher)</td><th>Architecture</th><td>$(ConvertTo-HtmlSafe $Recognition.architecture)</td></tr>
<tr><th>Installer</th><td>$(ConvertTo-HtmlSafe $Recognition.fileName)</td><th>Engine</th><td>$(ConvertTo-HtmlSafe $Recognition.detectedEngine)</td></tr>
<tr><th>SHA256</th><td colspan="3">$(ConvertTo-HtmlSafe $Recognition.sha256)</td></tr></table></div>
<div class="card"><h2>Validated Commands</h2><h3>Install</h3><code>$(ConvertTo-HtmlSafe $Recognition.installCommand)</code><h3>Uninstall</h3><code>$(ConvertTo-HtmlSafe $Evidence.exactUninstallCommand)</code></div>
<div class="card"><h2>Observed Installation Evidence</h2><table>
<tr><th>Exit code</th><td>$(ConvertTo-HtmlSafe $Evidence.exitCode)</td><th>ProductCode</th><td>$(ConvertTo-HtmlSafe $Evidence.productCode)</td></tr>
<tr><th>Display name</th><td>$(ConvertTo-HtmlSafe $best.displayName)</td><th>Display version</th><td>$(ConvertTo-HtmlSafe $best.displayVersion)</td></tr>
<tr><th>Publisher</th><td>$(ConvertTo-HtmlSafe $best.publisher)</td><th>Registry path</th><td>$(ConvertTo-HtmlSafe $best.registryPath)</td></tr></table></div>
<div class="card"><h2>Java Evidence</h2><table><tr><th>Registry path</th><th>CurrentVersion</th><th>JavaHome</th></tr>$javaRows</table></div>
<div class="card"><h2>SCCM Detection Script</h2><pre>$detection</pre></div>
<div class="card"><h2>Deployment Notes</h2><p class="warn">Validate all generated scripts in a packaging VM before production deployment. Exit codes 1641 and 3010 indicate restart behavior and must be handled according to the deployment standard.</p></div>
<footer>Generated by Enterprise Application Packaging Studio · Phoenix</footer>
</main></body></html>
"@
}

function Export-PackagingBundle {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$DestinationRoot,
        [Parameter(Mandatory)][string]$PackageName,
        [Parameter(Mandatory)]$Recognition,
        [Parameter(Mandatory)]$Evidence,
        [bool]$CopyInstaller = $true,
        [string]$ClientName = '',
        [string]$PreparedBy = ''
    )

    if ([string]::IsNullOrWhiteSpace($DestinationRoot)) { throw 'Destination root folder is required.' }
    if (-not (Test-Path -LiteralPath $DestinationRoot -PathType Container)) {
        New-Item -ItemType Directory -Path $DestinationRoot -Force | Out-Null
    }
    if (-not $Recognition.path -or -not (Test-Path -LiteralPath ([string]$Recognition.path) -PathType Leaf)) {
        throw 'The original installer path is unavailable.'
    }
    if (-not $Evidence.exactUninstallCommand) { throw 'Exact uninstall evidence is required before package generation.' }
    if (-not $Evidence.detectionScript) { throw 'A detection script is required before package generation.' }

    $safeName = ConvertTo-SafeFolderName $PackageName
    $packageRoot = Join-Path $DestinationRoot $safeName
    $sourceDir = Join-Path $packageRoot 'Source'
    $logsDir = Join-Path $packageRoot 'Logs'
    New-Item -ItemType Directory -Path $sourceDir,$logsDir -Force | Out-Null

    $installerName = [IO.Path]::GetFileName([string]$Recognition.path)
    if ($CopyInstaller) {
        Copy-Item -LiteralPath ([string]$Recognition.path) -Destination (Join-Path $sourceDir $installerName) -Force
    }

    $installScript = New-InstallScriptContent -InstallerFileName $installerName -InstallCommand ([string]$Recognition.installCommand)
    $uninstallScript = New-UninstallScriptContent -UninstallCommand ([string]$Evidence.exactUninstallCommand)
    $detectionScript = [string]$Evidence.detectionScript

    Set-Content -LiteralPath (Join-Path $packageRoot 'Install.ps1') -Value $installScript -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $packageRoot 'Uninstall.ps1') -Value $uninstallScript -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $packageRoot 'Detection.ps1') -Value $detectionScript -Encoding UTF8

    $manifest = [ordered]@{
        schemaVersion = '1.0'
        generatedAt = (Get-Date).ToString('o')
        packageName = $PackageName
        clientName = $ClientName
        preparedBy = $PreparedBy
        source = [ordered]@{ originalPath=$Recognition.path; fileName=$installerName; copied=$CopyInstaller; sha256=$Recognition.sha256 }
        recognition = $Recognition
        observedEvidence = $Evidence
        generatedFiles = @('Install.ps1','Uninstall.ps1','Detection.ps1','Packaging-Report.html','Package-Manifest.json','Source','Logs')
        sccm = [ordered]@{
            installProgram = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install.ps1'
            uninstallProgram = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Uninstall.ps1'
            detectionScript = 'Detection.ps1'
            installBehavior = 'Install for system'
            logonRequirement = 'Whether or not a user is logged on'
        }
    }
    $manifest | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath (Join-Path $packageRoot 'Package-Manifest.json') -Encoding UTF8

    $report = New-PackageReportHtml -Recognition $Recognition -Evidence $Evidence -PackageName $PackageName -ClientName $ClientName -PreparedBy $PreparedBy
    Set-Content -LiteralPath (Join-Path $packageRoot 'Packaging-Report.html') -Value $report -Encoding UTF8

    $summary = @"
Package generated successfully.
Package: $PackageName
Folder: $packageRoot
Install: powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install.ps1
Uninstall: powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Uninstall.ps1
Detection: Detection.ps1
"@
    Set-Content -LiteralPath (Join-Path $packageRoot 'README.txt') -Value $summary -Encoding UTF8

    [pscustomobject]@{
        success = $true
        packageName = $PackageName
        packageRoot = $packageRoot
        files = @(Get-ChildItem -LiteralPath $packageRoot -Recurse -File | ForEach-Object { $_.FullName.Substring($packageRoot.Length).TrimStart('\') })
        installProgram = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install.ps1'
        uninstallProgram = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Uninstall.ps1'
    }
}

Export-ModuleMember -Function Export-PackagingBundle
