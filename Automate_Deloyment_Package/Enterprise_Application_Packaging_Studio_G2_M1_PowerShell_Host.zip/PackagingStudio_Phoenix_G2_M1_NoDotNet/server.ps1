# Enterprise Application Packaging Studio - Phoenix Core
# No .NET SDK, compilation, Kestrel, IIS, Node.js or external module required.
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$Host.UI.RawUI.WindowTitle = 'Enterprise Application Packaging Studio - Phoenix Core'

$log = Join-Path $PSScriptRoot 'phoenix-server.log'
function Log([string]$m) { $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $m"; Add-Content -LiteralPath $log -Value $line -Encoding UTF8; Write-Host $line }
function Json($obj) { return ($obj | ConvertTo-Json -Depth 12 -Compress) }
function Send($ctx,[int]$code,[string]$type,[byte[]]$bytes) {
  $ctx.Response.StatusCode=$code; $ctx.Response.ContentType=$type; $ctx.Response.ContentLength64=$bytes.Length
  $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length); $ctx.Response.OutputStream.Close()
}
function SendText($ctx,[int]$code,[string]$type,[string]$text) { Send $ctx $code $type ([Text.Encoding]::UTF8.GetBytes($text)) }
function GuessMime([string]$p) { switch ([IO.Path]::GetExtension($p).ToLowerInvariant()) { '.html' {'text/html; charset=utf-8'} '.css' {'text/css; charset=utf-8'} '.js' {'application/javascript; charset=utf-8'} '.json' {'application/json; charset=utf-8'} '.png' {'image/png'} '.svg' {'image/svg+xml'} default {'application/octet-stream'} } }
function Ev($category,$source,$label,$value,$weight,$positive=$true) { [ordered]@{category=$category;source=$source;label=$label;value=$value;weight=[double]$weight;positive=[bool]$positive} }
function Cand($arguments,$confidence,$source,$explanation) { [ordered]@{arguments=$arguments;confidence=[double]$confidence;source=$source;explanation=$explanation} }
function Node($step,$result,$status,$explanation) { [ordered]@{step=$step;result=$result;status=$status;explanation=$explanation} }

function Analyze-Installer([string]$Path) {
  $Path = [Environment]::ExpandEnvironmentVariables($Path.Trim().Trim('"'))
  if(-not (Test-Path -LiteralPath $Path -PathType Leaf)){ throw "Installer not found: $Path" }
  $file = Get-Item -LiteralPath $Path
  $ext = $file.Extension.ToLowerInvariant()
  if($ext -notin '.exe','.msi'){ throw 'Only EXE and MSI installers are supported in this milestone.' }
  $vi = $file.VersionInfo
  $sig = $null; try { $sig = Get-AuthenticodeSignature -LiteralPath $Path } catch {}
  $publisher = if($vi.CompanyName){$vi.CompanyName.Trim()}elseif($sig.SignerCertificate.Subject -match 'CN=([^,]+)'){$matches[1]}else{'Unknown publisher'}
  $product = if($vi.ProductName){$vi.ProductName.Trim()}elseif($vi.FileDescription){$vi.FileDescription.Trim()}else{$file.BaseName}
  $version = if($vi.ProductVersion){$vi.ProductVersion.Trim()}elseif($vi.FileVersion){$vi.FileVersion.Trim()}else{'Unknown'}
  $name = $file.Name.ToLowerInvariant(); $combo = "$publisher $product $name".ToLowerInvariant()
  $family='Unknown'; $framework=if($ext -eq '.msi'){'Windows Installer (MSI)'}else{'EXE Bootstrapper'}; $arch='Unknown'; $embedded=$false
  if($name -match '(x64|amd64|win64|64-bit|windows-x86_64)'){$arch='x64'}elseif($name -match '(x86|i586|win32|32-bit)'){$arch='x86'}
  $evidence = New-Object System.Collections.Generic.List[object]
  $candidates = New-Object System.Collections.Generic.List[object]
  $ruleSource='Generic heuristic'; $rec=45.0; $ins=55.0; $cmd=45.0
  $evidence.Add((Ev 'Identity' 'Version resource' 'Publisher' $publisher (if($publisher -ne 'Unknown publisher'){20}else{2}) ($publisher -ne 'Unknown publisher')))
  $evidence.Add((Ev 'Identity' 'Version resource' 'Product' $product (if($product){18}else{2}) ([bool]$product)))
  $evidence.Add((Ev 'Identity' 'Version resource' 'Version' $version (if($version -ne 'Unknown'){12}else{2}) ($version -ne 'Unknown')))
  if($sig -and $sig.Status -eq 'Valid'){ $rec += 18; $evidence.Add((Ev 'Security' 'Authenticode' 'Digital signature' "Valid - $($sig.SignerCertificate.Subject)" 18 $true)) }
  elseif($sig){ $evidence.Add((Ev 'Security' 'Authenticode' 'Digital signature' $sig.Status 4 $false)) }

  if($combo -match 'oracle|java|jre-8u'){
    $family='Java Runtime Environment 8'; $framework='Oracle Java Bootstrapper'; $embedded=$true; $ruleSource='Oracle Java vendor rule'; $rec=98; $ins=92; $cmd=98
    $candidates.Add((Cand '/s' 98 'Oracle Java vendor rule' 'Lowercase /s is prioritized for the Java 8 offline installer.'))
    $candidates.Add((Cand 'INSTALLCFG=".\java-install.cfg"' 94 'Oracle Java configuration strategy' 'Uses a local configuration file when additional enterprise controls are required.'))
    $candidates.Add((Cand '/S' 15 'Generic NSIS fallback' 'Low confidence because Java may reject the uppercase variant.'))
    $evidence.Add((Ev 'Vendor rule' 'Local rule pack' 'Oracle Java family match' 'Publisher, product or filename matched Java 8 patterns.' 30 $true))
  } elseif($combo -match 'citrix.*workspace|workspace.*citrix'){
    $family='Citrix Workspace'; $framework='Citrix Bootstrapper'; $ruleSource='Citrix Workspace vendor rule'; $rec=97; $ins=94; $cmd=96
    $candidates.Add((Cand '/silent /noreboot' 96 'Citrix Workspace vendor rule' 'Validated strategy family for Citrix Workspace installers.'))
    $candidates.Add((Cand '/silent' 90 'Citrix Workspace fallback' 'Silent installation without explicit reboot suppression.'))
    $evidence.Add((Ev 'Vendor rule' 'Local rule pack' 'Citrix Workspace match' 'Publisher and product naming matched Citrix Workspace.' 28 $true))
  } elseif($combo -match '7-zip|7zip'){
    $family='7-Zip'; $framework=if($ext -eq '.msi'){'Windows Installer (MSI)'}else{'7-Zip EXE Installer'}; $ruleSource='7-Zip vendor rule'; $rec=98; $ins=96; $cmd=96
    if($ext -eq '.msi'){$candidates.Add((Cand '/qn /norestart' 98 'MSI standard' 'Use with msiexec.exe /i.'))}else{$candidates.Add((Cand '/S' 96 '7-Zip vendor rule' '7-Zip EXE installer silent switch.'))}
    $evidence.Add((Ev 'Vendor rule' 'Local rule pack' '7-Zip match' 'Product identity matched 7-Zip.' 30 $true))
  } elseif($ext -eq '.msi'){
    $family='MSI Application'; $framework='Windows Installer (MSI)'; $ruleSource='Windows Installer standard'; $rec=[Math]::Max($rec,80); $ins=99; $cmd=98
    $candidates.Add((Cand '/qn /norestart' 98 'Windows Installer standard' 'Use with msiexec.exe /i.'))
    $candidates.Add((Cand '/passive /norestart' 82 'Windows Installer fallback' 'Reduced UI fallback.'))
    $evidence.Add((Ev 'Installer' 'File extension' 'MSI package' 'Native Windows Installer database.' 30 $true))
  } else {
    $candidates.Add((Cand '/quiet /norestart' 60 'Generic EXE heuristic' 'Common bootstrapper convention; laboratory validation required.'))
    $candidates.Add((Cand '/silent /norestart' 55 'Generic EXE heuristic' 'Common silent convention; laboratory validation required.'))
    $candidates.Add((Cand '/S' 48 'Generic framework heuristic' 'Potential NSIS-style switch; low confidence until validated.'))
  }
  $hash=(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash
  $dnaInput="$publisher|$family|$framework|$arch|$($vi.OriginalFilename)"
  $sha=[Security.Cryptography.SHA256]::Create(); $dnaBytes=$sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($dnaInput)); $dna=([BitConverter]::ToString($dnaBytes).Replace('-','').Substring(0,12) -replace '(.{4})(?=.)','$1-')
  $evidence.Add((Ev 'Integrity' 'SHA256' 'Installer hash' $hash 8 $true))
  $evidence.Add((Ev 'Installer' 'Local heuristic' 'Installer framework' $framework 16 $true))
  $overall=[Math]::Round(($rec*0.45+$ins*0.30+$cmd*0.25),1)
  $gate=[ordered]@{required=75.0;actual=[Math]::Round($rec,1);passed=($rec -ge 75)}
  $tree=@((Node 'File validation' 'Installer accessible' 'PASS' 'The selected installer can be read locally.'),(Node 'Product recognition' $family (if($rec-ge75){'PASS'}else{'REVIEW'}) 'Identity was calculated from version data, signature and filename patterns.'),(Node 'Installer classification' $framework 'PASS' 'The installer technology was classified without executing it.'),(Node 'Rule selection' $ruleSource (if($ruleSource -eq 'Generic heuristic'){'REVIEW'}else{'PASS'}) 'Specific local rules take precedence over generic switches.'),(Node 'Laboratory validation' 'Pending' 'WAITING' 'The recommendation has not yet been executed in this milestone.'))
  [ordered]@{success=$true;path=$Path;publisher=$publisher;product=$product;family=$family;version=$version;architecture=$arch;installerFramework=$framework;embeddedMsi=$embedded;packagingDna=$dna;sha256=$hash;recognitionConfidence=[double]$rec;installerConfidence=[double]$ins;commandConfidence=[double]$cmd;overallConfidence=[double]$overall;recognitionGate=$gate;ruleSource=$ruleSource;suggestedInstallArguments=$candidates[0].arguments;candidates=@($candidates);decisionTree=$tree;evidence=@($evidence)}
}

Set-Content -LiteralPath $log -Value "Phoenix PowerShell host diagnostics`r`n" -Encoding UTF8
$port=5188
while(Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue){$port++}
$prefix="http://127.0.0.1:$port/"
$listener=[Net.HttpListener]::new(); $listener.Prefixes.Add($prefix)
try { $listener.Start() } catch { Log "ERROR starting listener: $($_.Exception.Message)"; Read-Host 'Press Enter'; exit 1 }
Log "PowerShell host ready at $prefix"
Start-Process $prefix
Write-Host ''; Write-Host 'Application is running. Close this window to stop it.' -ForegroundColor Cyan; Write-Host ''
$root=(Resolve-Path (Join-Path $PSScriptRoot 'wwwroot')).Path
try {
  while($listener.IsListening){
    $ctx=$listener.GetContext()
    try {
      $req=$ctx.Request; $route=$req.Url.AbsolutePath
      if($route -eq '/api/health'){ SendText $ctx 200 'application/json; charset=utf-8' (Json ([ordered]@{status='ready';release='G2-M1 Phoenix Core - PowerShell Host';port=$port})); continue }
      if($route -eq '/api/analyze' -and $req.HttpMethod -eq 'POST'){
        $reader=[IO.StreamReader]::new($req.InputStream,$req.ContentEncoding); $body=$reader.ReadToEnd(); $reader.Close(); $data=$body|ConvertFrom-Json
        try { SendText $ctx 200 'application/json; charset=utf-8' (Json (Analyze-Installer ([string]$data.path))) }
        catch { Log "Analysis error: $($_.Exception.Message)"; SendText $ctx 400 'application/json; charset=utf-8' (Json ([ordered]@{error=$_.Exception.Message})) }
        continue
      }
      $rel=if($route -eq '/'){'index.html'}else{$route.TrimStart('/')}
      $full=[IO.Path]::GetFullPath((Join-Path $root $rel))
      if(-not $full.StartsWith($root,[StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $full -PathType Leaf)){ $full=Join-Path $root 'index.html' }
      Send $ctx 200 (GuessMime $full) ([IO.File]::ReadAllBytes($full))
    } catch { try { SendText $ctx 500 'application/json' (Json ([ordered]@{error=$_.Exception.Message})) } catch {} }
  }
} finally { $listener.Stop(); $listener.Close(); Log 'Server stopped.' }
