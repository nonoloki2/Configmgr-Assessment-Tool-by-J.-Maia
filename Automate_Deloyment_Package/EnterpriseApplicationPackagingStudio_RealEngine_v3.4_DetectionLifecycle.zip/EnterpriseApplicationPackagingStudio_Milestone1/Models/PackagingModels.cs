namespace EnterpriseApplicationPackagingStudio.Models;

public sealed record AnalyzeRequest(bool Refresh = false);
public sealed record ExecuteAttemptRequest(string Phase, string Command, int TimeoutMinutes = 20, bool ConfirmLabMachine = false);
public sealed record GenerateRequest(
    string DetectionType,
    string? DetectionPath,
    string? DetectionValue,
    string? RequiredVersion,
    string? OutputDirectory = null);
public sealed record CommandCandidate(string Command, int Confidence, string Evidence, string Risk = "Low");
public sealed record FileEvidence(string Name, string FullPath, long Size, string Extension, string Sha256, string? FileVersion, string? ProductVersion, string? Company, string SignatureStatus, string? Signer);
public sealed record PackagingAnalysis(
    string InstallerType,
    int Confidence,
    string PrimaryInstaller,
    string Architecture,
    string Vendor,
    string Version,
    string? ProductCode,
    string? UpgradeCode,
    IReadOnlyList<FileEvidence> Files,
    IReadOnlyList<CommandCandidate> InstallCandidates,
    IReadOnlyList<CommandCandidate> UninstallCandidates,
    IReadOnlyList<string> DetectionCandidates,
    IReadOnlyList<string> Findings,
    DateTime AnalyzedAtUtc);
public sealed record AttemptResult(string Phase, string Command, int ExitCode, bool TimedOut, double DurationSeconds, string StdOut, string StdErr, DateTime StartedAtUtc, string Outcome);
public sealed record UninstallRegistryEntry(string Hive, string View, string KeyPath, string KeyName, string? DisplayName, string? DisplayVersion, string? Publisher, string? InstallLocation, string? UninstallString, string? QuietUninstallString, string? ProductCode);
public sealed record SystemBaseline(DateTime CapturedAtUtc, IReadOnlyList<UninstallRegistryEntry> UninstallEntries);
public sealed record DetectionCandidate(string Type, int Confidence, string Evidence, string? RegistryPath, string? ValueName, string? FilePath, string? ProductCode, string? RequiredVersion, string DisplayName);
public sealed record DetectionDiscovery(IReadOnlyList<DetectionCandidate> Candidates, DetectionCandidate? Selected, bool InstalledStateValidated, bool UninstalledStateValidated, DateTime DiscoveredAtUtc);
