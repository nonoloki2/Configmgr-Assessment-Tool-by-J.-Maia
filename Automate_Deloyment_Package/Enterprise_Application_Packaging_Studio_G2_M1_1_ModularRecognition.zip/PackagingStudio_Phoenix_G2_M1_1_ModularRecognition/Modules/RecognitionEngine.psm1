Set-StrictMode -Version 2.0

function Select-Value {
    param($Condition, $WhenTrue, $WhenFalse)
    if ($Condition) { return $WhenTrue }
    return $WhenFalse
}

function New-Evidence {
    param([string]$Category,[string]$Source,[string]$Label,[string]$Value,[double]$Weight,[bool]$Positive=$true)
    [ordered]@{ category=$Category; source=$Source; label=$Label; value=$Value; weight=$Weight; positive=$Positive }
}
function New-Candidate {
    param([string]$Arguments,[double]$Confidence,[string]$Source,[string]$Explanation)
    [ordered]@{ arguments=$Arguments; confidence=$Confidence; source=$Source; explanation=$Explanation }
}
function New-DecisionNode {
    param([string]$Step,[string]$Result,[string]$Status,[string]$Explanation)
    [ordered]@{ step=$Step; result=$Result; status=$Status; explanation=$Explanation }
}
function Get-PackagingDna {
    param([string]$InputText)
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        $bytes = $sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($InputText))
        return (([BitConverter]::ToString($bytes).Replace('-','').Substring(0,12)) -replace '(.{4})(?=.)','$1-')
    } finally { $sha.Dispose() }
}

function Invoke-InstallerRecognition {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Path)

    $stage = 'Input validation'
    try {
        $expandedPath = [Environment]::ExpandEnvironmentVariables($Path.Trim().Trim('"'))
        if ([string]::IsNullOrWhiteSpace($expandedPath)) { throw 'Installer path is empty.' }
        if (-not (Test-Path -LiteralPath $expandedPath -PathType Leaf)) { throw "Installer not found: $expandedPath" }

        $file = Get-Item -LiteralPath $expandedPath -ErrorAction Stop
        $extension = $file.Extension.ToLowerInvariant()
        if ($extension -notin @('.exe','.msi')) { throw 'Only EXE and MSI installers are supported in this milestone.' }

        $stage = 'Metadata collection'
        $versionInfo = $file.VersionInfo
        $signature = $null
        try { $signature = Get-AuthenticodeSignature -LiteralPath $expandedPath -ErrorAction Stop } catch { $signature = $null }

        $publisher = 'Unknown publisher'
        if ($versionInfo.CompanyName) { $publisher = $versionInfo.CompanyName.Trim() }
        elseif ($signature -and $signature.SignerCertificate -and $signature.SignerCertificate.Subject -match 'CN=([^,]+)') { $publisher = $matches[1] }

        if ($versionInfo.ProductName) { $product = $versionInfo.ProductName.Trim() }
        elseif ($versionInfo.FileDescription) { $product = $versionInfo.FileDescription.Trim() }
        else { $product = $file.BaseName }

        if ($versionInfo.ProductVersion) { $version = $versionInfo.ProductVersion.Trim() }
        elseif ($versionInfo.FileVersion) { $version = $versionInfo.FileVersion.Trim() }
        else { $version = 'Unknown' }

        $name = $file.Name.ToLowerInvariant()
        $combo = "$publisher $product $name".ToLowerInvariant()
        $family = 'Unknown'
        $framework = Select-Value ($extension -eq '.msi') 'Windows Installer (MSI)' 'EXE Bootstrapper'
        $architecture = 'Unknown'
        $embeddedMsi = $false
        if ($name -match '(x64|amd64|win64|64-bit|windows-x86_64)') { $architecture='x64' }
        elseif ($name -match '(x86|i586|win32|32-bit)') { $architecture='x86' }

        $evidence = New-Object System.Collections.Generic.List[object]
        $candidates = New-Object System.Collections.Generic.List[object]
        $ruleSource='Generic heuristic'; $recognition=45.0; $installer=55.0; $command=45.0

        $publisherKnown = ($publisher -ne 'Unknown publisher')
        $productKnown = (-not [string]::IsNullOrWhiteSpace($product))
        $versionKnown = ($version -ne 'Unknown')
        $evidence.Add((New-Evidence 'Identity' 'Version resource' 'Publisher' $publisher (Select-Value $publisherKnown 20 2) $publisherKnown))
        $evidence.Add((New-Evidence 'Identity' 'Version resource' 'Product' $product (Select-Value $productKnown 18 2) $productKnown))
        $evidence.Add((New-Evidence 'Identity' 'Version resource' 'Version' $version (Select-Value $versionKnown 12 2) $versionKnown))

        if ($signature -and $signature.Status -eq 'Valid') {
            $recognition += 18
            $subject = Select-Value ($signature.SignerCertificate -ne $null) $signature.SignerCertificate.Subject 'Signer subject unavailable'
            $evidence.Add((New-Evidence 'Security' 'Authenticode' 'Digital signature' "Valid - $subject" 18 $true))
        } elseif ($signature) {
            $evidence.Add((New-Evidence 'Security' 'Authenticode' 'Digital signature' ([string]$signature.Status) 4 $false))
        }

        $stage = 'Vendor rule evaluation'
        if ($combo -match 'oracle|java|jre-8u') {
            $family='Java Runtime Environment 8'; $framework='Oracle Java Bootstrapper'; $embeddedMsi=$true; $ruleSource='Oracle Java vendor rule'; $recognition=98; $installer=92; $command=98
            $candidates.Add((New-Candidate '/s' 98 'Oracle Java vendor rule' 'Lowercase /s is prioritized for the Java 8 offline installer.'))
            $candidates.Add((New-Candidate 'INSTALLCFG=".\java-install.cfg"' 94 'Oracle Java configuration strategy' 'Uses a local configuration file when additional enterprise controls are required.'))
            $candidates.Add((New-Candidate '/S' 15 'Generic NSIS fallback' 'Low confidence because Java may reject the uppercase variant.'))
            $evidence.Add((New-Evidence 'Vendor rule' 'Local rule pack' 'Oracle Java family match' 'Publisher, product or filename matched Java 8 patterns.' 30 $true))
        } elseif ($combo -match 'citrix.*workspace|workspace.*citrix') {
            $family='Citrix Workspace'; $framework='Citrix Bootstrapper'; $ruleSource='Citrix Workspace vendor rule'; $recognition=97; $installer=94; $command=96
            $candidates.Add((New-Candidate '/silent /noreboot' 96 'Citrix Workspace vendor rule' 'Validated strategy family for Citrix Workspace installers.'))
            $candidates.Add((New-Candidate '/silent' 90 'Citrix Workspace fallback' 'Silent installation without explicit reboot suppression.'))
            $evidence.Add((New-Evidence 'Vendor rule' 'Local rule pack' 'Citrix Workspace match' 'Publisher and product naming matched Citrix Workspace.' 28 $true))
        } elseif ($combo -match '7-zip|7zip') {
            $family='7-Zip'; $framework=Select-Value ($extension -eq '.msi') 'Windows Installer (MSI)' '7-Zip EXE Installer'; $ruleSource='7-Zip vendor rule'; $recognition=98; $installer=96; $command=96
            if ($extension -eq '.msi') { $candidates.Add((New-Candidate '/qn /norestart' 98 'MSI standard' 'Use with msiexec.exe /i.')) }
            else { $candidates.Add((New-Candidate '/S' 96 '7-Zip vendor rule' '7-Zip EXE installer silent switch.')) }
            $evidence.Add((New-Evidence 'Vendor rule' 'Local rule pack' '7-Zip match' 'Product identity matched 7-Zip.' 30 $true))
        } elseif ($extension -eq '.msi') {
            $family='MSI Application'; $framework='Windows Installer (MSI)'; $ruleSource='Windows Installer standard'; $recognition=[Math]::Max($recognition,80); $installer=99; $command=98
            $candidates.Add((New-Candidate '/qn /norestart' 98 'Windows Installer standard' 'Use with msiexec.exe /i.'))
            $candidates.Add((New-Candidate '/passive /norestart' 82 'Windows Installer fallback' 'Reduced UI fallback.'))
            $evidence.Add((New-Evidence 'Installer' 'File extension' 'MSI package' 'Native Windows Installer database.' 30 $true))
        } else {
            $candidates.Add((New-Candidate '/quiet /norestart' 60 'Generic EXE heuristic' 'Common bootstrapper convention; laboratory validation required.'))
            $candidates.Add((New-Candidate '/silent /norestart' 55 'Generic EXE heuristic' 'Common silent convention; laboratory validation required.'))
            $candidates.Add((New-Candidate '/S' 48 'Generic framework heuristic' 'Potential NSIS-style switch; low confidence until validated.'))
        }

        $stage = 'Integrity and confidence calculation'
        $hash=(Get-FileHash -LiteralPath $expandedPath -Algorithm SHA256 -ErrorAction Stop).Hash
        $dnaInput="$publisher|$family|$framework|$architecture|$($versionInfo.OriginalFilename)"
        $dna=Get-PackagingDna $dnaInput
        $evidence.Add((New-Evidence 'Integrity' 'SHA256' 'Installer hash' $hash 8 $true))
        $evidence.Add((New-Evidence 'Installer' 'Local heuristic' 'Installer framework' $framework 16 $true))
        $overall=[Math]::Round(($recognition*0.45+$installer*0.30+$command*0.25),1)
        $gate=[ordered]@{required=75.0;actual=[Math]::Round($recognition,1);passed=($recognition -ge 75)}
        $recognitionStatus=Select-Value ($recognition -ge 75) 'PASS' 'REVIEW'
        $ruleStatus=Select-Value ($ruleSource -eq 'Generic heuristic') 'REVIEW' 'PASS'
        $tree=@(
            (New-DecisionNode 'File validation' 'Installer accessible' 'PASS' 'The selected installer can be read locally.'),
            (New-DecisionNode 'Product recognition' $family $recognitionStatus 'Identity was calculated from version data, signature and filename patterns.'),
            (New-DecisionNode 'Installer classification' $framework 'PASS' 'The installer technology was classified without executing it.'),
            (New-DecisionNode 'Rule selection' $ruleSource $ruleStatus 'Specific local rules take precedence over generic switches.'),
            (New-DecisionNode 'Laboratory validation' 'Pending' 'WAITING' 'The recommendation has not yet been executed in this milestone.')
        )

        return [ordered]@{
            success=$true; path=$expandedPath; publisher=$publisher; product=$product; family=$family; version=$version;
            architecture=$architecture; installerFramework=$framework; embeddedMsi=$embeddedMsi; packagingDna=$dna; sha256=$hash;
            recognitionConfidence=[double]$recognition; installerConfidence=[double]$installer; commandConfidence=[double]$command;
            overallConfidence=[double]$overall; recognitionGate=$gate; ruleSource=$ruleSource;
            suggestedInstallArguments=$candidates[0].arguments; candidates=@($candidates); decisionTree=$tree; evidence=@($evidence)
        }
    } catch {
        $exception = $_.Exception
        $detail = [ordered]@{
            stage=$stage
            engine='RecognitionEngine'
            function='Invoke-InstallerRecognition'
            exceptionType=$exception.GetType().FullName
            message=$exception.Message
            scriptLine=$_.InvocationInfo.ScriptLineNumber
            positionMessage=$_.InvocationInfo.PositionMessage
        }
        $wrapped = New-Object System.Exception("Recognition failed during '$stage': $($exception.Message)", $exception)
        $wrapped.Data['RecognitionError'] = ($detail | ConvertTo-Json -Depth 5 -Compress)
        throw $wrapped
    }
}

Export-ModuleMember -Function Invoke-InstallerRecognition
