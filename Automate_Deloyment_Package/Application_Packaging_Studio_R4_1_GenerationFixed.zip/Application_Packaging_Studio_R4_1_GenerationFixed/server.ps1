﻿$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
Set-Location $PSScriptRoot
$Host.UI.RawUI.WindowTitle = 'Enterprise Application Packaging Studio - Phoenix Core'

$logDirectory = Join-Path $PSScriptRoot 'Logs'
if (-not (Test-Path $logDirectory)) { New-Item -ItemType Directory -Path $logDirectory | Out-Null }
$log = Join-Path $logDirectory 'phoenix-server.log'
$modulePath = Join-Path $PSScriptRoot 'Modules\RecognitionEngine.psm1'
Import-Module $modulePath -Force -ErrorAction Stop
Import-Module (Join-Path $PSScriptRoot 'Modules\TestingEngine.psm1') -Force -ErrorAction Stop
Import-Module (Join-Path $PSScriptRoot 'Modules\PackagingEngine.psm1') -Force -ErrorAction Stop
$dataDir=Join-Path $PSScriptRoot 'Data'; if(-not(Test-Path $dataDir)){New-Item -ItemType Directory $dataDir|Out-Null}
$packagesFile=Join-Path $dataDir 'packages.json'; if(-not(Test-Path $packagesFile)){Set-Content $packagesFile '[]' -Encoding UTF8}

function Write-Log { param([string]$Message,[string]$Level='INFO',[string]$RequestId='-')
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff') [$Level] [$RequestId] $Message"
    Add-Content -LiteralPath $log -Value $line -Encoding UTF8
    Write-Host $line
}
function ConvertTo-JsonText { param($Object) return ($Object | ConvertTo-Json -Depth 15 -Compress) }
function Send-Bytes { param($Context,[int]$Code,[string]$Type,[byte[]]$Bytes)
    $Context.Response.StatusCode=$Code; $Context.Response.ContentType=$Type; $Context.Response.ContentLength64=$Bytes.Length
    $Context.Response.OutputStream.Write($Bytes,0,$Bytes.Length); $Context.Response.OutputStream.Close()
}
function Send-Text { param($Context,[int]$Code,[string]$Type,[string]$Text)
    Send-Bytes $Context $Code $Type ([Text.Encoding]::UTF8.GetBytes($Text))
}
function Get-MimeType { param([string]$Path)
    switch ([IO.Path]::GetExtension($Path).ToLowerInvariant()) {
        '.html' {'text/html; charset=utf-8'} '.css' {'text/css; charset=utf-8'} '.js' {'application/javascript; charset=utf-8'}
        '.json' {'application/json; charset=utf-8'} '.png' {'image/png'} '.svg' {'image/svg+xml'} default {'application/octet-stream'}
    }
}
function New-ErrorPayload { param([System.Management.Automation.ErrorRecord]$ErrorRecord,[string]$RequestId,[string]$FallbackStage='Request processing')
    $details = $null
    try {
        $raw = $ErrorRecord.Exception.Data['RecognitionError']
        if ($raw) { $details = $raw | ConvertFrom-Json }
    } catch { $details = $null }
    if (-not $details) {
        $details = [ordered]@{ stage=$FallbackStage; engine='PowerShellHost'; function='HTTP request handler'; exceptionType=$ErrorRecord.Exception.GetType().FullName; message=$ErrorRecord.Exception.Message; scriptLine=$ErrorRecord.InvocationInfo.ScriptLineNumber; positionMessage=$ErrorRecord.InvocationInfo.PositionMessage }
    }
    return [ordered]@{
        success=$false; error='Recognition Engine failed'; message=$ErrorRecord.Exception.Message; requestId=$RequestId;
        stage=$details.stage; engine=$details.engine; function=$details.function; exceptionType=$details.exceptionType;
        scriptLine=$details.scriptLine; details=$details.positionMessage; logFile='Logs\phoenix-server.log'
    }
}

Set-Content -LiteralPath $log -Value "Phoenix PowerShell host diagnostics`r`n" -Encoding UTF8
$port=5188
while (Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue) { $port++ }
$prefix="http://127.0.0.1:$port/"
$listener=[Net.HttpListener]::new(); $listener.Prefixes.Add($prefix)
try { $listener.Start() } catch { Write-Log "Unable to start listener: $($_.Exception.Message)" 'ERROR'; Read-Host 'Press Enter'; exit 1 }
Write-Log "PowerShell host ready at $prefix"
Start-Process $prefix
Write-Host ''; Write-Host 'Application is running. Close this window to stop it.' -ForegroundColor Cyan; Write-Host ''
$root=(Resolve-Path (Join-Path $PSScriptRoot 'wwwroot')).Path
try {
    while ($listener.IsListening) {
        $context=$listener.GetContext(); $requestId=[Guid]::NewGuid().ToString('N').Substring(0,10)
        try {
            $request=$context.Request; $route=$request.Url.AbsolutePath
            if ($route -eq '/api/health') {
                Send-Text $context 200 'application/json; charset=utf-8' (ConvertTo-JsonText ([ordered]@{status='ready';release='Application Packaging Studio R4.1 Generation Fixed';port=$port;host='PowerShell HttpListener'})); continue
            }
            if ($route -eq '/api/analyze' -and $request.HttpMethod -eq 'POST') {
                Write-Log 'Recognition request started.' 'INFO' $requestId
                $reader=[IO.StreamReader]::new($request.InputStream,$request.ContentEncoding)
                try { $body=$reader.ReadToEnd() } finally { $reader.Close() }
                $data=$body | ConvertFrom-Json
                try {
                    $result=Invoke-InstallerRecognition -Path ([string]$data.path)
                    $result | Add-Member -NotePropertyName 'requestId' -NotePropertyValue $requestId -Force
                    Write-Log "Recognition completed for $($result.path)." 'INFO' $requestId
                    Send-Text $context 200 'application/json; charset=utf-8' (ConvertTo-JsonText $result)
                } catch {
                    $payload=New-ErrorPayload $_ $requestId 'Recognition'
                    Write-Log "$($payload.error): $($payload.message) | Stage=$($payload.stage) | Engine=$($payload.engine) | Line=$($payload.scriptLine)" 'ERROR' $requestId
                    Send-Text $context 400 'application/json; charset=utf-8' (ConvertTo-JsonText $payload)
                }
                continue
            }
            if ($route -eq '/api/test/install' -and $request.HttpMethod -eq 'POST') {
                $reader=[IO.StreamReader]::new($request.InputStream,$request.ContentEncoding); try{$data=($reader.ReadToEnd()|ConvertFrom-Json)}finally{$reader.Close()}
                Write-Log "Installation test started for $($data.path)" 'WARN' $requestId
                $result=Invoke-InstallerTest -InstallerPath ([string]$data.path) -InstallCommand ([string]$data.command) -TimeoutMinutes 15
                Send-Text $context 200 'application/json; charset=utf-8' (ConvertTo-JsonText $result); continue
            }
            if ($route -eq '/api/test/uninstall' -and $request.HttpMethod -eq 'POST') {
                $reader=[IO.StreamReader]::new($request.InputStream,$request.ContentEncoding); try{$data=($reader.ReadToEnd()|ConvertFrom-Json)}finally{$reader.Close()}
                $result=Invoke-UninstallTest -Command ([string]$data.command)
                Send-Text $context 200 'application/json; charset=utf-8' (ConvertTo-JsonText $result); continue
            }
            if ($route -eq '/api/package/export' -and $request.HttpMethod -eq 'POST') {
                $reader=[IO.StreamReader]::new($request.InputStream,$request.ContentEncoding)
                try { $data=($reader.ReadToEnd() | ConvertFrom-Json) } finally { $reader.Close() }
                Write-Log "Package export started: $($data.packageName)" 'INFO' $requestId
                $result=Export-PackagingBundle `
                    ([string]$data.destinationRoot) `
                    ([string]$data.packageName) `
                    $data.recognition `
                    $data.evidence `
                    ([string]$data.outputMode) `
                    ([bool]$data.copyInstaller) `
                    ([string]$data.clientName) `
                    ([string]$data.preparedBy)
                Write-Log "Package export completed: $($result.packageRoot)" 'INFO' $requestId
                Send-Text $context 201 'application/json; charset=utf-8' (ConvertTo-JsonText $result); continue
            }
            if ($route -eq '/api/package/open-folder' -and $request.HttpMethod -eq 'POST') {
                $reader=[IO.StreamReader]::new($request.InputStream,$request.ContentEncoding)
                try { $data=($reader.ReadToEnd() | ConvertFrom-Json) } finally { $reader.Close() }
                $folder=[string]$data.path
                if (-not (Test-Path -LiteralPath $folder -PathType Container)) { throw "Folder not found: $folder" }
                Start-Process explorer.exe -ArgumentList @($folder)
                Send-Text $context 200 'application/json; charset=utf-8' (ConvertTo-JsonText ([ordered]@{success=$true;path=$folder})); continue
            }
            if ($route -eq '/api/packages' -and $request.HttpMethod -eq 'GET') { Send-Text $context 200 'application/json; charset=utf-8' (Get-Content $packagesFile -Raw); continue }
            if ($route -eq '/api/packages' -and $request.HttpMethod -eq 'POST') {
                $reader=[IO.StreamReader]::new($request.InputStream,$request.ContentEncoding); try{$item=($reader.ReadToEnd()|ConvertFrom-Json)}finally{$reader.Close()}
                $items=@(Get-Content $packagesFile -Raw|ConvertFrom-Json); $item|Add-Member id ([guid]::NewGuid().ToString('N')) -Force; $item|Add-Member savedAt ((Get-Date).ToString('s')) -Force
                @($items+$item)|ConvertTo-Json -Depth 20|Set-Content $packagesFile -Encoding UTF8; Send-Text $context 201 'application/json; charset=utf-8' (ConvertTo-JsonText $item); continue
            }
            if ($route -eq '/api/activity' -and $request.HttpMethod -eq 'GET') { $txt=if(Test-Path $log){Get-Content $log -Tail 300}else{@()}; Send-Text $context 200 'application/json; charset=utf-8' (ConvertTo-JsonText @($txt)); continue }
            $relative=if ($route -eq '/') {'index.html'} else {$route.TrimStart('/')}
            $full=[IO.Path]::GetFullPath((Join-Path $root $relative))
            if (-not $full.StartsWith($root,[StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $full -PathType Leaf)) { $full=Join-Path $root 'index.html' }
            Send-Bytes $context 200 (Get-MimeType $full) ([IO.File]::ReadAllBytes($full))
        } catch {
            $payload=New-ErrorPayload $_ $requestId
            Write-Log "Unhandled request error: $($payload.message)" 'ERROR' $requestId
            try { Send-Text $context 500 'application/json; charset=utf-8' (ConvertTo-JsonText $payload) } catch {}
        }
    }
} finally { $listener.Stop(); $listener.Close(); Write-Log 'Server stopped.' }
