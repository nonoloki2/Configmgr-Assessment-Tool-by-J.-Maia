﻿let current=null,testEvidence=null;const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(url,opt,timeoutMs){let controller,timer;if(timeoutMs){controller=new AbortController();opt={...opt,signal:controller.signal};timer=setTimeout(()=>controller.abort(),timeoutMs)}try{const r=await fetch(url,opt);const j=await r.json();if(!r.ok)throw j;return j}catch(e){if(e && e.name==='AbortError')throw{message:`Request timed out after ${Math.round(timeoutMs/1000)}s.`};throw e}finally{if(timer)clearTimeout(timer)}}
async function health(){try{let j=await api('/api/health');$('health').textContent='● Engine ready';$('health').classList.add('pass');$('health').title=j.release}catch{$('health').textContent='Engine unavailable'}}health();
$('nav').onclick=e=>{let a=e.target.closest('a');if(!a)return;document.querySelectorAll('nav a').forEach(x=>x.classList.remove('active'));a.classList.add('active');document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));$(a.dataset.page).classList.add('active');$('pageTitle').textContent=a.textContent; if(a.dataset.page==='packages')loadPackages();if(a.dataset.page==='activity')loadLog()};
$('analyze').onclick=async()=>{let path=$('path').value.trim();$('analyze').disabled=true;$('error').classList.add('hidden');$('candidatePicker').classList.add('hidden');try{let r=await api('/api/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path})});if(r.needsSelection){renderCandidates(r)}else{current=r;render(current)}}catch(e){$('error').classList.remove('hidden');$('errorTitle').textContent=e.error||'Analysis failed';$('errorMessage').textContent=e.message||String(e)}finally{$('analyze').disabled=false}};
function renderCandidates(r){
  $('empty').classList.add('hidden');
  $('results').classList.add('hidden');
  $('candidatePicker').classList.remove('hidden');
  $('candidatePickerMessage').textContent=r.message||`Found ${(r.candidates||[]).length} installer candidates in this folder.`;
  $('candidateList').innerHTML=(r.candidates||[]).map(c=>
    `<div class="package"><div><b>${esc(c.fileName)}</b><span>${esc((c.extension||'').replace('.','').toUpperCase())} · ${esc(c.sizeDisplay)}</span></div><button class="ghost pick-candidate" data-path="${esc(c.fullPath)}">Analyze this file</button></div>`
  ).join('');
  $('candidatePicker').scrollIntoView({behavior:'smooth',block:'start'});
}
$('candidateList').onclick=async(e)=>{
  const b=e.target.closest('.pick-candidate');
  if(!b)return;
  $('path').value=b.dataset.path;
  $('candidatePicker').classList.add('hidden');
  $('analyze').click();
};
function render(j){$('empty').classList.add('hidden');$('results').classList.remove('hidden');$('identity').innerHTML=[['File',j.fileName],['Product',j.product],['Publisher',j.publisher],['Version',j.productVersion],['Architecture',j.architecture],['Installer',j.installerType],['Engine',j.detectedEngine],['SHA256',j.sha256]].map(x=>`<div><label>${x[0]}</label><strong>${esc(x[1]||'Unknown')}</strong></div>`).join('');['installCommand','installCommandNotes','uninstallCommand','uninstallCommandNotes','detectionMethod','detectionDetails','silentInstallConfidence'].forEach(id=>$(id).textContent=j[id]||'Unknown');$('testPath').value=j.path;$('testInstall').value=j.installCommand; $('rawEvidence').textContent=JSON.stringify(j,null,2);updateFindOnlineVisibility(j)}

// Find Online (Silent Install HQ): only surfaces when static recognition found nothing at all.
let onlineInstallCommand='';
function updateFindOnlineVisibility(j){
  $('findOnlineBox').classList.remove('hidden');
  $('findOnlineResults').innerHTML='';
  $('findOnlineStatus').textContent='';
  onlineInstallCommand='';
  const notFound=(j.installCommand==='Unknown' && j.uninstallCommand==='Unknown');
  const boxLead=$('findOnlineBox').querySelector('strong');
  const boxDesc=$('findOnlineBox').querySelector('p');
  if(notFound){
    boxLead.textContent='No local match found for this installer.';
    boxDesc.textContent="Search Silent Install HQ's script database (thousands of vendor-tested commands) for this product. Extracted commands are third-party content — verify before use.";
  }else{
    boxLead.textContent='Double-check this against a real source.';
    boxDesc.textContent='The command above is a best-effort local guess (confidence: '+(j.silentInstallConfidence||'unknown')+'). Cross-check it against Silent Install HQ before trusting it — local guesses can be wrong.';
  }
  const term=(j.product && j.product!=='Unknown') ? j.product : (j.fileName||'').replace(/\.(exe|msi)$/i,'');
  $('findOnline').dataset.query=term;
}
function findOnlineFallbackLink(q){
  const googleUrl='https://www.google.com/search?q='+encodeURIComponent(`site:silentinstallhq.com "${q}" silent install`);
  return `<div class="package"><div><b>Search manually instead</b><span>opens a Google search restricted to silentinstallhq.com for "${esc(q)}"</span></div><button class="ghost" data-url="${esc(googleUrl)}" onclick="window.open(this.dataset.url,'_blank')">Search in Google</button></div>`;
}
$('findOnline').onclick=async()=>{
  const q=$('findOnline').dataset.query;
  if(!q)return;
  $('findOnline').disabled=true;
  $('findOnlineStatus').textContent=`Searching Silent Install HQ for "${q}"…`;
  $('findOnlineResults').innerHTML='';
  try{
    const r=await api('/api/online-lookup',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query:q})},30000);
    if(!r.found){
      $('findOnlineStatus').textContent=r.message||`No match found on Silent Install HQ for "${r.query}".`;
      $('findOnlineResults').innerHTML=findOnlineFallbackLink(q);
    }else{
      $('findOnlineStatus').textContent=`Found ${r.results.length} matching page(s). Extracted commands are third-party content — verify before use.`;
      $('findOnlineResults').innerHTML=(r.results||[]).map(p=>{
        const installs=(p.installCandidates||[]).map(c=>`<div class="command"><code>${esc(c)}</code><button class="ghost use-install" data-cmd="${esc(c)}">Use as Install command</button></div>`).join('');
        const uninstalls=(p.uninstallCandidates||[]).map(c=>`<div class="command"><code>${esc(c)}</code><button class="ghost use-uninstall" data-cmd="${esc(c)}">Copy Uninstall command</button></div>`).join('');
        return `<div class="card" style="margin-top:12px"><h4><a href="${esc(p.url)}" target="_blank" rel="noopener">${esc(p.title)}</a></h4>${installs}${uninstalls}</div>`;
      }).join('');
    }
  }catch(e){
    $('findOnlineStatus').textContent=(e.message||String(e))+' — you can search manually instead:';
    $('findOnlineResults').innerHTML=findOnlineFallbackLink(q);
  }finally{
    $('findOnline').disabled=false;
  }
};
$('findOnlineResults').onclick=(e)=>{
  const bi=e.target.closest('.use-install');
  if(bi){
    onlineInstallCommand=bi.dataset.cmd;
    $('testInstall').value=onlineInstallCommand;
    $('inlineTestInstall').value=onlineInstallCommand;
    alert('Install command copied into the test workspace. Review it before running.');
    return;
  }
  const bu=e.target.closest('.use-uninstall');
  if(bu){
    navigator.clipboard?.writeText(bu.dataset.cmd).catch(()=>{});
    alert('Uninstall command copied to clipboard. The app still determines the exact uninstall command from a real install/uninstall test — use this only as a reference.');
    return;
  }
};
$('savePackage').onclick=async()=>{if(!current)return;await api('/api/packages',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(current)});alert('Package saved.')};
$('testAck').onchange=()=>$('runInstall').disabled=!$('testAck').checked;
$('runInstall').onclick=async()=>{if(!confirm('Install this software now on the local packaging machine?'))return;$('testStatus').textContent='Installing and comparing registry evidence…';$('runInstall').disabled=true;try{testEvidence=await api('/api/test/install',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:$('testPath').value,command:$('testInstall').value})});renderTest(testEvidence)}catch(e){$('testStatus').textContent=e.message||String(e)}finally{$('runInstall').disabled=false}};
function renderTest(j){$('testResult').classList.remove('hidden');let b=j.bestMatch||{};$('observed').innerHTML=[['Exit code',j.exitCode],['Display name',b.displayName],['Display version',b.displayVersion],['Publisher',b.publisher],['ProductCode',j.productCode],['Registry path',b.registryPath],['Java CurrentVersion',(j.javaEvidence||[]).map(x=>x.currentVersion).join(', ')],['JavaHome',(j.javaEvidence||[]).map(x=>x.javaHome).join(', ')]].map(x=>`<div><label>${x[0]}</label><strong>${esc(x[1]??'Not found')}</strong></div>`).join('');$('exactUninstall').textContent=j.exactUninstallCommand||'Not discovered';$('detectionScript').value=j.detectionScript||'';$('rawEvidence').textContent=JSON.stringify(j,null,2);$('testStatus').textContent='Installation evidence captured successfully.'}
$('runUninstall').onclick=async()=>{if(!testEvidence?.exactUninstallCommand)return;if(!confirm('Run the discovered uninstall command now?'))return;let r=await api('/api/test/uninstall',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({command:testEvidence.exactUninstallCommand})});alert('Uninstall finished with exit code '+r.exitCode)};
async function loadPackages(){let x=await api('/api/packages');$('packageList').innerHTML=x.length?x.map(p=>`<div class="package"><b>${esc(p.product||p.fileName)}</b><span>${esc(p.productVersion||'')} · ${esc(p.publisher||'')}</span></div>`).join(''):'No packages saved.'}
async function loadLog(){let x=await api('/api/activity');$('activityText').textContent=x.join('\n')}
$('refreshLog').onclick=loadLog;$('saveBranding').onclick=()=>{localStorage.clientName=$('clientName').value;localStorage.preparedBy=$('preparedBy').value;alert('Branding saved locally.')};$('clientName').value=localStorage.clientName||'';$('preparedBy').value=localStorage.preparedBy||'';

// G2-M2.1: integrated test workflow directly inside Recognition.
$('openInlineTest').onclick=()=>{
  if(!current){alert('Analyze an installer first.');return}
  $('inlineTestPath').value=current.path||$('path').value;
  $('inlineTestInstall').value=(current.installCommand && current.installCommand!=='Unknown') ? current.installCommand : (onlineInstallCommand||current.installCommand||'');
  $('inlineTestAck').checked=false;
  $('inlineRunInstall').disabled=true;
  $('inlineTestStatus').textContent='';
  $('inlineTesting').classList.remove('hidden');
  $('inlineTesting').scrollIntoView({behavior:'smooth',block:'start'});
};
$('cancelInlineTest').onclick=()=>$('inlineTesting').classList.add('hidden');
$('inlineTestAck').onchange=()=>$('inlineRunInstall').disabled=!$('inlineTestAck').checked;
$('inlineRunInstall').onclick=async()=>{
  if(!confirm('Install this software now on the local packaging machine and capture before/after evidence?'))return;
  $('inlineRunInstall').disabled=true;
  $('inlineTestStatus').textContent='Capturing baseline, installing software and comparing registry evidence…';
  try{
    testEvidence=await api('/api/test/install',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:$('inlineTestPath').value,command:$('inlineTestInstall').value})});
    renderInlineTest(testEvidence);
  }catch(e){
    $('inlineTestStatus').textContent=e.message||String(e);
  }finally{
    $('inlineRunInstall').disabled=!$('inlineTestAck').checked;
  }
};
function renderInlineTest(j){
  $('inlineTestResult').classList.remove('hidden');
  let b=j.bestMatch||{};
  $('inlineObserved').innerHTML=[['Exit code',j.exitCode],['Display name',b.displayName],['Display version',b.displayVersion],['Publisher',b.publisher],['ProductCode',j.productCode],['Registry path',b.registryPath],['Java CurrentVersion',(j.javaEvidence||[]).map(x=>x.currentVersion).filter(Boolean).join(', ')],['JavaHome',(j.javaEvidence||[]).map(x=>x.javaHome).filter(Boolean).join(', ')]].map(x=>`<div><label>${x[0]}</label><strong>${esc(x[1]??'Not found')}</strong></div>`).join('');
  $('inlineExactUninstall').textContent=j.exactUninstallCommand||'Not discovered';
  $('inlineDetectionScript').value=j.detectionScript||'';
  $('inlineTestStatus').textContent='Installation completed and evidence captured.';
  $('rawEvidence').textContent=JSON.stringify(j,null,2);
  // Keep the dedicated Testing page synchronized as well.
  renderTest(j);
  $('inlineTestResult').scrollIntoView({behavior:'smooth',block:'start'});
}
$('copyDetection').onclick=async()=>{try{await navigator.clipboard.writeText($('inlineDetectionScript').value);alert('Detection script copied.')}catch{alert('Unable to access clipboard. Select and copy the script manually.')}};
$('inlineRunUninstall').onclick=async()=>{
  if(!testEvidence?.exactUninstallCommand){alert('No exact uninstall command was discovered.');return}
  if(!confirm('Run the discovered uninstall command now?'))return;
  $('inlineRunUninstall').disabled=true;
  try{
    let r=await api('/api/test/uninstall',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({command:testEvidence.exactUninstallCommand})});
    alert('Uninstall finished with exit code '+r.exitCode);
  }catch(e){alert(e.message||String(e))}
  finally{$('inlineRunUninstall').disabled=false}
};

// Release 4: stabilized workspace generation.
let generatedPackagePath='';

function getWindowsParentFolder(filePath){
  const value=String(filePath||'').trim().replace(/\\+$/,'');
  const index=Math.max(value.lastIndexOf('\\'),value.lastIndexOf('/'));
  return index>2?value.slice(0,index):'';
}

function suggestPackageName(){
  if(!current)return 'Application_Package';
  const parts=[current.product,current.productVersion,current.architecture].filter(Boolean).join('_');
  return parts.replace(/[<>:"/\\|?*]+/g,'_').replace(/\s+/g,'_').replace(/_+/g,'_');
}

function updateExportMode(){
  const mode=$('exportMode').value;
  const installerFolder=getWindowsParentFolder(current?.path||$('path').value);
  const isBeside=mode==='BesideInstaller';

  $('copyInstallerRow').classList.toggle('hidden',isBeside); $('copyInstallerRow').style.display=isBeside?'none':'flex';
  $('exportDestination').readOnly=isBeside;

  if(isBeside){
    $('exportDestination').value=installerFolder;
    $('generatedStructure').textContent=
`InstallerFolder\\
├── Original installer
├── Install.ps1
├── Uninstall.ps1
├── Detection.ps1
├── Packaging-Report.html
├── Package-Manifest.json
├── README.txt
└── Logs\\`;
  }else{
    if(!$('exportDestination').dataset.userEdited){
      $('exportDestination').value=installerFolder;
    }
    $('generatedStructure').textContent=
`Destination\\
└── WorkspaceName\\
    ├── Source\\
    │   └── Original installer
    ├── Install.ps1
    ├── Uninstall.ps1
    ├── Detection.ps1
    ├── Packaging-Report.html
    ├── Package-Manifest.json
    ├── README.txt
    └── Logs\\`;
  }
}

function preparePackageGeneration(){
  if(!current||!testEvidence)return;
  $('packageGeneration').classList.remove('hidden');
  $('exportPackageName').value=$('exportPackageName').value||suggestPackageName();
  $('exportClientName').value=localStorage.clientName||$('clientName').value||'';
  $('exportPreparedBy').value=localStorage.preparedBy||$('preparedBy').value||'';
  updateExportMode();
  $('packageGeneration').scrollIntoView({behavior:'smooth',block:'start'});
}

const originalRenderInlineTest=renderInlineTest;
renderInlineTest=function(j){originalRenderInlineTest(j);preparePackageGeneration()};

$('exportMode').addEventListener('change',updateExportMode);
$('exportDestination').addEventListener('input',()=>{
  $('exportDestination').dataset.userEdited=$('exportDestination').value.trim()?'true':'';
});

$('generatePackage').onclick=async()=>{
  if(!current||!testEvidence){
    alert('Install the application and capture evidence first.');
    return;
  }

  const mode=$('exportMode').value;
  const installerFolder=getWindowsParentFolder(current.path||$('path').value);
  const destinationRoot=mode==='BesideInstaller'
    ? installerFolder
    : ($('exportDestination').value.trim()||installerFolder);
  const packageName=$('exportPackageName').value.trim()||suggestPackageName();

  if(!destinationRoot){
    $('exportStatus').textContent='Unable to determine the installer folder.';
    return;
  }

  const b=$('generatePackage');
  b.disabled=true;
  b.textContent='Generating workspace…';
  $('exportStatus').textContent=mode==='BesideInstaller'
    ? 'Writing scripts and reports beside the original installer…'
    : 'Creating the structured workspace…';

  try{
    const r=await api('/api/package/export',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({
        destinationRoot,
        packageName,
        outputMode:mode,
        recognition:current,
        evidence:testEvidence,
        copyInstaller:mode==='BesideInstaller'?false:$('exportCopyInstaller').checked,
        clientName:$('exportClientName').value.trim(),
        preparedBy:$('exportPreparedBy').value.trim()
      })
    });

    generatedPackagePath=r.packageRoot;
    $('openGeneratedFolder').disabled=false;
    $('exportResult').classList.remove('hidden');
    $('exportResult').innerHTML=
      `<strong>Workspace generated successfully.</strong>`+
      `<code>${esc(r.packageRoot)}</code>`+
      `<div class="scope">${r.files.length} generated file(s). No duplicate installer was created.</div>`;
    $('exportStatus').textContent='Generation completed successfully.';
  }catch(e){
    $('exportStatus').textContent=e.message||String(e);
  }finally{
    b.disabled=false;
    b.textContent='Generate Scripts and Report';
  }
};

$('openGeneratedFolder').onclick=async()=>{
  if(!generatedPackagePath)return;
  try{
    await api('/api/package/open-folder',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({path:generatedPackagePath})
    });
  }catch(e){
    alert(e.message||String(e));
  }
};
