function Get-UninstallInventory {
    $roots = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    $items = foreach ($root in $roots) {
        Get-ItemProperty $root -ErrorAction SilentlyContinue | ForEach-Object {
            [pscustomobject]@{
                key = [string]$_.PSChildName
                displayName = [string]$_.DisplayName
                displayVersion = [string]$_.DisplayVersion
                publisher = [string]$_.Publisher
                uninstallString = [string]$_.UninstallString
                quietUninstallString = [string]$_.QuietUninstallString
                installLocation = [string]$_.InstallLocation
                registryPath = [string]$_.PSPath
            }
        }
    }
    @($items | Where-Object { $_.displayName })
}
function Get-JavaRuntimeEvidence {
    $paths = @(
        'HKLM:\SOFTWARE\JavaSoft\Java Runtime Environment',
        'HKLM:\SOFTWARE\WOW6432Node\JavaSoft\Java Runtime Environment',
        'HKLM:\SOFTWARE\JavaSoft\JRE',
        'HKLM:\SOFTWARE\WOW6432Node\JavaSoft\JRE',
        'HKLM:\SOFTWARE\JavaSoft\JDK',
        'HKLM:\SOFTWARE\WOW6432Node\JavaSoft\JDK'
    )
    $out = foreach ($path in $paths) {
        if (Test-Path $path) {
            $root = Get-ItemProperty $path -ErrorAction SilentlyContinue
            $current = [string]$root.CurrentVersion
            if ($current) {
                $versionPath = Join-Path $path $current
                $v = Get-ItemProperty $versionPath -ErrorAction SilentlyContinue
                [pscustomobject]@{ path=$path; currentVersion=$current; javaHome=[string]$v.JavaHome; runtimeLib=[string]$v.RuntimeLib }
            }
        }
    }
    @($out)
}
function Invoke-InstallerTest {
    param([string]$InstallerPath,[string]$InstallCommand,[int]$TimeoutMinutes=15)
    if (-not (Test-Path -LiteralPath $InstallerPath -PathType Leaf)) { throw "Installer not found: $InstallerPath" }
    if ([string]::IsNullOrWhiteSpace($InstallCommand)) { throw 'Install command is required.' }
    $before = @(Get-UninstallInventory)
    $started = Get-Date
    $proc = Start-Process -FilePath 'cmd.exe' -ArgumentList @('/d','/s','/c', $InstallCommand) -PassThru -WindowStyle Hidden
    $completed = $proc.WaitForExit($TimeoutMinutes * 60 * 1000)
    if (-not $completed) { try{$proc.Kill()}catch{}; throw "Installation test timed out after $TimeoutMinutes minutes." }
    Start-Sleep -Seconds 3
    $after = @(Get-UninstallInventory)
    $beforeKeys = @{}; foreach($x in $before){$beforeKeys[$x.registryPath]=$true}
    $newEntries = @($after | Where-Object { -not $beforeKeys.ContainsKey($_.registryPath) })
    $changedEntries = @($after | Where-Object {
        $old = $before | Where-Object registryPath -eq $_.registryPath | Select-Object -First 1
        $old -and ($old.displayVersion -ne $_.displayVersion -or $old.uninstallString -ne $_.uninstallString)
    })
    $evidence = @($newEntries + $changedEntries | Sort-Object registryPath -Unique)
    $java = @(Get-JavaRuntimeEvidence)
    $best = $evidence | Sort-Object @{Expression={ if($_.displayName -match '(?i)java'){0}else{1} }}, displayName | Select-Object -First 1
    $productCode = if ($best -and $best.key -match '^\{[0-9A-Fa-f-]{36}\}$') { $best.key } else { $null }
    $uninstall = if ($best.quietUninstallString) { $best.quietUninstallString } elseif ($productCode) { "msiexec.exe /x $productCode /qn /norestart" } else { $best.uninstallString }
    $detectScript = if ($productCode) {
@"
`$paths = @(
  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\$productCode',
  'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\$productCode'
)
if (`$paths | Where-Object { Test-Path `$_ }) { exit 0 }
exit 1
"@
    } elseif ($best) {
@"
`$match = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue |
  Where-Object { `$_.DisplayName -eq '$($best.displayName.Replace("'","''"))' -and `$_.DisplayVersion -eq '$($best.displayVersion.Replace("'","''"))' }
if (`$match) { exit 0 }
exit 1
"@
    } else { '' }
    [pscustomobject]@{
        exitCode=$proc.ExitCode; started=$started.ToString('s'); completed=(Get-Date).ToString('s')
        evidence=@($evidence); bestMatch=$best; productCode=$productCode; exactUninstallCommand=$uninstall
        detectionScript=$detectScript; javaEvidence=$java
    }
}
function Invoke-UninstallTest {
    param([string]$Command,[int]$TimeoutMinutes=10)
    if ([string]::IsNullOrWhiteSpace($Command)) { throw 'Uninstall command is required.' }
    $p=Start-Process cmd.exe -ArgumentList @('/d','/s','/c',$Command) -PassThru -WindowStyle Hidden
    if(-not $p.WaitForExit($TimeoutMinutes*60*1000)){try{$p.Kill()}catch{};throw 'Uninstall test timed out.'}
    [pscustomobject]@{exitCode=$p.ExitCode;completed=(Get-Date).ToString('s')}
}
Export-ModuleMember -Function Invoke-InstallerTest,Invoke-UninstallTest,Get-UninstallInventory,Get-JavaRuntimeEvidence
