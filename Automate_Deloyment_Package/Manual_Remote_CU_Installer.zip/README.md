# PSHPatcher v2 — Windows CU Remote Installer

## O que mudou em relacao a v1
- Selecao manual do arquivo `.msu`/`.cab` (nao depende mais de um caminho fixo)
- Deteccao automatica de KB, arquitetura e SO alvo pelo nome do arquivo
- Preflight check por host: ping, WinRM, build atual, disco livre, reboot pendente, se o KB ja esta instalado, compatibilidade SO/arquitetura
- Execucao em paralelo (runspaces), com paralelismo configuravel
- Status em tempo real por estagio: Verificando -> Conectando -> Copiando -> Instalando -> Sucesso/Erro
- Exportacao de relatorio em CSV
- Suporte a credencial alternativa (botao "Definir credencial")

## Pre-requisitos
- PowerShell 5.1+ (Windows PowerShell, roda tambem em PowerShell 7 com WinForms)
- WinRM habilitado nos hosts alvo (`Enable-PSRemoting`) e liberado no firewall
- Conta com permissao de administrador remoto nos hosts (ou usar "Definir credencial")
- Compartilhamento administrativo `C$` acessivel (usado para copiar o pacote via `Copy-Item -ToSession`)

## Como usar
1. Abra `PSHPatcher-v2.ps1`:
   ```
   powershell.exe -ExecutionPolicy Bypass -File .\PSHPatcher-v2.ps1
   ```
2. Cole a lista de hosts (1 por linha) ou clique em **Load hosts.txt**
3. (Opcional) Clique em **Definir credencial** se o usuario atual nao tiver acesso remoto aos hosts
4. Clique em **Selecionar arquivo (.msu/.cab)...** e escolha o pacote de update
5. Clique em **Verificar hosts** para rodar o preflight (recomendado antes de instalar) — isso preenche build atual, disco livre, reboot pendente e compatibilidade
6. Clique em **Install CU** para iniciar a instalacao em paralelo
7. Acompanhe o status por host em tempo real na grid
8. Use **Exportar relatorio (CSV)** ao final para gerar a evidencia da execucao

## Notas de implementacao / limitacoes conhecidas
- O progresso da instalacao e mostrado por **estagio** (Conectando/Copiando/Instalando/Concluido), nao por percentual — `wusa.exe`/`dism.exe` nao expoem progresso granular de forma confiavel via linha de comando, entao um percentual falso seria enganoso.
- Exit codes comuns do Windows Update ja sao traduzidos (0, 3010, 2359302, 1642, 1603, 1618, 87). Outros codigos aparecem como "Exit code N" — pode-se estender `Get-FriendlyExitDetail` conforme necessario.
- A checagem de compatibilidade compara o nome do arquivo (`windows11.0-kbXXXXXXX-x64...msu`) com o `Caption`/`OSArchitecture` reportado pelo host. Ela evita tentativas obviamente erradas, mas nao substitui validacao completa de pre-requisitos do pacote (ex: SSU antes de LCU).
- Este script foi escrito e revisado por leitura (o ambiente de geracao nao tem Windows/PowerShell para rodar a GUI). Recomendo testar primeiro em 2-3 hosts de laboratorio antes de rodar em producao.
- Para pacotes que exigem SSU + LCU juntos, hoje e preciso rodar o "Install CU" duas vezes (uma pra cada arquivo). Dá pra evoluir para multi-arquivo com ordenacao automatica se for uma necessidade recorrente.

## Estrutura do arquivo
- `PSHPatcher-v2.ps1` — script unico, self-contained (helpers, workers remotos, UI)
