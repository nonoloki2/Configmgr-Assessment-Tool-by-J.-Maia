﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$script:SilentInstallHqBase = 'https://silentinstallhq.com'
$script:SilentInstallHqUserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'

function Set-TlsForWebRequests {
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        [Net.ServicePointManager]::Expect100Continue = $false
    } catch { }
}

function Invoke-HttpWebRequestTransport {
    param([Parameter(Mandatory=$true)][string]$Url,[int]$TimeoutSeconds=18)
    Set-TlsForWebRequests
    $request = [System.Net.HttpWebRequest]::Create($Url)
    $request.Method = 'GET'
    $request.UserAgent = $script:SilentInstallHqUserAgent
    $request.Accept = 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8'
    $request.AutomaticDecompression = [System.Net.DecompressionMethods]::GZip -bor [System.Net.DecompressionMethods]::Deflate
    $request.AllowAutoRedirect = $true
    $request.MaximumAutomaticRedirections = 8
    $request.Timeout = $TimeoutSeconds * 1000
    $request.ReadWriteTimeout = $TimeoutSeconds * 1000
    $request.KeepAlive = $false
    $request.UseDefaultCredentials = $true
    try {
        if ([System.Net.WebRequest]::DefaultWebProxy) {
            [System.Net.WebRequest]::DefaultWebProxy.Credentials = [System.Net.CredentialCache]::DefaultNetworkCredentials
            $request.Proxy = [System.Net.WebRequest]::DefaultWebProxy
        }
    } catch { }
    $response = $null
    try {
        $response = [System.Net.HttpWebResponse]$request.GetResponse()
        if ([int]$response.StatusCode -lt 200 -or [int]$response.StatusCode -ge 300) {
            throw "HTTP $([int]$response.StatusCode) ($($response.StatusDescription))"
        }
        $stream = $response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($stream, [Text.Encoding]::UTF8, $true)
        try { return $reader.ReadToEnd() } finally { $reader.Dispose(); $stream.Dispose() }
    } finally {
        if ($response) { $response.Dispose() }
        try { $request.Abort() } catch { }
    }
}

function Invoke-PowerShellWebRequestTransport {
    param([Parameter(Mandatory=$true)][string]$Url,[int]$TimeoutSeconds=18)
    Set-TlsForWebRequests
    $params = @{
        Uri = $Url
        Method = 'Get'
        UseBasicParsing = $true
        TimeoutSec = $TimeoutSeconds
        MaximumRedirection = 8
        Headers = @{
            'User-Agent' = $script:SilentInstallHqUserAgent
            'Accept' = 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8'
            'Accept-Encoding' = 'gzip, deflate'
            'Cache-Control' = 'no-cache'
        }
        ErrorAction = 'Stop'
    }
    $cmd = Get-Command Invoke-WebRequest -ErrorAction Stop
    if ($cmd.Parameters.ContainsKey('UseDefaultCredentials')) { $params.UseDefaultCredentials = $true }
    $result = Invoke-WebRequest @params
    return [string]$result.Content
}

function Invoke-CurlTransport {
    param([Parameter(Mandatory=$true)][string]$Url,[int]$TimeoutSeconds=18)
    $curl = Get-Command curl.exe -ErrorAction SilentlyContinue
    if (-not $curl) { throw 'curl.exe is not available.' }
    $args = @('--location','--silent','--show-error','--fail','--compressed','--connect-timeout',[string]([Math]::Min(10,$TimeoutSeconds)),'--max-time',[string]$TimeoutSeconds,'--user-agent',$script:SilentInstallHqUserAgent,'--header','Accept: text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',$Url)
    $output = & $curl.Source @args 2>&1
    if ($LASTEXITCODE -ne 0) { throw "curl.exe exit code $LASTEXITCODE`: $($output -join ' ')" }
    return ($output -join "`n")
}

function Invoke-ResilientHttpGet {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Url,[int]$TimeoutSeconds=18)
    $errors = New-Object System.Collections.Generic.List[string]
    foreach ($transport in @('WindowsWebRequest','PowerShellWebRequest','Curl')) {
        try {
            $content = switch ($transport) {
                'WindowsWebRequest' { Invoke-HttpWebRequestTransport -Url $Url -TimeoutSeconds $TimeoutSeconds }
                'PowerShellWebRequest' { Invoke-PowerShellWebRequestTransport -Url $Url -TimeoutSeconds $TimeoutSeconds }
                'Curl' { Invoke-CurlTransport -Url $Url -TimeoutSeconds $TimeoutSeconds }
            }
            if ([string]::IsNullOrWhiteSpace($content)) { throw 'The server returned an empty response.' }
            return [pscustomobject]@{ Content=[string]$content; Transport=$transport; Url=$Url }
        } catch {
            $errors.Add("${transport}: $($_.Exception.Message)")
        }
    }
    throw "All web transports failed for $Url. $($errors -join ' | ')"
}

function ConvertTo-PlainTextFromHtml {
    param([Parameter(Mandatory=$true)][string]$Html)
    $t=$Html -replace '(?is)<script.*?</script>','' -replace '(?is)<style.*?</style>',''
    $t=$t -replace '(?i)<br\s*/?>',"`n" -replace '(?i)</(tr|td|th|p|div|li|h[1-6]|pre|code)>',"`n"
    $t=$t -replace '<[^>]+>',' '
    $t=[System.Net.WebUtility]::HtmlDecode($t) -replace "\u00a0",' '
    $lines=($t -split "`r?`n") | ForEach-Object { ($_ -replace '[ \t]+',' ').Trim() } | Where-Object { $_ }
    return ($lines -join "`n")
}

function ConvertTo-CleanCommand {
    param([string]$Value)
    if([string]::IsNullOrWhiteSpace($Value)){ return $null }
    $v=[System.Net.WebUtility]::HtmlDecode($Value)
    $v=$v -replace '(?is)<br\s*/?>',' ' -replace '<[^>]+>',' '
    $v=($v -replace '[\r\n\t]+',' ' -replace ' {2,}',' ').Trim(' ','`','*',[char]0x201c,[char]0x201d)
    $v=$v -replace '\s+(Silent Uninstall Switch|Repair Command|Download Link|PowerShell Script|Detection Script|PSADT.*)$',''
    if($v.Length -lt 3){ return $null }
    return $v
}

function ConvertTo-Slug {
    param([string]$Text)
    $v = $Text.ToLowerInvariant()
    $v = $v -replace '[^a-z0-9]+','-'
    return $v.Trim('-')
}

function Get-DirectArticleCandidates {
    param([Parameter(Mandatory=$true)][string]$Query)
    $clean = ($Query -replace '\bsetup\b|\binstaller\b|\b(x64|x86|64-bit|32-bit)\b',' ' -replace '\s+',' ').Trim()
    $baseSlug = ConvertTo-Slug $clean
    $aliases = New-Object System.Collections.Generic.List[string]
    $aliases.Add($baseSlug)
    if ($clean -match '(?i)^firefox$|mozilla firefox') { $aliases.Insert(0,'mozilla-firefox') }
    if ($clean -match '(?i)^chrome$|google chrome') { $aliases.Insert(0,'google-chrome') }
    if ($clean -match '(?i)^edge$|microsoft edge') { $aliases.Insert(0,'microsoft-edge') }
    if ($clean -match '(?i)^reader$|adobe.*reader|acrobat reader') { $aliases.Insert(0,'adobe-acrobat-reader-dc') }
    if ($clean -match '(?i)^7[- ]?zip$') { $aliases.Insert(0,'7-zip') }
    $urls = New-Object System.Collections.Generic.List[string]
    foreach ($slug in @($aliases | Select-Object -Unique)) {
        if ([string]::IsNullOrWhiteSpace($slug)) { continue }
        $urls.Add("$script:SilentInstallHqBase/$slug-silent-install-how-to-guide/")
        $urls.Add("$script:SilentInstallHqBase/$slug-silent-install/")
    }
    return @($urls | Select-Object -Unique)
}

function Get-SearchResultsFromHtml {
    param([Parameter(Mandatory=$true)][string]$Html,[int]$MaxResults=8)
    $seen=@{}; $results=@()
    $rx='(?is)<a\b[^>]*href=["''](?<url>https?://silentinstallhq\.com/[^"''#?]+/)["''][^>]*>(?<text>.*?)</a>'
    foreach($m in [regex]::Matches($Html,$rx)){
        $url=$m.Groups['url'].Value.TrimEnd('/')+'/'
        if($url -notmatch 'silent-install|silent-uninstall|how-to-guide'){ continue }
        if($seen.ContainsKey($url)){ continue }
        $title=ConvertTo-PlainTextFromHtml $m.Groups['text'].Value
        if([string]::IsNullOrWhiteSpace($title)){ $title=$url }
        $seen[$url]=$true
        $results += [pscustomobject]@{title=$title;url=$url}
        if($results.Count -ge $MaxResults){ break }
    }
    return @($results)
}

function Get-CommandsForLabelFromHtml {
    param([string]$Html,[string]$LabelPattern)
    $found=@()
    foreach($row in [regex]::Matches($Html,'(?is)<tr\b[^>]*>(?<row>.*?)</tr>')){
        $rowHtml=$row.Groups['row'].Value; $rowText=ConvertTo-PlainTextFromHtml $rowHtml
        if($rowText -notmatch "(?i)$LabelPattern"){ continue }
        $codes=@([regex]::Matches($rowHtml,'(?is)<(?:code|pre)\b[^>]*>(?<cmd>.*?)</(?:code|pre)>') | ForEach-Object { ConvertTo-CleanCommand $_.Groups['cmd'].Value } | Where-Object { $_ })
        if($codes.Count -eq 0){ $candidate=ConvertTo-CleanCommand ($rowText -replace "(?is)^.*?$LabelPattern\s*:?\s*",''); if($candidate){$codes=@($candidate)} }
        $found += $codes
    }
    $plain=ConvertTo-PlainTextFromHtml $Html; $lines=@($plain -split "`n")
    for($i=0;$i -lt $lines.Count;$i++){
        if($lines[$i] -match "(?i)^\s*$LabelPattern\s*:?\s*(.*)$"){
            $candidate=$Matches[1]
            if([string]::IsNullOrWhiteSpace($candidate) -and $i+1 -lt $lines.Count){$candidate=$lines[$i+1]}
            $candidate=ConvertTo-CleanCommand $candidate
            if($candidate){$found += $candidate}
        }
    }
    return @($found | Where-Object { $_ } | Select-Object -Unique)
}

function Get-SilentInstallHqCommandsFromHtml {
    [CmdletBinding()] param([Parameter(Mandatory=$true)][string]$Html,[Parameter(Mandatory=$true)][string]$Url,[string]$Transport='Unknown')
    $installs=Get-CommandsForLabelFromHtml -Html $Html -LabelPattern 'Silent Install Switch(?:\s*\([^)]*\))?'
    $uninstalls=Get-CommandsForLabelFromHtml -Html $Html -LabelPattern 'Silent Uninstall Switch(?:\s*\([^)]*\))?'
    $titleMatch=[regex]::Match($Html,'(?is)<title>(.*?)</title>')
    $title=if($titleMatch.Success){(ConvertTo-PlainTextFromHtml $titleMatch.Groups[1].Value)-replace '\s*[-|]\s*Silent Install HQ\s*$',''}else{$Url}
    [pscustomobject]@{url=$Url;title=$title.Trim();installCandidates=@($installs);uninstallCandidates=@($uninstalls);found=(($installs.Count+$uninstalls.Count)-gt 0);transport=$Transport}
}

function Invoke-SilentInstallHqLookup {
    [CmdletBinding()] param([Parameter(Mandatory=$true)][string]$ProductQuery,[int]$MaxCandidatePages=5)
    $clean=$ProductQuery.Trim(); if([string]::IsNullOrWhiteSpace($clean)){throw 'Enter a product name to search.'}
    $attempted=New-Object System.Collections.Generic.List[string]
    $picked=@()

    # Fast path: current generic articles have predictable slugs. This avoids the WordPress search endpoint entirely.
    foreach($url in @(Get-DirectArticleCandidates -Query $clean)){
        if($attempted.Count -ge 4){break}; $attempted.Add($url)
        try{
            $download=Invoke-ResilientHttpGet -Url $url -TimeoutSeconds 18
            $parsed=Get-SilentInstallHqCommandsFromHtml -Html $download.Content -Url $url -Transport $download.Transport
            if($parsed.found){$picked += $parsed; break}
        }catch{}
    }

    # Discovery path: public HTML search only. No WordPress REST API dependency.
    if($picked.Count -eq 0){
        $encoded=[Uri]::EscapeDataString($clean)
        $searchUrl="$script:SilentInstallHqBase/?s=$encoded"
        try{
            $searchDownload=Invoke-ResilientHttpGet -Url $searchUrl -TimeoutSeconds 18
            $results=@(Get-SearchResultsFromHtml -Html $searchDownload.Content -MaxResults 10)
            foreach($candidate in $results){
                if($picked.Count -ge $MaxCandidatePages){break}
                try{
                    $download=Invoke-ResilientHttpGet -Url $candidate.url -TimeoutSeconds 18
                    $parsed=Get-SilentInstallHqCommandsFromHtml -Html $download.Content -Url $candidate.url -Transport $download.Transport
                    if($parsed.found){$picked += $parsed}
                }catch{}
            }
        }catch{
            if($picked.Count -eq 0){
                return [pscustomobject]@{success=$false;found=$false;query=$clean;message="Silent Install HQ could not be reached using Windows proxy credentials, PowerShell web request, or curl.exe. $($_.Exception.Message)";results=@();attempted=@($attempted)}
            }
        }
    }

    if($picked.Count -eq 0){return [pscustomobject]@{success=$true;found=$false;query=$clean;message="Silent Install HQ was reached, but no labeled install or uninstall commands were found for '$clean'.";results=@();attempted=@($attempted)}}
    return [pscustomobject]@{success=$true;found=$true;query=$clean;message="Commands captured from Silent Install HQ.";results=@($picked | Group-Object url | ForEach-Object {$_.Group[0]});attempted=@($attempted)}
}

Export-ModuleMember -Function Invoke-SilentInstallHqLookup,Get-SilentInstallHqCommandsFromHtml,ConvertTo-PlainTextFromHtml
