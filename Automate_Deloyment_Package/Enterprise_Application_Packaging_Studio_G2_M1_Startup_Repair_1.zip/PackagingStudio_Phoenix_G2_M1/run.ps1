$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = 'Enterprise Application Packaging Studio - Phoenix Core'
Set-Location $PSScriptRoot

$port = 5188
$appUrl = "http://127.0.0.1:$port"
$healthUrl = "$appUrl/api/health"
$release = 'G2-M1 Phoenix Core - Startup Repair 1'
$logPath = Join-Path $PSScriptRoot 'phoenix-startup.log'

function Write-StartupLog {
    param([string]$Message)
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $Message"
    Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8
    Write-Host $line
}

try {
    Set-Content -LiteralPath $logPath -Value "Enterprise Application Packaging Studio - startup diagnostics`r`n" -Encoding UTF8

    $dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
    if (-not $dotnet) {
        throw 'Microsoft .NET 8 SDK was not found in PATH.'
    }

    $sdks = & dotnet --list-sdks 2>$null
    if (-not $sdks) {
        throw 'The .NET runtime is installed, but the .NET SDK is missing. This source release requires the .NET 8 SDK.'
    }

    $hasNet8 = $sdks | Where-Object { $_ -match '^8\.' }
    if (-not $hasNet8) {
        throw 'The .NET 8 SDK was not found. Install .NET 8 SDK and run again.'
    }

    Write-StartupLog "Using dotnet: $($dotnet.Source)"
    Write-StartupLog "Application URL: $appUrl"

    # Keep the behavior that worked in the previous release: show a page immediately.
    # This local page polls the real service and redirects automatically as soon as Kestrel is ready.
    $loadingFile = Join-Path $env:TEMP 'PackagingStudio-Phoenix-Starting.html'
    $loadingHtml = @"
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Starting Packaging Studio</title>
<style>
body{margin:0;font-family:Segoe UI,Arial,sans-serif;background:#081526;color:#eaf2ff;display:grid;place-items:center;min-height:100vh}
.card{width:min(620px,88vw);padding:38px;border:1px solid #29415f;border-radius:22px;background:#0d1d31;box-shadow:0 24px 80px #0008;text-align:center}
.logo{font-size:13px;letter-spacing:.18em;color:#66d9ff;text-transform:uppercase}.spinner{width:58px;height:58px;margin:28px auto;border:5px solid #213a59;border-top-color:#66d9ff;border-radius:50%;animation:s 1s linear infinite}@keyframes s{to{transform:rotate(360deg)}}
h1{margin:0;font-size:30px}p{color:#adc0d8;line-height:1.55}.status{margin-top:22px;padding:12px;border-radius:12px;background:#091522;color:#9fe8ff;font-family:Consolas,monospace}
</style>
</head>
<body><main class="card"><div class="logo">Phoenix Core</div><h1>Enterprise Application Packaging Studio</h1><div class="spinner"></div><p>The local engine is starting. This page will open the application automatically when it is ready.</p><div class="status" id="status">Starting local service...</div></main>
<script>
const target='$appUrl'; let attempts=0;
async function check(){attempts++;document.getElementById('status').textContent='Starting local service... attempt '+attempts;
 try{await fetch(target+'/api/health?ts='+Date.now(),{mode:'no-cors',cache:'no-store'});location.replace(target+'/?startup='+Date.now());return;}catch(e){}
 if(attempts>=120){document.getElementById('status').textContent='Startup is taking longer than expected. Check phoenix-startup.log and the PowerShell window.';return;}
 setTimeout(check,500);
}
check();
</script></body></html>
"@
    Set-Content -LiteralPath $loadingFile -Value $loadingHtml -Encoding UTF8
    Start-Process $loadingFile

    # Detect a listener before starting. Never hide startup/build failures.
    $listener = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($listener) {
        try {
            $health = Invoke-RestMethod -Uri $healthUrl -TimeoutSec 2
            if ($health.status -eq 'ready' -and $health.release -like 'G2-M1 Phoenix Core*') {
                Write-StartupLog 'Phoenix Core is already running. Opening the existing instance.'
                Start-Process $appUrl
                exit 0
            }
        } catch { }
        throw "Port $port is already being used by another process (PID $($listener.OwningProcess)). Close that process and run again."
    }

    $env:ASPNETCORE_URLS = $appUrl
    $env:PHOENIX_RELEASE = $release
    Write-StartupLog 'Starting the application in the foreground so any build/startup error remains visible.'
    Write-Host ''
    Write-Host 'Do not close this window while using the application.' -ForegroundColor Cyan
    Write-Host ''

    & dotnet run --project (Join-Path $PSScriptRoot 'PackagingStudio.Phoenix.csproj')
    $exitCode = $LASTEXITCODE
    Write-StartupLog "dotnet exited with code $exitCode"
    if ($exitCode -ne 0) {
        Write-Host ''
        Write-Host "Startup failed. Diagnostics were saved to: $logPath" -ForegroundColor Red
        Read-Host 'Press Enter to close'
        exit $exitCode
    }
}
catch {
    Write-StartupLog "ERROR: $($_.Exception.Message)"
    Write-Host ''
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host "Diagnostics: $logPath" -ForegroundColor Yellow
    Read-Host 'Press Enter to close'
    exit 1
}
