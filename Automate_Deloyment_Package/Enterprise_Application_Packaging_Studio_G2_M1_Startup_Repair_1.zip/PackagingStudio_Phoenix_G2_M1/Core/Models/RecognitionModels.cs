namespace PackagingStudio.Phoenix.Core.Models;

public sealed class RecognitionResult
{
    public bool Success { get; set; }
    public string? Error { get; set; }
    public string FileName { get; set; } = "";
    public string FullPath { get; set; } = "";
    public long FileSize { get; set; }
    public string Sha256 { get; set; } = "";
    public string Publisher { get; set; } = "Unknown";
    public string Product { get; set; } = "Unknown";
    public string Family { get; set; } = "Unknown";
    public string Version { get; set; } = "Unknown";
    public string Architecture { get; set; } = "Unknown";
    public string InstallerFramework { get; set; } = "Unknown";
    public bool EmbeddedMsi { get; set; }
    public string DigitalSignatureStatus { get; set; } = "Unknown";
    public string PackagingDna { get; set; } = "";
    public double RecognitionConfidence { get; set; }
    public double InstallerConfidence { get; set; }
    public double CommandConfidence { get; set; }
    public double OverallConfidence { get; set; }
    public string SuggestedInstallArguments { get; set; } = "Pending discovery";
    public string SuggestedUninstallStrategy { get; set; } = "Pending post-install evidence";
    public string RuleSource { get; set; } = "Generic heuristics";
    public List<EvidenceItem> Evidence { get; set; } = [];
    public List<DecisionNode> DecisionTree { get; set; } = [];
    public List<CommandCandidate> Candidates { get; set; } = [];
    public QualityGate RecognitionGate { get; set; } = new();
}

public sealed record EvidenceItem(string Category, string Label, string Value, double Weight, bool Positive, string Source);
public sealed record DecisionNode(string Step, string Result, string Status, string Explanation);
public sealed record CommandCandidate(string Arguments, double Confidence, string Source, string Status, string Explanation);
public sealed class QualityGate { public double Required { get; set; } = 75; public double Actual { get; set; } public bool Passed => Actual >= Required; }

public sealed class VendorRulePack
{
    public string Vendor { get; set; } = "";
    public string Family { get; set; } = "";
    public string[] PublisherPatterns { get; set; } = [];
    public string[] FilePatterns { get; set; } = [];
    public string[] ProductPatterns { get; set; } = [];
    public CommandRule[] InstallCandidates { get; set; } = [];
    public string UninstallStrategy { get; set; } = "Evidence-driven discovery";
    public int Priority { get; set; } = 50;
}
public sealed class CommandRule { public string Arguments { get; set; } = ""; public double Confidence { get; set; } public string Source { get; set; } = ""; public string Explanation { get; set; } = ""; }
