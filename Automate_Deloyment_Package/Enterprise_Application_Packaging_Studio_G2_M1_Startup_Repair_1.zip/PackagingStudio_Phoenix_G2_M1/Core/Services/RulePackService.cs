using System.Text.Json;
using System.Text.RegularExpressions;
using PackagingStudio.Phoenix.Core.Models;

namespace PackagingStudio.Phoenix.Core.Services;

public sealed class RulePackService
{
    private readonly List<VendorRulePack> _rules = [];
    public RulePackService(IWebHostEnvironment env)
    {
        var root = Path.Combine(env.ContentRootPath, "Rules");
        if (!Directory.Exists(root)) return;
        foreach (var file in Directory.EnumerateFiles(root, "*.json", SearchOption.AllDirectories))
        {
            try
            {
                var rule = JsonSerializer.Deserialize<VendorRulePack>(File.ReadAllText(file), new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                if (rule is not null) _rules.Add(rule);
            }
            catch { }
        }
        _rules.Sort((a,b) => b.Priority.CompareTo(a.Priority));
    }

    public VendorRulePack? Match(string publisher, string product, string fileName)
        => _rules.FirstOrDefault(r => MatchesAny(publisher, r.PublisherPatterns) || MatchesAny(product, r.ProductPatterns) || MatchesAny(fileName, r.FilePatterns));

    private static bool MatchesAny(string value, IEnumerable<string> patterns)
    {
        foreach (var p in patterns)
        {
            var regex = "^" + Regex.Escape(p).Replace("\\*", ".*") + "$";
            if (Regex.IsMatch(value ?? "", regex, RegexOptions.IgnoreCase)) return true;
            if (!p.Contains('*') && (value ?? "").Contains(p, StringComparison.OrdinalIgnoreCase)) return true;
        }
        return false;
    }

    public object GetRulePackSummary() => _rules.Select(r => new { r.Vendor, r.Family, r.Priority, candidates = r.InstallCandidates.Length });
}
