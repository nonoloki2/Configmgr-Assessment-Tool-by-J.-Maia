using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using PackagingStudio.Phoenix.Core.Models;

namespace PackagingStudio.Phoenix.Core.Services;

public sealed class RecognitionService
{
    private readonly RulePackService _rules;
    public RecognitionService(RulePackService rules) => _rules = rules;

    public async Task<RecognitionResult> AnalyzeAsync(string path, CancellationToken ct)
    {
        var r = new RecognitionResult { FullPath = path };
        if (!OperatingSystem.IsWindows()) return Fail(r, "Phoenix Core must run on Windows because installer metadata and Authenticode analysis are Windows-specific.");
        if (!File.Exists(path)) return Fail(r, "Installer file was not found. Check the complete local path.");
        var ext = Path.GetExtension(path).ToLowerInvariant();
        if (ext is not ".exe" and not ".msi") return Fail(r, "This release analyzes EXE and MSI installers.");

        try
        {
            var fi = new FileInfo(path);
            var vi = FileVersionInfo.GetVersionInfo(path);
            r.FileName = fi.Name; r.FileSize = fi.Length;
            r.Product = Clean(vi.ProductName) ?? Path.GetFileNameWithoutExtension(path);
            r.Publisher = Clean(vi.CompanyName) ?? "Unknown";
            r.Version = Clean(vi.ProductVersion) ?? Clean(vi.FileVersion) ?? "Unknown";
            r.Sha256 = await HashAsync(path, ct);
            r.Architecture = await ReadArchitectureAsync(path, ct);
            var signature = await ReadAuthenticodeAsync(path, ct);
            if (!string.IsNullOrWhiteSpace(signature.Subject)) r.Publisher = NormalizePublisher(signature.Subject!, r.Publisher);
            r.DigitalSignatureStatus = signature.Status ?? "Unknown";
            var bytes = await ReadSampleAsync(path, ct);
            r.EmbeddedMsi = Contains(bytes, "Windows Installer") || Contains(bytes, ".msi") || ext == ".msi";
            r.InstallerFramework = DetectFramework(bytes, fi.Name, ext);

            AddEvidence(r, "File", "File name", r.FileName, 8, true, "PE metadata");
            AddEvidence(r, "Identity", "Publisher", r.Publisher, r.Publisher == "Unknown" ? 0 : 22, r.Publisher != "Unknown", "Version resource / Authenticode");
            AddEvidence(r, "Identity", "Product", r.Product, r.Product == "Unknown" ? 0 : 18, r.Product != "Unknown", "Version resource");
            AddEvidence(r, "Identity", "Version", r.Version, r.Version == "Unknown" ? 0 : 10, r.Version != "Unknown", "Version resource");
            AddEvidence(r, "Security", "Digital signature", r.DigitalSignatureStatus, r.DigitalSignatureStatus.Equals("Valid", StringComparison.OrdinalIgnoreCase) ? 18 : 2, r.DigitalSignatureStatus.Equals("Valid", StringComparison.OrdinalIgnoreCase), "Authenticode");
            AddEvidence(r, "Installer", "Framework", r.InstallerFramework, r.InstallerFramework == "Unknown" ? 3 : 14, r.InstallerFramework != "Unknown", "Binary markers");
            AddEvidence(r, "Installer", "Architecture", r.Architecture, r.Architecture == "Unknown" ? 2 : 10, r.Architecture != "Unknown", "PE header");

            var rule = _rules.Match(r.Publisher, r.Product, r.FileName);
            if (rule is not null)
            {
                r.Family = rule.Family;
                r.RuleSource = $"{rule.Vendor} vendor rule pack";
                AddEvidence(r, "Knowledge", "Vendor rule", $"{rule.Vendor} / {rule.Family}", 25, true, "Local rule pack");
                r.Candidates = rule.InstallCandidates.Select(c => new CommandCandidate(c.Arguments, c.Confidence, c.Source, "Ready for validation", c.Explanation)).ToList();
                var best = r.Candidates.OrderByDescending(c => c.Confidence).FirstOrDefault();
                if (best is not null) { r.SuggestedInstallArguments = best.Arguments; r.CommandConfidence = best.Confidence; }
                r.SuggestedUninstallStrategy = rule.UninstallStrategy;
            }
            else
            {
                r.Family = InferFamily(r.Product, r.FileName);
                r.Candidates = GenericCandidates(r.InstallerFramework);
                var best = r.Candidates.FirstOrDefault();
                if (best is not null) { r.SuggestedInstallArguments = best.Arguments; r.CommandConfidence = best.Confidence; }
            }

            r.RecognitionConfidence = Math.Min(100, r.Evidence.Where(e => e.Positive).Sum(e => e.Weight));
            r.InstallerConfidence = r.InstallerFramework == "Unknown" ? 45 : 86;
            r.OverallConfidence = Math.Round((r.RecognitionConfidence * .45) + (r.InstallerConfidence * .25) + (r.CommandConfidence * .30), 1);
            r.RecognitionGate.Actual = r.RecognitionConfidence;
            r.PackagingDna = BuildDna(r);
            BuildDecisionTree(r, rule is not null);
            r.Success = true;
            return r;
        }
        catch (Exception ex) { return Fail(r, ex.Message); }
    }

    private static void BuildDecisionTree(RecognitionResult r, bool rule)
    {
        r.DecisionTree.Add(new("File validation", "Installer accessible", "PASS", "The selected EXE/MSI exists and can be read."));
        r.DecisionTree.Add(new("Product recognition", $"{r.Publisher} / {r.Product}", r.RecognitionGate.Passed ? "PASS" : "REVIEW", $"Recognition confidence is {r.RecognitionConfidence:0.0}%."));
        r.DecisionTree.Add(new("Installer classification", r.InstallerFramework, r.InstallerFramework == "Unknown" ? "REVIEW" : "PASS", "Classification is based on extension and binary markers."));
        r.DecisionTree.Add(new("Vendor intelligence", rule ? r.RuleSource : "No exact rule matched", rule ? "PASS" : "FALLBACK", rule ? "A local product/vendor rule outranks generic framework heuristics." : "Generic candidates remain available for controlled validation."));
        r.DecisionTree.Add(new("Install candidate", r.SuggestedInstallArguments, "PENDING", "The command is a hypothesis until laboratory validation confirms installation evidence."));
        r.DecisionTree.Add(new("Detection discovery", "Not started", "LOCKED", "Detection starts only after a successful install test."));
        r.DecisionTree.Add(new("Uninstall discovery", r.SuggestedUninstallStrategy, "LOCKED", "Uninstall intelligence requires post-install registry and file evidence."));
    }

    private static List<CommandCandidate> GenericCandidates(string framework) => framework switch
    {
        "MSI" => [new("/qn /norestart", 88, "Generic MSI rule", "Ready for validation", "Standard Windows Installer silent properties.")],
        "Inno Setup" => [new("/VERYSILENT /SUPPRESSMSGBOXES /NORESTART /SP-", 82, "Generic Inno Setup rule", "Ready for validation", "Common Inno Setup unattended command.")],
        "NSIS" => [new("/S", 70, "Generic NSIS heuristic", "Ready for validation", "NSIS commonly uses uppercase /S, but vendor rules and installer feedback take precedence.")],
        _ => [new("/quiet /norestart", 42, "Generic fallback", "Low confidence", "No exact vendor or framework rule was found."), new("/silent /norestart", 38, "Generic fallback", "Low confidence", "Alternative convention; validate carefully.")]
    };

    private static string DetectFramework(byte[] b, string name, string ext)
    {
        if (ext == ".msi") return "MSI";
        if (Contains(b, "Inno Setup Setup Data")) return "Inno Setup";
        if (Contains(b, "Nullsoft") || Contains(b, "NSIS")) return "NSIS";
        if (Contains(b, "BurnStub") || Contains(b, "WixBundle")) return "WiX Burn";
        if (Contains(b, "InstallShield")) return "InstallShield";
        if (name.Contains("CitrixWorkspace", StringComparison.OrdinalIgnoreCase)) return "Vendor Bootstrapper";
        if (name.StartsWith("jre-", StringComparison.OrdinalIgnoreCase)) return "Oracle Bootstrapper";
        return "Unknown";
    }

    private static async Task<(string? Status,string? Subject)> ReadAuthenticodeAsync(string path, CancellationToken ct)
    {
        var escaped = path.Replace("'", "''");
        var script = "$s=Get-AuthenticodeSignature -LiteralPath '"+escaped+"'; [pscustomobject]@{Status=$s.Status.ToString();Subject=if($s.SignerCertificate){$s.SignerCertificate.Subject}else{''}}|ConvertTo-Json -Compress";
        var output = await RunPowerShellAsync(script, ct);
        try { var x = JsonSerializer.Deserialize<AuthResult>(output, new JsonSerializerOptions{PropertyNameCaseInsensitive=true}); return (x?.Status,x?.Subject); } catch { return ("Unknown",null); }
    }
    private sealed class AuthResult { public string? Status {get;set;} public string? Subject {get;set;} }

    private static async Task<string> ReadArchitectureAsync(string path, CancellationToken ct)
    {
        if (Path.GetExtension(path).Equals(".msi", StringComparison.OrdinalIgnoreCase)) return "MSI metadata pending";
        await using var fs = File.OpenRead(path); using var br = new BinaryReader(fs);
        if (br.ReadUInt16() != 0x5A4D) return "Unknown"; fs.Seek(0x3C, SeekOrigin.Begin); var pe = br.ReadInt32(); fs.Seek(pe + 4, SeekOrigin.Begin); var machine = br.ReadUInt16();
        return machine switch { 0x8664 => "x64", 0x014c => "x86", 0xAA64 => "ARM64", _ => "Unknown" };
    }
    private static async Task<byte[]> ReadSampleAsync(string path, CancellationToken ct)
    {
        await using var fs = File.OpenRead(path); var size = (int)Math.Min(fs.Length, 16 * 1024 * 1024); var data = new byte[size]; _ = await fs.ReadAsync(data.AsMemory(0,size),ct); return data;
    }
    private static bool Contains(byte[] b, string text) => Encoding.ASCII.GetString(b).Contains(text, StringComparison.OrdinalIgnoreCase) || Encoding.Unicode.GetString(b).Contains(text, StringComparison.OrdinalIgnoreCase);
    private static async Task<string> HashAsync(string path, CancellationToken ct) { await using var fs=File.OpenRead(path); var hash=await SHA256.HashDataAsync(fs,ct); return Convert.ToHexString(hash); }
    private static string BuildDna(RecognitionResult r) { var raw=$"{r.Publisher}|{r.Family}|{r.InstallerFramework}|{r.Architecture}|{r.EmbeddedMsi}"; var h=SHA256.HashData(Encoding.UTF8.GetBytes(raw)); return $"{Convert.ToHexString(h)[..4]}-{Convert.ToHexString(h)[4..8]}"; }
    private static string InferFamily(string p,string f) => p != "Unknown" ? p.Split(' ',StringSplitOptions.RemoveEmptyEntries).FirstOrDefault() ?? "Unknown" : Path.GetFileNameWithoutExtension(f);
    private static string? Clean(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();
    private static string NormalizePublisher(string subject,string fallback) { var cn=subject.Split(',').FirstOrDefault(x=>x.TrimStart().StartsWith("CN=",StringComparison.OrdinalIgnoreCase)); return cn is null ? fallback : cn.Trim()[3..]; }
    private static void AddEvidence(RecognitionResult r,string c,string l,string v,double w,bool p,string s)=>r.Evidence.Add(new(c,l,v,w,p,s));
    private static RecognitionResult Fail(RecognitionResult r,string error) { r.Success=false; r.Error=error; return r; }
    private static async Task<string> RunPowerShellAsync(string script, CancellationToken ct)
    {
        var psi=new ProcessStartInfo("powershell.exe",$"-NoProfile -NonInteractive -ExecutionPolicy Bypass -Command \"{script.Replace("\"","\\\"")}\""){RedirectStandardOutput=true,RedirectStandardError=true,UseShellExecute=false,CreateNoWindow=true};
        using var p=Process.Start(psi)!; var output=await p.StandardOutput.ReadToEndAsync(ct); await p.WaitForExitAsync(ct); return output.Trim();
    }
}
