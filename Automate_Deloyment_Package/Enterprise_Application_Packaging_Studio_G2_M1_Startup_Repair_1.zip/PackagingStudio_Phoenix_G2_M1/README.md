# Enterprise Application Packaging Studio — G2-M1 Phoenix Core

## Test requirements
- Windows 10/11 x64 laboratory machine
- PowerShell 5.1+
- .NET 8 SDK (recommended for this source release)
- Run as administrator for complete installer metadata access

## Start
1. Extract the ZIP.
2. Right-click `run.cmd` and select **Run as administrator**.
3. The launcher waits for Kestrel to answer before opening the browser, eliminating the previous F5/startup race.
4. Enter a complete local path to an EXE or MSI.

## What this test release implements
- Product and publisher recognition
- Authenticode status
- SHA256 and PE architecture
- Installer framework markers
- Packaging DNA
- Separate recognition, installer and command confidence
- Recognition Quality Gate
- Vendor rule packs for Oracle Java 8, Citrix Workspace and 7-Zip
- Explainable command candidates
- Persistent-style decision tree shown in the UI
- No internet dependency

## Safety boundary
This milestone analyzes and recommends. It does not execute installation or uninstallation yet. Existing validated execution flow will be connected after this core is approved.
