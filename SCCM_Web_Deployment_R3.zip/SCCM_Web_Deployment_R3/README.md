# SCCM Web Deployment Console — Release 3

## Compatibility approach

The existing **Create New Deployment** workflow from Release 2.1 was retained. Release 3 adds a separate tab named **Managed Deployment Membership**.

The new operation adds one source Device Collection as an include membership rule on one fixed target collection that already has Application deployments.

## Managed Deployment Membership safety controls

Before enabling the write button, the console:

- Retrieves source and target collections again by Collection ID
- Blocks source = target
- Blocks default `SMS` target collections
- Honors blocked targets from `config.json`
- Detects an existing direct include rule
- Checks whether the source already includes the target through an include-rule chain
- Retrieves all Application deployments assigned to the target collection
- Blocks targets with no active Application deployment
- Warns when the target has multiple deployments
- Highlights Required deployments
- Shows source and target member counts
- Requires a purpose-sensitive confirmation phrase
- Requires an explicit impact acknowledgement
- Writes an audit record
- Offers an immediate Undo action for the rule created

## Important

Member totals after an include rule are estimates because the source and target may already contain some of the same devices.

A Required deployment may begin applying according to its existing availability, deadline, maintenance-window, and notification configuration.

## Start

Run Windows PowerShell 5.1 as Administrator:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
cd C:\Path\SCCM_Web_Deployment_R3
.\Start-SCCMWebDeploy.ps1
```

Open:

```text
http://localhost:8787/
```

## Recommended first membership test

1. Use a source collection with one or two lab devices.
2. Select an existing target with an Available deployment.
3. Run Validate Impact.
4. Confirm the deployments displayed are the expected deployments.
5. Add the rule.
6. Verify the Include Collection membership rule in the SCCM console.
7. Use Undo Change if necessary.

## Logs

```text
logs\SCCMWebDeploy-YYYYMMDD.log
```
