﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [string]$ConfigPath = (Join-Path $PSScriptRoot 'config.json')
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Write-Log {
    param(
        [Parameter(Mandatory)][string]$Message,
        [ValidateSet('INFO','WARN','ERROR','AUDIT')][string]$Level = 'INFO'
    )
    $line = '{0:u} [{1}] {2}' -f (Get-Date), $Level, $Message
    Write-Host $line
    Add-Content -LiteralPath $script:LogFile -Value $line -Encoding UTF8
}

function Send-Json {
    param(
        [Parameter(Mandatory)]$Context,
        [Parameter(Mandatory)]$Data,
        [int]$StatusCode = 200
    )
    $json = $Data | ConvertTo-Json -Depth 10 -Compress
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $Context.Response.StatusCode = $StatusCode
    $Context.Response.ContentType = 'application/json; charset=utf-8'
    $Context.Response.ContentLength64 = $bytes.Length
    $Context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $Context.Response.OutputStream.Close()
}

function Send-File {
    param(
        [Parameter(Mandatory)]$Context,
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$ContentType
    )
    if (-not (Test-Path -LiteralPath $Path)) {
        Send-Json -Context $Context -Data @{ ok = $false; error = 'File not found.' } -StatusCode 404
        return
    }
    $bytes = [IO.File]::ReadAllBytes($Path)
    $Context.Response.StatusCode = 200
    $Context.Response.ContentType = $ContentType
    $Context.Response.ContentLength64 = $bytes.Length
    $Context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $Context.Response.OutputStream.Close()
}

function Read-RequestJson {
    param([Parameter(Mandatory)]$Request)
    $reader = New-Object IO.StreamReader($Request.InputStream, $Request.ContentEncoding)
    try { $raw = $reader.ReadToEnd() } finally { $reader.Dispose() }
    if ([string]::IsNullOrWhiteSpace($raw)) { return $null }
    $raw | ConvertFrom-Json
}

function Get-ConfigMgrModulePath {
    if ($env:SMS_ADMIN_UI_PATH) {
        $candidate = Join-Path (Split-Path $env:SMS_ADMIN_UI_PATH -Parent) 'ConfigurationManager.psd1'
        if (Test-Path -LiteralPath $candidate) { return $candidate }
    }

    $module = Get-Module -ListAvailable ConfigurationManager | Select-Object -First 1
    if ($module) { return $module.Path }

    throw 'ConfigurationManager PowerShell module was not found. Install the SCCM console on this computer.'
}

function Initialize-ConfigMgrModule {
    if (-not (Get-Module ConfigurationManager)) {
        Import-Module (Get-ConfigMgrModulePath) -Force
    }
}

function Ensure-CMSiteDrive {
    if (-not $script:IsConnected) {
        throw 'Not connected to SCCM. Configure Site Code and SMS Provider in Connection Settings.'
    }

    if ([string]::IsNullOrWhiteSpace([string]$script:Config.SiteCode) -or
        [string]::IsNullOrWhiteSpace([string]$script:Config.SmsProvider)) {
        $script:IsConnected = $false
        throw 'The SCCM connection settings are incomplete. Reconnect using Connection Settings.'
    }

    Initialize-ConfigMgrModule

    $drive = Get-PSDrive -Name $script:Config.SiteCode -PSProvider CMSite -ErrorAction SilentlyContinue
    if (-not $drive -or [string]$drive.Root -ne [string]$script:Config.SmsProvider) {
        if ($drive) {
            Remove-PSDrive -Name $script:Config.SiteCode -Force -ErrorAction SilentlyContinue
        }

        New-PSDrive `
            -Name $script:Config.SiteCode `
            -PSProvider CMSite `
            -Root $script:Config.SmsProvider `
            -ErrorAction Stop | Out-Null
    }

    $target = '{0}:\' -f $script:Config.SiteCode
    Set-Location $target -ErrorAction Stop
}

function Invoke-CMOperation {
    param([Parameter(Mandatory)][scriptblock]$ScriptBlock)

    $oldLocation = Get-Location
    try {
        Ensure-CMSiteDrive
        return (& $ScriptBlock)
    }
    catch {
        $firstError = $_.Exception.Message
        Write-Log -Level WARN -Message "CMSite operation failed. Rebuilding the site drive once. Error: $firstError"

        try {
            Set-Location $PSScriptRoot -ErrorAction SilentlyContinue
            Remove-PSDrive -Name ([string]$script:Config.SiteCode) -Force -ErrorAction SilentlyContinue

            Initialize-ConfigMgrModule

            New-PSDrive `
                -Name ([string]$script:Config.SiteCode) `
                -PSProvider CMSite `
                -Root ([string]$script:Config.SmsProvider) `
                -Description ("SCCM Site " + [string]$script:Config.SiteCode) `
                -ErrorAction Stop | Out-Null

            Set-Location ('{0}:\' -f [string]$script:Config.SiteCode) -ErrorAction Stop
            return (& $ScriptBlock)
        }
        catch {
            throw "SCCM operation failed after reconnect. First error: $firstError. Reconnect error: $($_.Exception.Message)"
        }
    }
    finally {
        try { Set-Location $oldLocation -ErrorAction SilentlyContinue } catch {}
    }
}

function Connect-ConfigMgr {
    param(
        [Parameter(Mandatory)][string]$SiteCode,
        [Parameter(Mandatory)][string]$SmsProvider
    )

    $SiteCode = $SiteCode.Trim().ToUpperInvariant()
    $SmsProvider = $SmsProvider.Trim()

    if ($SiteCode -notmatch '^[A-Z0-9]{3}$') {
        throw 'Site Code must contain exactly three letters or numbers.'
    }

    if ([string]::IsNullOrWhiteSpace($SmsProvider)) {
        throw 'SMS Provider server is required.'
    }

    Initialize-ConfigMgrModule

    # Connection is intentionally performed without Invoke-CMOperation.
    # The recovery wrapper must only be used after a valid CMSite drive exists.
    $oldLocation = Get-Location
    try {
        Set-Location $PSScriptRoot

        $existing = Get-PSDrive -Name $SiteCode -PSProvider CMSite -ErrorAction SilentlyContinue
        if ($existing) {
            Remove-PSDrive -Name $SiteCode -Force -ErrorAction Stop
        }

        New-PSDrive `
            -Name $SiteCode `
            -PSProvider CMSite `
            -Root $SmsProvider `
            -Description "SCCM Site $SiteCode" `
            -ErrorAction Stop | Out-Null

        Set-Location ('{0}:\' -f $SiteCode) -ErrorAction Stop

        # Simple provider validation using the same method that worked in R1.1.
        $site = Get-CMSite -ErrorAction Stop | Select-Object -First 1
        if (-not $site) {
            throw "Connected to the provider, but site '$SiteCode' was not returned."
        }

        $script:Config.SiteCode = $SiteCode
        $script:Config.SmsProvider = $SmsProvider
        $script:IsConnected = $true

        $script:Config |
            ConvertTo-Json -Depth 5 |
            Set-Content -LiteralPath $ConfigPath -Encoding UTF8

        Write-Log "Connected to SCCM Site '$SiteCode' through SMS Provider '$SmsProvider'."

        [pscustomobject]@{
            siteCode    = $SiteCode
            smsProvider = $SmsProvider
            siteName    = [string]$site.SiteName
            version     = [string]$site.Version
        }
    }
    catch {
        $script:IsConnected = $false
        try {
            Set-Location $PSScriptRoot -ErrorAction SilentlyContinue
            Remove-PSDrive -Name $SiteCode -Force -ErrorAction SilentlyContinue
        } catch {}

        throw "SCCM connection failed: $($_.Exception.Message)"
    }
    finally {
        try { Set-Location $oldLocation -ErrorAction SilentlyContinue } catch {}
    }
}

function Get-Applications {
    param([string]$Query)

    $result = Invoke-CMOperation {
        $items = Get-CMApplication -Fast -ErrorAction Stop

        if (-not [string]::IsNullOrWhiteSpace($Query)) {
            $needle = $Query.Trim()
            $items = $items | Where-Object {
                ([string]$_.LocalizedDisplayName).IndexOf($needle, [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
                ([string]$_.SoftwareVersion).IndexOf($needle, [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
                ([string]$_.Manufacturer).IndexOf($needle, [StringComparison]::OrdinalIgnoreCase) -ge 0
            }
        }

        @(
            $items |
            Sort-Object LocalizedDisplayName, SoftwareVersion, CIVersion |
            Select-Object -First $script:Config.MaxSearchResults |
            ForEach-Object {
                [pscustomobject]@{
                    name         = [string]$_.LocalizedDisplayName
                    version      = [string]$_.SoftwareVersion
                    manufacturer = [string]$_.Manufacturer
                    ciId         = [int]$_.CI_ID
                    revision     = [int]$_.CIVersion
                    modelName    = [string]$_.ModelName
                    lastModified = if ($_.DateLastModified) { ([datetime]$_.DateLastModified).ToString('s') } else { $null }
                    isExpired    = [bool]$_.IsExpired
                }
            }
        )
    }

    return @($result)
}

function Get-Collections {
    param([string]$Query)

    $result = Invoke-CMOperation {
        $items = Get-CMDeviceCollection -ErrorAction Stop

        if (-not [string]::IsNullOrWhiteSpace($Query)) {
            $needle = $Query.Trim()
            $items = $items | Where-Object {
                ([string]$_.Name).IndexOf($needle, [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
                ([string]$_.CollectionID).IndexOf($needle, [StringComparison]::OrdinalIgnoreCase) -ge 0
            }
        }

        @(
            $items |
            Sort-Object Name |
            Select-Object -First $script:Config.MaxSearchResults |
            ForEach-Object {
                [pscustomobject]@{
                    name                   = [string]$_.Name
                    collectionId           = [string]$_.CollectionID
                    memberCount            = [int]$_.MemberCount
                    limitingCollectionName = [string]$_.LimitToCollectionName
                    limitingCollectionId   = [string]$_.LimitToCollectionID
                    comment                = [string]$_.Comment
                }
            }
        )
    }

    return @($result)
}

function Test-BlockedCollection {
    param(
        [Parameter(Mandatory)][string]$CollectionId,
        [Parameter(Mandatory)][string]$CollectionName
    )
    return (
        $script:Config.BlockedCollectionIds -contains $CollectionId -or
        $script:Config.BlockedCollectionNames -contains $CollectionName
    )
}


function Get-IncludeCollectionIdFromRule {
    param([Parameter(Mandatory)]$Rule)

    foreach ($propertyName in @(
        'IncludeCollectionID',
        'IncludeCollectionId',
        'SourceCollectionID',
        'SourceCollectionId'
    )) {
        $property = $Rule.PSObject.Properties[$propertyName]
        if ($property -and -not [string]::IsNullOrWhiteSpace([string]$property.Value)) {
            return [string]$property.Value
        }
    }

    return $null
}

function Get-CollectionIncludeIds {
    param([Parameter(Mandatory)][string]$CollectionId)

    $rules = @(
        Get-CMDeviceCollectionIncludeMembershipRule `
            -CollectionId $CollectionId `
            -ErrorAction SilentlyContinue
    )

    @(
        foreach ($rule in $rules) {
            $id = Get-IncludeCollectionIdFromRule -Rule $rule
            if ($id) { $id }
        }
    )
}

function Test-CollectionTransitivelyIncludes {
    param(
        [Parameter(Mandatory)][string]$StartCollectionId,
        [Parameter(Mandatory)][string]$SearchCollectionId
    )

    $queue = New-Object System.Collections.Generic.Queue[string]
    $visited = New-Object 'System.Collections.Generic.HashSet[string]'
    $queue.Enqueue($StartCollectionId)

    while ($queue.Count -gt 0) {
        $current = $queue.Dequeue()
        if (-not $visited.Add($current)) { continue }

        foreach ($includedId in @(Get-CollectionIncludeIds -CollectionId $current)) {
            if ($includedId -eq $SearchCollectionId) { return $true }
            if (-not $visited.Contains($includedId)) { $queue.Enqueue($includedId) }
        }

        if ($visited.Count -gt 250) {
            throw 'Circular-reference validation stopped because more than 250 related collections were discovered.'
        }
    }

    return $false
}

function Get-ApplicationDeploymentsForCollection {
    param([Parameter(Mandatory)][string]$CollectionId)

    $deployments = @(
        Get-CMApplicationDeployment `
            -CollectionId $CollectionId `
            -ErrorAction SilentlyContinue
    )

    @(
        foreach ($deployment in $deployments) {
            $offerType = $null
            if ($deployment.PSObject.Properties['OfferTypeID']) {
                $offerType = [int]$deployment.OfferTypeID
            }

            $purpose = switch ($offerType) {
                0 { 'Required' }
                2 { 'Available' }
                default {
                    if ($deployment.PSObject.Properties['DeploymentIntent']) {
                        [string]$deployment.DeploymentIntent
                    } else {
                        'Unknown'
                    }
                }
            }

            $applicationName = $null
            foreach ($propertyName in @('ApplicationName','LocalizedDisplayName','SoftwareName')) {
                $property = $deployment.PSObject.Properties[$propertyName]
                if ($property -and -not [string]::IsNullOrWhiteSpace([string]$property.Value)) {
                    $applicationName = [string]$property.Value
                    break
                }
            }

            $deploymentName = $null
            foreach ($propertyName in @('AssignmentName','DeploymentName')) {
                $property = $deployment.PSObject.Properties[$propertyName]
                if ($property -and -not [string]::IsNullOrWhiteSpace([string]$property.Value)) {
                    $deploymentName = [string]$property.Value
                    break
                }
            }

            $deadline = $null
            foreach ($propertyName in @('EnforcementDeadline','DeadlineTime')) {
                $property = $deployment.PSObject.Properties[$propertyName]
                if ($property -and $property.Value) {
                    try { $deadline = ([datetime]$property.Value).ToString('s') } catch {}
                    break
                }
            }

            [pscustomobject]@{
                applicationName = if ($applicationName) { $applicationName } else { 'Application deployment' }
                deploymentName  = if ($deploymentName) { $deploymentName } else { 'Unnamed deployment' }
                purpose         = $purpose
                deadline        = $deadline
                enabled         = if ($deployment.PSObject.Properties['Enabled']) { [bool]$deployment.Enabled } else { $true }
                assignmentId    = if ($deployment.PSObject.Properties['AssignmentUniqueID']) { [string]$deployment.AssignmentUniqueID } else { $null }
            }
        }
    )
}

function Get-MembershipPreview {
    param(
        [Parameter(Mandatory)][string]$SourceCollectionId,
        [Parameter(Mandatory)][string]$TargetCollectionId
    )

    Invoke-CMOperation {
        $source = Get-CMDeviceCollection -Id $SourceCollectionId -ErrorAction Stop
        $target = Get-CMDeviceCollection -Id $TargetCollectionId -ErrorAction Stop

        if (-not $source) { throw "Source collection '$SourceCollectionId' was not found." }
        if (-not $target) { throw "Target collection '$TargetCollectionId' was not found." }
        if ($SourceCollectionId -eq $TargetCollectionId) {
            throw 'Source and target collections cannot be the same.'
        }

        if ($TargetCollectionId.StartsWith('SMS', [StringComparison]::OrdinalIgnoreCase)) {
            throw 'Default SMS collections cannot be used as managed deployment targets.'
        }

        if (Test-BlockedCollection -CollectionId $TargetCollectionId -CollectionName ([string]$target.Name)) {
            throw "The target collection '$($target.Name)' is blocked by config.json."
        }

        $directIncludes = @(Get-CollectionIncludeIds -CollectionId $TargetCollectionId)
        $alreadyIncluded = $directIncludes -contains $SourceCollectionId

        # A cycle would be created if the source already includes the target,
        # directly or through another chain of include rules.
        $wouldCreateCycle = Test-CollectionTransitivelyIncludes `
            -StartCollectionId $SourceCollectionId `
            -SearchCollectionId $TargetCollectionId

        $deployments = @(Get-ApplicationDeploymentsForCollection -CollectionId $TargetCollectionId)
        $requiredCount = @($deployments | Where-Object { $_.purpose -eq 'Required' -and $_.enabled }).Count
        $availableCount = @($deployments | Where-Object { $_.purpose -eq 'Available' -and $_.enabled }).Count
        $activeCount = @($deployments | Where-Object { $_.enabled }).Count

        $warnings = New-Object System.Collections.Generic.List[string]
        if ($alreadyIncluded) { $warnings.Add('The source collection is already included in the target collection.') }
        if ($wouldCreateCycle) { $warnings.Add('This operation would create a circular collection dependency.') }
        if ($activeCount -eq 0) { $warnings.Add('The selected target has no active Application deployment.') }
        if ($activeCount -gt 1) { $warnings.Add("The selected target has $activeCount active Application deployments. Every one may apply to the source members.") }
        if ($requiredCount -gt 0) { $warnings.Add('At least one Required deployment is active. Installation may begin according to the existing deployment schedule.') }

        $blocked = $alreadyIncluded -or $wouldCreateCycle -or ($activeCount -eq 0)
        $phrase = if ($requiredCount -gt 0) {
            'ADD {0} DEVICES TO REQUIRED DEPLOYMENT' -f [int]$source.MemberCount
        } else {
            [string]$target.Name
        }

        [pscustomobject]@{
            source = [pscustomobject]@{
                name = [string]$source.Name
                collectionId = [string]$source.CollectionID
                memberCount = [int]$source.MemberCount
                limitingCollectionName = [string]$source.LimitToCollectionName
            }
            target = [pscustomobject]@{
                name = [string]$target.Name
                collectionId = [string]$target.CollectionID
                memberCount = [int]$target.MemberCount
                limitingCollectionName = [string]$target.LimitToCollectionName
            }
            deployments = @($deployments)
            activeDeploymentCount = $activeCount
            requiredDeploymentCount = $requiredCount
            availableDeploymentCount = $availableCount
            alreadyIncluded = $alreadyIncluded
            wouldCreateCycle = $wouldCreateCycle
            estimatedMaximumMembers = ([int]$target.MemberCount + [int]$source.MemberCount)
            blocked = $blocked
            warnings = @($warnings)
            requiredConfirmation = $phrase
        }
    }
}

function Add-ManagedDeploymentMembership {
    param(
        [Parameter(Mandatory)]$Body,
        [Parameter(Mandatory)][string]$UserName,
        [Parameter(Mandatory)][string]$RemoteAddress
    )

    foreach ($field in @('sourceCollectionId','targetCollectionId','confirmationText')) {
        if ($null -eq $Body.$field -or [string]::IsNullOrWhiteSpace([string]$Body.$field)) {
            throw "Required field is missing: $field"
        }
    }

    if (-not [bool]$Body.acknowledged) {
        throw 'The impact acknowledgement must be selected.'
    }

    $preview = Get-MembershipPreview `
        -SourceCollectionId ([string]$Body.sourceCollectionId) `
        -TargetCollectionId ([string]$Body.targetCollectionId)

    if ($preview.blocked) {
        throw ('Operation blocked: ' + (($preview.warnings) -join ' '))
    }

    if ([string]$Body.confirmationText -cne [string]$preview.requiredConfirmation) {
        throw 'The confirmation text does not match exactly.'
    }

    Invoke-CMOperation {
        Add-CMDeviceCollectionIncludeMembershipRule `
            -CollectionId ([string]$Body.targetCollectionId) `
            -IncludeCollectionId ([string]$Body.sourceCollectionId) `
            -ErrorAction Stop

        try {
            Invoke-CMDeviceCollectionUpdate `
                -CollectionId ([string]$Body.targetCollectionId) `
                -ErrorAction Stop
        } catch {
            Write-Log -Level WARN -Message "Membership was added, but collection evaluation could not be triggered: $($_.Exception.Message)"
        }
    }

    Write-Log -Level AUDIT -Message (
        "User='$UserName'; Remote='$RemoteAddress'; Action='Add Include Membership Rule'; " +
        "Source='$($preview.source.name)' SourceID='$($preview.source.collectionId)'; " +
        "Target='$($preview.target.name)' TargetID='$($preview.target.collectionId)'; " +
        "ActiveDeployments='$($preview.activeDeploymentCount)' RequiredDeployments='$($preview.requiredDeploymentCount)'"
    )

    [pscustomobject]@{
        source = $preview.source
        target = $preview.target
        deployments = $preview.deployments
        message = 'Collection include membership rule added successfully.'
    }
}

function Remove-ManagedDeploymentMembership {
    param(
        [Parameter(Mandatory)]$Body,
        [Parameter(Mandatory)][string]$UserName,
        [Parameter(Mandatory)][string]$RemoteAddress
    )

    if ([string]$Body.confirmationText -cne 'UNDO') {
        throw 'Type UNDO to remove the include membership rule.'
    }

    $sourceId = [string]$Body.sourceCollectionId
    $targetId = [string]$Body.targetCollectionId

    Invoke-CMOperation {
        $existingIds = @(Get-CollectionIncludeIds -CollectionId $targetId)
        if ($existingIds -notcontains $sourceId) {
            throw 'The include membership rule no longer exists.'
        }

        Remove-CMDeviceCollectionIncludeMembershipRule `
            -CollectionId $targetId `
            -IncludeCollectionId $sourceId `
            -Force `
            -ErrorAction Stop

        try {
            Invoke-CMDeviceCollectionUpdate -CollectionId $targetId -ErrorAction Stop
        } catch {
            Write-Log -Level WARN -Message "Membership was removed, but collection evaluation could not be triggered: $($_.Exception.Message)"
        }
    }

    Write-Log -Level AUDIT -Message (
        "User='$UserName'; Remote='$RemoteAddress'; Action='Remove Include Membership Rule'; " +
        "SourceID='$sourceId'; TargetID='$targetId'"
    )

    [pscustomobject]@{
        message = 'Include membership rule removed successfully.'
        sourceCollectionId = $sourceId
        targetCollectionId = $targetId
    }
}

function New-ApplicationDeploymentFromRequest {
    param(
        [Parameter(Mandatory)]$Body,
        [Parameter(Mandatory)][string]$UserName,
        [Parameter(Mandatory)][string]$RemoteAddress
    )

    if (-not $script:Config.EnableDeploymentCreation) {
        throw 'Deployment creation is disabled in config.json.'
    }

    $required = @(
        'applicationCiId','collectionId','collectionName',
        'deployAction','deployPurpose','userNotification','confirmationText'
    )

    foreach ($field in $required) {
        if ($null -eq $Body.$field -or [string]::IsNullOrWhiteSpace([string]$Body.$field)) {
            throw "Required field is missing: $field"
        }
    }

    if ([string]$Body.confirmationText -cne [string]$Body.collectionName) {
        throw 'Collection confirmation text does not match exactly.'
    }

    if (@('Install','Uninstall') -notcontains [string]$Body.deployAction) { throw 'Invalid deploy action.' }
    if (@('Available','Required') -notcontains [string]$Body.deployPurpose) { throw 'Invalid deploy purpose.' }
    if (@('DisplayAll','DisplaySoftwareCenterOnly','HideAll') -notcontains [string]$Body.userNotification) { throw 'Invalid notification option.' }

    if (Test-BlockedCollection -CollectionId $Body.collectionId -CollectionName $Body.collectionName) {
        throw "The collection '$($Body.collectionName)' is blocked by config.json."
    }

    $available = if ($Body.availableDateTime) { [datetime]::Parse([string]$Body.availableDateTime) } else { Get-Date }
    $deadline = $null

    if ([string]$Body.deployPurpose -eq 'Required') {
        if (-not $Body.deadlineDateTime) { throw 'A deadline is required for a Required deployment.' }
        $deadline = [datetime]::Parse([string]$Body.deadlineDateTime)
        if ($deadline -lt $available) { throw 'Deadline cannot be earlier than availability.' }
    }

    $ciId = [int]$Body.applicationCiId
    $collectionId = [string]$Body.collectionId

    $result = Invoke-CMOperation {
        $app = Get-CMApplication -Id $ciId -Fast -ErrorAction Stop
        if (-not $app) { throw "Application CI_ID $ciId was not found." }

        $collection = Get-CMDeviceCollection -Id $collectionId -ErrorAction Stop
        if (-not $collection) { throw "Device Collection $collectionId was not found." }

        $actualAppName = [string]$app.LocalizedDisplayName
        $actualCollectionName = [string]$collection.Name

        if ($actualCollectionName -cne [string]$Body.collectionName) {
            throw "Collection name changed or did not match. Current name: $actualCollectionName"
        }

        $params = @{
            Id                         = $ciId
            CollectionId               = $collectionId
            DeployAction               = [string]$Body.deployAction
            DeployPurpose              = [string]$Body.deployPurpose
            AvailableDateTime          = $available
            UserNotification           = [string]$Body.userNotification
            TimeBaseOn                 = 'LocalTime'
            OverrideServiceWindow      = [bool]$Body.overrideServiceWindow
            RebootOutsideServiceWindow = [bool]$Body.rebootOutsideServiceWindow
            UseMeteredNetwork          = [bool]$Body.useMeteredNetwork
            ErrorAction                = 'Stop'
        }

        if ($deadline) { $params.DeadlineDateTime = $deadline }
        if (-not [string]::IsNullOrWhiteSpace([string]$Body.comment)) {
            $params.Comment = [string]$Body.comment
        }

        New-CMApplicationDeployment @params | Out-Null

        [pscustomobject]@{
            applicationName  = $actualAppName
            applicationCiId  = $ciId
            collectionName   = $actualCollectionName
            collectionId     = $collectionId
            deployAction     = [string]$Body.deployAction
            deployPurpose    = [string]$Body.deployPurpose
            availableDateTime = $available.ToString('s')
            deadlineDateTime = if ($deadline) { $deadline.ToString('s') } else { $null }
        }
    }

    Write-Log -Level AUDIT -Message (
        "User='$UserName'; Remote='$RemoteAddress'; Action='Create Application Deployment'; " +
        "Application='$($result.applicationName)' CI_ID='$($result.applicationCiId)'; " +
        "Collection='$($result.collectionName)' CollectionID='$($result.collectionId)'; " +
        "Purpose='$($result.deployPurpose)'; DeployAction='$($result.deployAction)'"
    )

    return $result
}

if (-not (Test-Path -LiteralPath $ConfigPath)) {
    throw "Configuration file not found: $ConfigPath"
}

$script:Config = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
$script:IsConnected = $false
$script:LogFile = Join-Path $PSScriptRoot ('logs\SCCMWebDeploy-{0}.log' -f (Get-Date -Format 'yyyyMMdd'))
New-Item -ItemType Directory -Path (Split-Path $script:LogFile) -Force | Out-Null

$listener = New-Object Net.HttpListener
$listener.Prefixes.Add([string]$script:Config.ListenUrl)
$listener.AuthenticationSchemes = [Net.AuthenticationSchemes]::Anonymous
$listener.Start()

Write-Log "SCCM Web Deployment Console R2 started at $($script:Config.ListenUrl)"
Write-Host ""
Write-Host "Open $($script:Config.ListenUrl) in a browser. Press Ctrl+C to stop." -ForegroundColor Cyan

try {
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $request = $context.Request
        $path = $request.Url.AbsolutePath.TrimEnd('/')
        if ([string]::IsNullOrEmpty($path)) { $path = '/' }

        try {
            switch -Regex ("$($request.HttpMethod) $path") {
                '^GET /$' {
                    Send-File -Context $context -Path (Join-Path $PSScriptRoot 'www\index.html') -ContentType 'text/html; charset=utf-8'
                    break
                }
                '^GET /api/health$' {
                    Send-Json -Context $context -Data @{
                        ok = $true
                        connected = [bool]$script:IsConnected
                        siteCode = [string]$script:Config.SiteCode
                        smsProvider = [string]$script:Config.SmsProvider
                        deploymentCreationEnabled = [bool]$script:Config.EnableDeploymentCreation
                        serverTime = (Get-Date).ToString('s')
                    }
                    break
                }
                '^GET /api/config$' {
                    Send-Json -Context $context -Data @{
                        ok = $true
                        siteCode = [string]$script:Config.SiteCode
                        smsProvider = [string]$script:Config.SmsProvider
                    }
                    break
                }
                '^POST /api/connect$' {
                    $body = Read-RequestJson -Request $request
                    $connection = Connect-ConfigMgr -SiteCode ([string]$body.siteCode) -SmsProvider ([string]$body.smsProvider)
                    Send-Json -Context $context -Data @{
                        ok = $true
                        message = 'Connected to SCCM successfully.'
                        connection = $connection
                    }
                    break
                }
                '^GET /api/applications$' {
                    $query = [Web.HttpUtility]::UrlDecode($request.QueryString['query'])
                    Write-Log "Application search requested. Query='$query'"
                    $items = Get-Applications -Query $query
                    Send-Json -Context $context -Data @{
                        ok = $true
                        count = @($items).Count
                        items = @($items)
                    }
                    break
                }
                '^GET /api/collections$' {
                    $query = [Web.HttpUtility]::UrlDecode($request.QueryString['query'])
                    Write-Log "Collection search requested. Query='$query'"
                    $items = Get-Collections -Query $query
                    Send-Json -Context $context -Data @{
                        ok = $true
                        count = @($items).Count
                        items = @($items)
                    }
                    break
                }
                '^POST /api/membership/preview$' {
                    $body = Read-RequestJson -Request $request
                    $preview = Get-MembershipPreview `
                        -SourceCollectionId ([string]$body.sourceCollectionId) `
                        -TargetCollectionId ([string]$body.targetCollectionId)

                    Send-Json -Context $context -Data @{
                        ok = $true
                        preview = $preview
                    }
                    break
                }
                '^POST /api/membership/add$' {
                    $body = Read-RequestJson -Request $request
                    $remote = if ($request.RemoteEndPoint) { $request.RemoteEndPoint.Address.ToString() } else { 'unknown' }
                    $user = [Security.Principal.WindowsIdentity]::GetCurrent().Name
                    $result = Add-ManagedDeploymentMembership -Body $body -UserName $user -RemoteAddress $remote

                    Send-Json -Context $context -Data @{
                        ok = $true
                        result = $result
                    } -StatusCode 201
                    break
                }
                '^POST /api/membership/remove$' {
                    $body = Read-RequestJson -Request $request
                    $remote = if ($request.RemoteEndPoint) { $request.RemoteEndPoint.Address.ToString() } else { 'unknown' }
                    $user = [Security.Principal.WindowsIdentity]::GetCurrent().Name
                    $result = Remove-ManagedDeploymentMembership -Body $body -UserName $user -RemoteAddress $remote

                    Send-Json -Context $context -Data @{
                        ok = $true
                        result = $result
                    }
                    break
                }
                '^POST /api/deployments/application$' {
                    $body = Read-RequestJson -Request $request
                    $remote = if ($request.RemoteEndPoint) { $request.RemoteEndPoint.Address.ToString() } else { 'unknown' }
                    $user = [Security.Principal.WindowsIdentity]::GetCurrent().Name
                    $result = New-ApplicationDeploymentFromRequest -Body $body -UserName $user -RemoteAddress $remote
                    Send-Json -Context $context -Data @{
                        ok = $true
                        message = 'Application deployment created successfully.'
                        deployment = $result
                    } -StatusCode 201
                    break
                }
                default {
                    Send-Json -Context $context -Data @{ ok = $false; error = 'Route not found.' } -StatusCode 404
                }
            }
        }
        catch {
            Write-Log -Level ERROR -Message $_.Exception.ToString()
            if ($context.Response.OutputStream.CanWrite) {
                Send-Json -Context $context -Data @{
                    ok = $false
                    error = $_.Exception.Message
                } -StatusCode 400
            }
        }
    }
}
finally {
    if ($listener.IsListening) { $listener.Stop() }
    $listener.Close()
    Write-Log 'SCCM Web Deployment Console stopped.'
}
