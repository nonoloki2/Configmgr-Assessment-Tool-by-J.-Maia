# ConfigMgr Health Assessment Tool

Ferramenta gráfica (PowerShell + WinForms) que coleta a saúde da infraestrutura
do Configuration Manager e gera um relatório HTML autocontido (sem CDN/internet),
com cards por servidor, abas por área, e **destaque em vermelho/âmbar em qualquer
aba/seção que tenha um problema** — inclusive a aba "Storage" quando há disco
crítico, que era o ponto que você notou na ferramenta de referência.

## Como usar

1. Copie `ConfigMgr-HealthAssessment.ps1` para uma estação com acesso ao SMS
   Provider (normalmente o próprio site server ou uma máquina com o console
   ConfigMgr instalado).
2. Rode como sua conta de admin do ConfigMgr (ou clique com botão direito >
   "Executar com PowerShell"). Se o Execution Policy bloquear, rode:
   ```powershell
   powershell.exe -ExecutionPolicy Bypass -File .\ConfigMgr-HealthAssessment.ps1
   ```
3. Preencha **Site Code** e **Servidor do Site Primário**.
4. (Opcional) marque "Usar credenciais alternativas" se sua conta atual não
   tiver admin local nos servidores de sistema de site.
5. Clique em **Executar Avaliação**. O log aparece em tempo real; ao final,
   clique em **Abrir Relatório**.

## Pré-requisitos

- Permissão de leitura no ConfigMgr (Read-Only Analyst já é suficiente para os
  dados do SMS Provider).
- Admin local / WinRM habilitado nos servidores de sistema de site para as
  checagens remotas (SO, disco, RAM/CPU, serviços, certificados IIS). Sem
  WinRM, essas seções aparecem como "Sem dados" mas o restante do relatório é
  gerado normalmente — nada quebra.
- Módulo **ActiveDirectory** (RSAT) opcional, usado apenas para "dispositivos
  sem cliente que logaram no domínio nos últimos 30 dias". Se não estiver
  instalado, a checagem é pulada com um aviso no relatório.
- Módulo **UpdateServices** (RSAT) opcional, usado para detalhar a última
  sincronização do WSUS. Sem ele, ainda reportamos o serviço `WsusService` e
  disco do WSUS.

## O que é coletado (mapeamento com o que você pediu)

| Pedido | Onde no script/relatório |
|---|---|
| Saúde dos DPs | Aba "Distribution Point" por servidor + card geral |
| Espaço em disco dos DPs/servidores | Aba "Storage", cards de disco coloridos por severidade |
| Serviços do Management Point | Aba "Services" (`SMS_EXECUTIVE`, `W3SVC`, `WAS`) |
| Serviços do IIS | Aba "Services" |
| Certificado IIS expirado/expirando em 60 dias | Aba "Services" → "IIS Certificates" |
| Memória RAM total + alerta 90% | Aba "Operating System" → "Performance" |
| Processamento (CPU) + alerta 90% | Aba "Operating System" → "Performance" |
| Data do último patch instalado | Aba "Operating System" → "Patch Evidence" |
| Content Status (somente erros) | Seção global "Content Distribution Status (somente erros)" + aba DP por servidor |
| Saúde do WSUS / SUP | Aba "Services" → "WSUS / SUP" |
| Boundaries sem grupo | Seção global "Boundaries sem Boundary Group" |
| Devices sem cliente (logon AD ≤30 dias) | Seção global "Dispositivos sem Cliente SCCM" |
| Clientes inativos | Seção global "Clientes Inativos" |
| Client Check Failed | Seção global "Client Check Failed" |
| Destaque vermelho em componente com problema | Toda aba (`tab-btn`) herda a cor do pior status encontrado naquela seção; o card do servidor também ganha uma borda colorida |

## Limitações conhecidas / pontos para ajuste fino no seu ambiente

- A classificação de "erro" em `SMS_PackageStatusDistPointsSummarizer` usa os
  estados `Install Failed` e `Removal Failed` (os mais universalmente
  reconhecidos como falha); se seu ambiente usa content monitoring com outros
  estados de erro, ajuste o hashtable `$errorStates` dentro de
  `Get-ContentDistributionErrors`.
- A saúde de MP é inferida por status de serviço (`SMS_EXECUTIVE`, IIS) e
  certificado; se quiser also validar o endpoint `/sms_mp/.sms_aut?mplist`,
  dá pra adicionar um `Invoke-WebRequest` dentro de `Get-ServerServiceHealth`
  facilmente.
- O cruzamento AD x SCCM assume que o nome do computador no AD bate com
  `SMS_R_System.Name`; em ambientes com múltiplos domínios/floresta, talvez
  seja necessário ajustar o filtro do `Get-ADComputer`.
- Os limiares (disco, RAM, CPU, patch, certificado) ficam centralizados em
  `Initialize-ScriptConfig` — fácil de ajustar para a política da sua empresa.

Qualquer ajuste que precisar (novos serviços, mais roles, outra fonte pra
saúde do WSUS, etc.) é só pedir que eu evoluo o script.
