$ErrorActionPreference = 'Stop'
$port = 8765
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$url = "http://localhost:$port/"

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($url)
try {
    $listener.Start()
} catch {
    Write-Host "Unable to start local server on port $port." -ForegroundColor Red
    Write-Host $_.Exception.Message
    Read-Host "Press Enter to close"
    exit 1
}

Write-Host "Software Packaging Management is running at $url" -ForegroundColor Green
Write-Host "Keep this window open while using the application." -ForegroundColor Yellow
Start-Process $url

$mime = @{
    '.html'='text/html; charset=utf-8'; '.js'='application/javascript; charset=utf-8';
    '.css'='text/css; charset=utf-8'; '.json'='application/json; charset=utf-8';
    '.png'='image/png'; '.jpg'='image/jpeg'; '.jpeg'='image/jpeg'; '.svg'='image/svg+xml';
    '.pdf'='application/pdf'; '.txt'='text/plain; charset=utf-8'
}

try {
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $relative = [Uri]::UnescapeDataString($context.Request.Url.AbsolutePath.TrimStart('/'))
        if ([string]::IsNullOrWhiteSpace($relative)) { $relative = 'index.html' }
        $path = Join-Path $root $relative
        $resolvedRoot = [IO.Path]::GetFullPath($root)
        $resolvedPath = [IO.Path]::GetFullPath($path)
        if (-not $resolvedPath.StartsWith($resolvedRoot) -or -not (Test-Path $resolvedPath -PathType Leaf)) {
            $context.Response.StatusCode = 404
            $bytes = [Text.Encoding]::UTF8.GetBytes('Not found')
        } else {
            $ext = [IO.Path]::GetExtension($resolvedPath).ToLowerInvariant()
            $context.Response.ContentType = $(if ($mime.ContainsKey($ext)) {$mime[$ext]} else {'application/octet-stream'})
            $bytes = [IO.File]::ReadAllBytes($resolvedPath)
            $context.Response.StatusCode = 200
        }
        $context.Response.ContentLength64 = $bytes.Length
        $context.Response.OutputStream.Write($bytes,0,$bytes.Length)
        $context.Response.OutputStream.Close()
    }
} finally {
    $listener.Stop()
    $listener.Close()
}
