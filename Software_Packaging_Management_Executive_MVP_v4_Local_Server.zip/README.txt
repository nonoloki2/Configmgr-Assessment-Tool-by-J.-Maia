SOFTWARE PACKAGING MANAGEMENT - PDF IMPORT FIX

IMPORTANT: Do NOT open index.html directly.

1. Extract the entire ZIP to a normal folder.
2. Double-click START_APPLICATION.bat.
3. Keep the PowerShell window open.
4. The application opens at http://localhost:8765.
5. Click Import ServiceNow PDF and select the PDF.

Why this version is different
- The app no longer runs through file://.
- app.js is a classic script, not a blocked JavaScript module.
- PDF.js is loaded before app.js.
- PDF processing runs without a separate worker to avoid worker/CORS failures.

Internet requirement
The first PDF import requires access to cdnjs.cloudflare.com to load Mozilla PDF.js.
If this domain is blocked by the corporate network, use the built-in Paste PDF Text fallback.
