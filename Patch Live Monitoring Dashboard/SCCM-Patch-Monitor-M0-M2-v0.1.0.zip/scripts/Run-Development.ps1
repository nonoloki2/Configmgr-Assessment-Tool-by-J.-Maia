$ErrorActionPreference='Stop'
$root=Resolve-Path "$PSScriptRoot\.."
Start-Process dotnet -ArgumentList "run --project `"$root\src\SccmPatchMonitor.Worker\SccmPatchMonitor.Worker.csproj`"" -WorkingDirectory $root
Start-Process dotnet -ArgumentList "run --project `"$root\src\SccmPatchMonitor.Web\SccmPatchMonitor.Web.csproj`" --urls http://localhost:5088" -WorkingDirectory $root
Write-Output 'Web: http://localhost:5088'
