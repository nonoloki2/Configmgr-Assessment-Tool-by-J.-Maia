$ErrorActionPreference='Stop'
Write-Output 'SCCM Patch Monitor - development validation'
dotnet --info
Write-Output 'Restoring solution...'
dotnet restore "$PSScriptRoot\..\SccmPatchMonitor.sln"
Write-Output 'Building solution...'
dotnet build "$PSScriptRoot\..\SccmPatchMonitor.sln" -c Release --no-restore
Write-Output 'BUILD OK'
