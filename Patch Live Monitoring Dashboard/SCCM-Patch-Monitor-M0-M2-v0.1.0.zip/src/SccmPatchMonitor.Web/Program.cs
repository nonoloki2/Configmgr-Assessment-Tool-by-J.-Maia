using Microsoft.EntityFrameworkCore;
using SccmPatchMonitor.Domain;
using SccmPatchMonitor.Infrastructure;

var builder=WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<PatchMonitorDbContext>(o=>o.UseNpgsql(builder.Configuration.GetConnectionString("Postgres")));
builder.Services.AddScoped<ISccmPatchSource,SccmPatchSource>();
var app=builder.Build();
app.UseDefaultFiles(); app.UseStaticFiles();

app.MapGet("/health", async (PatchMonitorDbContext db)=> {
    var ok=await db.Database.CanConnectAsync(); return Results.Ok(new { status=ok?"Healthy":"Degraded", service="SccmPatchMonitor.Web", database=ok?"Healthy":"Unavailable", version="0.1.0", timestamp=DateTimeOffset.UtcNow });
});
app.MapGet("/api/sccm/deployments", async (ISccmPatchSource s, CancellationToken ct)=>Results.Ok(await s.GetDeploymentsAsync(ct)));
app.MapGet("/api/monitors", async (PatchMonitorDbContext db)=>Results.Ok(await db.PatchMonitors.OrderBy(x=>x.Name).ToListAsync()));
app.MapGet("/api/monitors/{id:guid}/runs", async (Guid id, PatchMonitorDbContext db)=>Results.Ok(await db.MonitorRuns.Where(x=>x.PatchMonitorId==id).OrderByDescending(x=>x.StartedAt).Take(100).ToListAsync()));
app.MapGet("/api/monitors/{id:guid}/latest-devices", async (Guid id, PatchMonitorDbContext db)=> {
    var run=await db.MonitorRuns.Where(x=>x.PatchMonitorId==id && x.State==MonitorRunState.Succeeded).OrderByDescending(x=>x.StartedAt).FirstOrDefaultAsync();
    return run is null?Results.Ok(Array.Empty<object>()):Results.Ok(await db.DeviceSnapshots.Where(x=>x.MonitorRunId==run.Id).OrderBy(x=>x.ComputerName).ToListAsync());
});
app.MapPost("/api/monitors", async (CreateMonitorRequest req, PatchMonitorDbContext db, ISccmPatchSource s, CancellationToken ct)=> {
    if(req.FrequencyMinutes < 15) return Results.BadRequest(new {error="Minimum frequency is 15 minutes."});
    var dep=(await s.GetDeploymentsAsync(ct)).FirstOrDefault(x=>x.AssignmentId==req.AssignmentId);
    if(dep is null) return Results.BadRequest(new {error="Selected ConfigMgr deployment no longer exists."});
    var m=new PatchMonitor{Name=string.IsNullOrWhiteSpace(req.Name)?dep.Name:req.Name.Trim(),AssignmentId=dep.AssignmentId,DeploymentName=dep.Name,CollectionId=dep.CollectionId,CollectionName=dep.CollectionName,FrequencyMinutes=req.FrequencyMinutes,NextRunAt=DateTimeOffset.UtcNow};
    db.Add(m); await db.SaveChangesAsync(ct); return Results.Created($"/api/monitors/{m.Id}",m);
});
app.MapPut("/api/monitors/{id:guid}", async (Guid id, UpdateMonitorRequest req, PatchMonitorDbContext db)=> {
    var m=await db.PatchMonitors.FindAsync(id); if(m is null)return Results.NotFound();
    m.Name=req.Name.Trim(); m.FrequencyMinutes=Math.Max(15,req.FrequencyMinutes); m.State=req.Enabled?PatchMonitorState.Enabled:PatchMonitorState.Paused; m.UpdatedAt=DateTimeOffset.UtcNow;
    if(req.Enabled && m.NextRunAt<DateTimeOffset.UtcNow)m.NextRunAt=DateTimeOffset.UtcNow; await db.SaveChangesAsync(); return Results.Ok(m);
});
app.MapPost("/api/monitors/{id:guid}/run-now", async (Guid id, PatchMonitorDbContext db)=> { var m=await db.PatchMonitors.FindAsync(id); if(m is null)return Results.NotFound(); m.NextRunAt=DateTimeOffset.UtcNow; m.State=PatchMonitorState.Enabled; await db.SaveChangesAsync(); return Results.Accepted(); });
app.MapDelete("/api/monitors/{id:guid}", async (Guid id, PatchMonitorDbContext db)=> { var m=await db.PatchMonitors.FindAsync(id); if(m is null)return Results.NotFound(); db.Remove(m); await db.SaveChangesAsync(); return Results.NoContent(); });
app.MapGet("/api/overview", async (PatchMonitorDbContext db)=> {
    var monitors=await db.PatchMonitors.OrderBy(x=>x.Name).ToListAsync(); var ids=monitors.Select(x=>x.Id).ToList();
    var runs=await db.MonitorRuns.Where(x=>ids.Contains(x.PatchMonitorId) && x.State==MonitorRunState.Succeeded).OrderByDescending(x=>x.StartedAt).ToListAsync();
    var latest=runs.GroupBy(x=>x.PatchMonitorId).Select(g=>g.First()).ToDictionary(x=>x.PatchMonitorId);
    return Results.Ok(monitors.Select(m=>new {m.Id,m.Name,m.DeploymentName,m.CollectionName,m.FrequencyMinutes,m.State,m.LastRunAt,m.NextRunAt,m.LastRunStatus,latest=latest.TryGetValue(m.Id,out var r)?new {r.Total,r.Success,r.InProgress,r.Error,r.Unknown,r.CompliancePercent,r.ResolvedKbs}:null}));
});

using(var scope=app.Services.CreateScope()){var db=scope.ServiceProvider.GetRequiredService<PatchMonitorDbContext>(); await db.Database.EnsureCreatedAsync();}
app.Run();
record CreateMonitorRequest(string Name,int AssignmentId,int FrequencyMinutes);
record UpdateMonitorRequest(string Name,int FrequencyMinutes,bool Enabled);
