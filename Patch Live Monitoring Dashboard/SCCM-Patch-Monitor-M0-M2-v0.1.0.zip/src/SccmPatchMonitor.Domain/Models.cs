namespace SccmPatchMonitor.Domain;

public enum PatchMonitorState { Enabled, Paused }
public enum MonitorRunState { Running, Succeeded, Failed }

public sealed class PatchMonitor
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = "";
    public int AssignmentId { get; set; }
    public string DeploymentName { get; set; } = "";
    public string CollectionId { get; set; } = "";
    public string CollectionName { get; set; } = "";
    public int FrequencyMinutes { get; set; } = 60;
    public PatchMonitorState State { get; set; } = PatchMonitorState.Enabled;
    public DateTimeOffset? LastRunAt { get; set; }
    public DateTimeOffset NextRunAt { get; set; } = DateTimeOffset.UtcNow;
    public string? LastRunStatus { get; set; }
    public string? LastError { get; set; }
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset UpdatedAt { get; set; } = DateTimeOffset.UtcNow;
}

public sealed class MonitorRun
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid PatchMonitorId { get; set; }
    public DateTimeOffset StartedAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? FinishedAt { get; set; }
    public MonitorRunState State { get; set; } = MonitorRunState.Running;
    public int Total { get; set; }
    public int Success { get; set; }
    public int InProgress { get; set; }
    public int Error { get; set; }
    public int Unknown { get; set; }
    public decimal CompliancePercent { get; set; }
    public string ResolvedKbs { get; set; } = "";
    public string? ErrorMessage { get; set; }
}

public sealed class DeviceSnapshot
{
    public long Id { get; set; }
    public Guid MonitorRunId { get; set; }
    public int ResourceId { get; set; }
    public string ComputerName { get; set; } = "";
    public string ComplianceBucket { get; set; } = "";
    public string DashboardStatus { get; set; } = "Unknown";
    public string? SccmStatusState { get; set; }
    public string? MatchedKbs { get; set; }
    public string? ErrorCode { get; set; }
    public DateTimeOffset CollectedAt { get; set; } = DateTimeOffset.UtcNow;
}

public sealed record SccmDeployment(int AssignmentId, string Name, string CollectionId, string CollectionName);
public sealed record CollectedDevice(int ResourceId, string ComputerName, bool QfeCompliant, string? MatchedKbs, string? SccmStatusState, string? ErrorCode, string DashboardStatus);
public sealed record PatchCollectionResult(string CollectionId, string CollectionName, string DeploymentName, string ResolvedKbs, IReadOnlyList<CollectedDevice> Devices);
