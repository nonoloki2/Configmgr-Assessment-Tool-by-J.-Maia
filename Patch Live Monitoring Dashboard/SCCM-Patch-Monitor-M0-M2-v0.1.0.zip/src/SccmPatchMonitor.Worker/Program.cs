using Microsoft.EntityFrameworkCore;
using SccmPatchMonitor.Infrastructure;
using SccmPatchMonitor.Worker;
var builder=Host.CreateApplicationBuilder(args);
builder.Services.AddWindowsService(o=>o.ServiceName="SCCM Patch Monitor Collector");
builder.Services.AddDbContextFactory<PatchMonitorDbContext>(o=>o.UseNpgsql(builder.Configuration.GetConnectionString("Postgres")));
builder.Services.AddSingleton<ISccmPatchSource,SccmPatchSource>();
builder.Services.AddHostedService<SchedulerWorker>();
await builder.Build().RunAsync();
