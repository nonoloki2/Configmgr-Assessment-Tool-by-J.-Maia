using Microsoft.EntityFrameworkCore;
using SccmPatchMonitor.Domain;
using SccmPatchMonitor.Infrastructure;
namespace SccmPatchMonitor.Worker;

public sealed class SchedulerWorker(ILogger<SchedulerWorker> log, IDbContextFactory<PatchMonitorDbContext> dbFactory, ISccmPatchSource source) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        log.LogInformation("Patch scheduler started. Minimum scheduler tick: 60 seconds.");
        while(!stoppingToken.IsCancellationRequested){try{await RunDueAsync(stoppingToken);}catch(Exception ex){log.LogError(ex,"Scheduler iteration failed");}await Task.Delay(TimeSpan.FromMinutes(1),stoppingToken);}
    }
    private async Task RunDueAsync(CancellationToken ct)
    {
        await using var db=await dbFactory.CreateDbContextAsync(ct);
        var now=DateTimeOffset.UtcNow; var due=await db.PatchMonitors.Where(x=>x.State==PatchMonitorState.Enabled && x.NextRunAt<=now).OrderBy(x=>x.NextRunAt).Take(5).ToListAsync(ct);
        foreach(var m in due) await CollectOneAsync(m,ct);
    }
    private async Task CollectOneAsync(PatchMonitor m,CancellationToken ct)
    {
        // Claim before work to prevent the same monitor from being picked every scheduler tick.
        await using(var claim=await dbFactory.CreateDbContextAsync(ct)){var dbm=await claim.PatchMonitors.FindAsync([m.Id],ct);if(dbm is null)return;dbm.NextRunAt=DateTimeOffset.UtcNow.AddMinutes(Math.Max(15,dbm.FrequencyMinutes));dbm.LastRunStatus="Running";await claim.SaveChangesAsync(ct);}
        var run=new MonitorRun{PatchMonitorId=m.Id,StartedAt=DateTimeOffset.UtcNow,State=MonitorRunState.Running};
        try{
            await using(var db=await dbFactory.CreateDbContextAsync(ct)){db.Add(run);await db.SaveChangesAsync(ct);}
            var result=await source.CollectAsync(m.AssignmentId,ct); var devices=result.Devices; run.Total=devices.Count;run.Success=devices.Count(x=>x.DashboardStatus=="Success");run.InProgress=devices.Count(x=>x.DashboardStatus=="InProgress");run.Error=devices.Count(x=>x.DashboardStatus=="Error");run.Unknown=devices.Count(x=>x.DashboardStatus=="Unknown");run.CompliancePercent=run.Total==0?0:Math.Round((decimal)run.Success*100/run.Total,2);run.ResolvedKbs=result.ResolvedKbs;run.State=MonitorRunState.Succeeded;run.FinishedAt=DateTimeOffset.UtcNow;
            await using var db=await dbFactory.CreateDbContextAsync(ct); db.MonitorRuns.Update(run);db.DeviceSnapshots.AddRange(devices.Select(d=>new DeviceSnapshot{MonitorRunId=run.Id,ResourceId=d.ResourceId,ComputerName=d.ComputerName,ComplianceBucket=d.QfeCompliant?"Compliant":"NonCompliant",DashboardStatus=d.DashboardStatus,SccmStatusState=d.SccmStatusState,MatchedKbs=d.MatchedKbs,ErrorCode=d.ErrorCode,CollectedAt=DateTimeOffset.UtcNow}));var dbm=await db.PatchMonitors.FindAsync([m.Id],ct);if(dbm is not null){dbm.LastRunAt=run.FinishedAt;dbm.LastRunStatus="Succeeded";dbm.LastError=null;dbm.DeploymentName=result.DeploymentName;dbm.CollectionId=result.CollectionId;dbm.CollectionName=result.CollectionName;}await db.SaveChangesAsync(ct); log.LogInformation("Monitor {Name}: {Success}/{Total} QFE compliant ({Percent}%).",m.Name,run.Success,run.Total,run.CompliancePercent);
        }catch(Exception ex){run.State=MonitorRunState.Failed;run.FinishedAt=DateTimeOffset.UtcNow;run.ErrorMessage=ex.Message;await using var db=await dbFactory.CreateDbContextAsync(ct);db.MonitorRuns.Update(run);var dbm=await db.PatchMonitors.FindAsync([m.Id],ct);if(dbm is not null){dbm.LastRunAt=run.FinishedAt;dbm.LastRunStatus="Failed";dbm.LastError=ex.Message;}await db.SaveChangesAsync(ct);log.LogError(ex,"Monitor {Name} failed",m.Name);}
    }
}
