using Microsoft.Data.SqlClient;
using SccmPatchMonitor.Domain;

namespace SccmPatchMonitor.Infrastructure;

public interface ISccmPatchSource
{
    Task<IReadOnlyList<SccmDeployment>> GetDeploymentsAsync(CancellationToken ct);
    Task<PatchCollectionResult> CollectAsync(int assignmentId, CancellationToken ct);
}

public sealed class SccmPatchSource(IConfiguration config) : ISccmPatchSource
{
    private readonly string _cs = config.GetConnectionString("ConfigMgr") ?? throw new InvalidOperationException("ConnectionStrings:ConfigMgr is required.");

    public async Task<IReadOnlyList<SccmDeployment>> GetDeploymentsAsync(CancellationToken ct)
    {
        const string sql = """
SELECT DISTINCT
    cia.AssignmentID,
    cia.AssignmentName,
    cia.CollectionID,
    COALESCE(coll.Name, cia.CollectionID) AS CollectionName
FROM v_CIAssignment AS cia
JOIN v_CIAssignmentToCI AS map ON map.AssignmentID = cia.AssignmentID
JOIN v_UpdateCIs AS upd ON upd.CI_ID = map.CI_ID
LEFT JOIN v_Collection AS coll ON coll.CollectionID = cia.CollectionID
WHERE upd.ArticleID IS NOT NULL AND upd.ArticleID <> ''
ORDER BY cia.AssignmentName DESC;
""";
        var result = new List<SccmDeployment>();
        await using var c = new SqlConnection(_cs); await c.OpenAsync(ct);
        await using var cmd = new SqlCommand(sql, c) { CommandTimeout = 120 };
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct))
            result.Add(new(r.GetInt32(0), r.IsDBNull(1)?$"Assignment {r.GetInt32(0)}":r.GetString(1), r.IsDBNull(2)?"":r.GetString(2), r.IsDBNull(3)?"":r.GetString(3)));
        return result;
    }

    public async Task<PatchCollectionResult> CollectAsync(int assignmentId, CancellationToken ct)
    {
        const string metaSql = """
DECLARE @AssignmentID INT = @id;
SELECT TOP 1 cia.AssignmentName, cia.CollectionID, COALESCE(coll.Name, cia.CollectionID)
FROM v_CIAssignment cia LEFT JOIN v_Collection coll ON coll.CollectionID=cia.CollectionID
WHERE cia.AssignmentID=@AssignmentID;
SELECT STRING_AGG('KB'+upd.ArticleID, ', ')
FROM (SELECT DISTINCT upd.ArticleID FROM v_CIAssignmentToCI map JOIN v_UpdateCIs upd ON upd.CI_ID=map.CI_ID
      WHERE map.AssignmentID=@AssignmentID AND upd.ArticleID IS NOT NULL AND upd.ArticleID<>'') upd;
""";
        await using var c = new SqlConnection(_cs); await c.OpenAsync(ct);
        string dep, cid, cname, kbs;
        await using (var cmd = new SqlCommand(metaSql,c) { CommandTimeout=120 }) {
            cmd.Parameters.AddWithValue("@id", assignmentId);
            await using var r=await cmd.ExecuteReaderAsync(ct);
            if(!await r.ReadAsync(ct)) throw new InvalidOperationException($"AssignmentID {assignmentId} was not found in ConfigMgr.");
            dep=r.IsDBNull(0)?$"Assignment {assignmentId}":r.GetString(0); cid=r.IsDBNull(1)?"":r.GetString(1); cname=r.IsDBNull(2)?cid:r.GetString(2);
            await r.NextResultAsync(ct); kbs=(await r.ReadAsync(ct) && !r.IsDBNull(0))?r.GetString(0):"";
        }
        if(string.IsNullOrWhiteSpace(cid)) throw new InvalidOperationException($"AssignmentID {assignmentId} has no target collection.");
        if(string.IsNullOrWhiteSpace(kbs)) throw new InvalidOperationException($"No KB ArticleID was resolved for AssignmentID {assignmentId}.");

        const string dataSql = """
DECLARE @AssignmentID INT=@id, @CollectionID NVARCHAR(16)=@collection;
WITH KBList AS (
  SELECT DISTINCT UPPER('KB'+upd.ArticleID) KB
  FROM v_CIAssignmentToCI map JOIN v_UpdateCIs upd ON upd.CI_ID=map.CI_ID
  WHERE map.AssignmentID=@AssignmentID AND upd.ArticleID IS NOT NULL AND upd.ArticleID<>''
), Members AS (
  SELECT fcm.ResourceID FROM v_FullCollectionMembership fcm WHERE fcm.CollectionID=@CollectionID
), AssignmentData AS (
  SELECT cas.ResourceID, sn.StateName, cas.LastEnforcementErrorCode
  FROM v_CIAssignmentStatus cas
  LEFT JOIN v_AssignmentState_Combined assc ON assc.AssignmentID=cas.AssignmentID AND assc.ResourceID=cas.ResourceID
  LEFT JOIN v_StateNames sn ON sn.TopicType=assc.StateType AND sn.StateID=ISNULL(assc.StateID,0)
  WHERE cas.AssignmentID=@AssignmentID
)
SELECT m.ResourceID, rs.Name0,
  CASE WHEN EXISTS (SELECT 1 FROM v_GS_QUICK_FIX_ENGINEERING q JOIN KBList k ON UPPER(q.HotFixID0)=k.KB WHERE q.ResourceID=m.ResourceID) THEN 1 ELSE 0 END QfeCompliant,
  STUFF((SELECT ', '+q.HotFixID0 FROM v_GS_QUICK_FIX_ENGINEERING q JOIN KBList k ON UPPER(q.HotFixID0)=k.KB WHERE q.ResourceID=m.ResourceID FOR XML PATH(''),TYPE).value('.','nvarchar(max)'),1,2,'') MatchedKbs,
  ad.StateName,
  CASE WHEN ad.LastEnforcementErrorCode IS NULL OR ad.LastEnforcementErrorCode=0 THEN NULL ELSE CONCAT('0x',RIGHT(CONCAT('00000000',CONVERT(varchar(8),CONVERT(varbinary(4),ad.LastEnforcementErrorCode),2)),8)) END ErrorCode
FROM Members m JOIN v_R_System rs ON rs.ResourceID=m.ResourceID LEFT JOIN AssignmentData ad ON ad.ResourceID=m.ResourceID
ORDER BY rs.Name0;
""";
        var devices=new List<CollectedDevice>();
        await using(var cmd=new SqlCommand(dataSql,c){CommandTimeout=300}) {
            cmd.Parameters.AddWithValue("@id",assignmentId); cmd.Parameters.AddWithValue("@collection",cid);
            await using var r=await cmd.ExecuteReaderAsync(ct);
            while(await r.ReadAsync(ct)) {
                var compliant=r.GetInt32(2)==1; var state=r.IsDBNull(4)?null:r.GetString(4); var err=r.IsDBNull(5)?null:r.GetString(5);
                var status=Classify(compliant,state,err);
                devices.Add(new(r.GetInt32(0),r.IsDBNull(1)?$"Resource {r.GetInt32(0)}":r.GetString(1),compliant,r.IsDBNull(3)?null:r.GetString(3),state,err,status));
            }
        }
        return new(cid,cname,dep,kbs,devices);
    }

    private static string Classify(bool qfe, string? state, string? error)
    {
        if(qfe) return "Success"; // v2.9.6 baseline rule: QFE evidence wins.
        var s=(state??"").ToLowerInvariant();
        if(!string.IsNullOrWhiteSpace(error) || s.Contains("error") || s.Contains("fail")) return "Error";
        if(s.Contains("progress") || s.Contains("wait") || s.Contains("download") || s.Contains("install") || s.Contains("pending")) return "InProgress";
        return "Unknown"; // SCCM success without QFE must never inflate Success.
    }
}
