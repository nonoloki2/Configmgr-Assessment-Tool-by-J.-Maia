using Microsoft.EntityFrameworkCore;
using SccmPatchMonitor.Domain;

namespace SccmPatchMonitor.Infrastructure;

public sealed class PatchMonitorDbContext(DbContextOptions<PatchMonitorDbContext> options) : DbContext(options)
{
    public DbSet<PatchMonitor> PatchMonitors => Set<PatchMonitor>();
    public DbSet<MonitorRun> MonitorRuns => Set<MonitorRun>();
    public DbSet<DeviceSnapshot> DeviceSnapshots => Set<DeviceSnapshot>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<PatchMonitor>(e => {
            e.ToTable("patch_monitors"); e.HasKey(x => x.Id); e.HasIndex(x => x.AssignmentId);
            e.Property(x => x.Name).HasMaxLength(180); e.Property(x => x.DeploymentName).HasMaxLength(300);
            e.Property(x => x.CollectionId).HasMaxLength(16); e.Property(x => x.CollectionName).HasMaxLength(300);
        });
        b.Entity<MonitorRun>(e => {
            e.ToTable("monitor_runs"); e.HasKey(x => x.Id); e.HasIndex(x => new { x.PatchMonitorId, x.StartedAt });
            e.Property(x => x.CompliancePercent).HasPrecision(6,2);
        });
        b.Entity<DeviceSnapshot>(e => {
            e.ToTable("device_snapshots"); e.HasKey(x => x.Id); e.HasIndex(x => new { x.MonitorRunId, x.DashboardStatus });
            e.Property(x => x.ComputerName).HasMaxLength(255); e.Property(x => x.ErrorCode).HasMaxLength(32);
        });
    }
}
