SCCM Patch Dashboard v2.9.5 - Server-Side Safe

BASELINE SAFETY
- Main patch compliance query is unchanged from v2.9.3/2.9.4 baseline.
- Success / In Progress / Error / Unknown calculations are unchanged.
- Top 3 error enrichment remains SMS Provider-side only.

NO REAL-TIME ENDPOINT ACCESS
- Unattended flow does not run Domain Trust.
- No live pending-reboot buttons are emitted in detail HTML.
- Endpoint Health uses SCCM SQL inventory/status only.
- Preferred DP enrichment uses SMS Provider only, in bulk/batches; no per-device endpoint access.

ENDPOINT HEALTH (separate from patch columns)
- Disk WARNING: >5% and <=15% free on C:. Yellow oval badge.
- Disk CRITICAL: <=5% free on C:. Red oval badge.
- Disk detail page has Status filter: Warning / Critical.
- Client Check Failed: SCCM client-health data.
- Inactive >30 days: SCCM client activity data.
- Percentages use total devices in the deployment collection.

PATCH DETAIL CLEANUP
- Domain Trust / Trust Detail / AD Computer removed from normal patch drill-down pages.
- Preferred Distribution Points restored via the same provider-side Boundary Group approach used in v2.8.
- DP values are shortened to hostname only (no FQDN) to keep the report compact.

FAIL-SAFE
- Endpoint Health failure is WARN-only and never prevents the Patch Report.
- Preferred DP failure is WARN-only and never changes patch population/status.
