SCCM Patch Dashboard v2.9.4 - Endpoint Health Safe

Goal: add independent operational health indicators without changing patch compliance logic.

Added:
- Low Disk Space on C: (default: <20 GB free; configurable in Run-Unattended.ps1)
- Client Check Failed
- Inactive >30 days (ClientStatus=Inactive AND LastActiveTime older than threshold)
- Separate HTML + CSV drill-down for each indicator
- Main dashboard receives only counts and percentages in a separate Endpoint Health block

Safety:
- 01_Compliance_Query_AutoResolve.sql is unchanged from v2.9.3 PatchOnlySafe.
- Endpoint Health uses an independent SELECT against the same target collection.
- Health-query failure is WARN-only and does not block Patch Report generation.
- No Endpoint Health columns are added to Success/InProgress/Error/Unknown detail pages.
- Domain Trust remains disabled by default.
