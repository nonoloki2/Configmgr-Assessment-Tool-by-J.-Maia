SCCM Patch Dashboard v2.9.6 - QFE Compliance Baseline

ONLY functional change from v2.9.5:
- Compliance classification now follows the corporate query validated in SSMS:
  Compliant     = EXISTS at least one cycle KB in v_GS_QUICK_FIX_ENGINEERING.
  Non-Compliant = NOT EXISTS any cycle KB in v_GS_QUICK_FIX_ENGINEERING.
- Cycle KBs remain auto-resolved from the selected deployment, preserving unattended operation.

UNTOUCHED from v2.9.5:
- Deployment resolver
- Top 3 error enrichment
- Management Point
- Preferred Distribution Points
- Disk Space / Endpoint Health
- HTML layout and drill-downs
- CSV behavior already present in v2.9.5
- History logic
- NO-ENDPOINT safety mode
- No live endpoint queries

Expected validation reference from the SSMS test supplied by the user:
TotalDevices=10272, CompliantByKB=9977, NonCompliantByKB=295
(The live collection membership can change between executions.)
