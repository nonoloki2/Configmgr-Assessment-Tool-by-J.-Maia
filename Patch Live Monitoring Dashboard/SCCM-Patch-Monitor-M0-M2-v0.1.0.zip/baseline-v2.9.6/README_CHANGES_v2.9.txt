SCCM Monthly Patch Dashboard - v2.9 Trust Health + Top 3 Error Restore
=====================================================================

WHAT CHANGED

1) TOP 3 ERRORS RESTORED
- The SQL-only rewrite was using only v_CIAssignmentStatus.LastEnforcementErrorCode.
- The original v2.8 used SMS_SUMDeploymentAssetDetails and prioritized StatusErrorCode,
  falling back to LastEnforcementErrorCode.
- Run-Unattended.ps1 now keeps SQL as the primary source and optionally enriches
  Error devices from SMS_SUMDeploymentAssetDetails through the SMS Provider.
- If the Provider cannot be reached, the report still completes using the SQL fallback.
- Top 3 now considers only DeploymentStatus=Error and excludes zero/blank codes.
- The execution log records the number of distinct error codes and the top counts.

2) DOMAIN TRUST HEALTH
- New standalone dashboard section, deliberately separated from patch compliance.
- AD Computer status is checked via LDAP without requiring the ActiveDirectory module.
- Missing/disabled computer accounts are reported as AD issue.
- For other devices, the runner attempts a parallel remote Test-ComputerSecureChannel.
- SecureChannel=False is reported as Broken.
- Offline/WinRM/firewall/auth failures are Unverified, NOT falsely classified as Broken.
- Separate exports are generated:
    Devices_DomainTrust_Issues.html
    Devices_DomainTrust_Issues.csv
- Detail tables include AD Computer, Domain Trust and Trust Detail columns.

CONFIGURATION
Run-Unattended.ps1 contains two switches:
    $EnableSmsProviderErrorEnrichment = $true
    $EnableDomainTrustHealth          = $true

IMPORTANT REQUIREMENTS
- SQL access remains required exactly as before.
- SMS Provider enrichment requires WMI/CIM network access and ConfigMgr permissions.
  Failure is non-fatal and falls back to SQL error codes.
- Secure-channel verification requires PowerShell remoting/WinRM to the endpoints.
  Devices that cannot be remotely tested are marked Unverified.
- LDAP AD lookup uses the domain context of the account running the scheduled script.

PATCH STATUS SAFETY
Domain Trust Health never changes Success / In Progress / Error / Unknown counts.
