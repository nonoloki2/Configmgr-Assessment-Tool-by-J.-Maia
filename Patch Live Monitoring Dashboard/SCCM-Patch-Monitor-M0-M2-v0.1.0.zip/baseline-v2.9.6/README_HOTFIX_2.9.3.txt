SCCM Patch Dashboard v2.9.3 - Resolver Safe

Correção única desta versão:
- O resolver do deployment aceita sufixos válidos DEPOIS do YYYY-MM.
- YYYY-MM precisa aparecer imediatamente após o prefixo fixo do deployment.
- Impede que "...2026 - 07 - 08 - NBU All" seja interpretado como agosto.
- Se o deployment do mês atual ainda não existir no Patch Tuesday, usa o deployment mais recente do mês anterior pela mesma regra segura.

Nenhuma alteração foi feita na lógica de Success/In Progress/Error/Unknown, HTML, histórico, Top 3 ou Domain Trust em relação à v2.9.
