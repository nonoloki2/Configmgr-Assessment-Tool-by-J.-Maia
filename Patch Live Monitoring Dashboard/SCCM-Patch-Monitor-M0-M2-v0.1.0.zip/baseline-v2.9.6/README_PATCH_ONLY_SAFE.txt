SCCM Patch Dashboard v2.9.3 - Patch Only Safe

Purpose of this build:
- Domain Trust is DISABLED by default.
- Patch report does not depend on Domain Trust being enabled.
- Defensive defaults prevent an unset optional variable from aborting the script.
- SMS Provider error enrichment remains enabled for Top 3 Errors validation.
- Resolver logic is unchanged from v2.9.3.

Run normally:
  .\Run-Unattended.ps1

Do not edit any variables for this validation run.
