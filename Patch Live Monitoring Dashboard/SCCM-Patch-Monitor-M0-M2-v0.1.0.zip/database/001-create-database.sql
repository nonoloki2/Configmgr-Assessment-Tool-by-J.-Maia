-- Run as PostgreSQL administrator. Change the password before use.
CREATE USER sccmpatch_app WITH PASSWORD 'CHANGE_ME';
CREATE DATABASE sccm_patch_monitor OWNER sccmpatch_app;
