# SCCM Patch Monitor — v0.1.0 (M0–M2 Candidate)

This package starts the migration of **SCCM PatchDashboard v2.9.6 QFECompliance** from a static report into a persistent web monitoring platform.

## Frozen rule from v2.9.6

Patch **Success** is based on evidence that at least one KB belonging to the selected deployment exists in `v_GS_QUICK_FIX_ENGINEERING`. A ConfigMgr deployment state of Success without QFE evidence does **not** increase compliance.

## Implemented in this candidate

- .NET 10 solution with Web + Windows Worker + Infrastructure + Domain.
- PostgreSQL persistent storage.
- Multiple independent Patch Monitors.
- Each monitor stores exactly the two core scheduling choices requested: **Deployment** and **Frequency** (plus an optional friendly name).
- Web dropdown discovers Software Updates deployments dynamically from ConfigMgr SQL views.
- Frequencies: 30m, 1h, 2h, 4h, 6h, 12h, daily. Backend minimum is 15 minutes.
- `Run now` support.
- Worker checks due monitors every minute and persists every run/device snapshot.
- QFE compliance collection is parameterized by `AssignmentID`; it no longer depends on a monthly deployment-name pattern.
- Browser reads PostgreSQL through the Web API; it never connects to endpoints.
- Left navigation already reserves **Endpoint Health** as a future independent module, but no new health scope was added.
- Original v2.9.6 package is retained under `baseline-v2.9.6/` for regression reference.

## Important validation status

This is a **candidate**, not a frozen stable milestone. The build environment used to assemble this ZIP does not have the .NET SDK installed, so compilation against .NET 10 and live ConfigMgr/PostgreSQL execution must be validated on the target Windows machine before M0/M1/M2 are marked stable.

## First validation sequence on Windows

1. Install/confirm .NET 10 SDK and PostgreSQL.
2. Create the PostgreSQL database/user using `database/001-create-database.sql`.
3. Edit both `appsettings.json` files and set the PostgreSQL and ConfigMgr SQL connection strings.
4. Run PowerShell as Administrator:

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
.\scripts\Install-Development.ps1
```

5. Start both processes:

```powershell
.\scripts\Run-Development.ps1
```

6. Open `http://localhost:5088`.
7. Verify `/health`, deployment dropdown, create one monitor, click **Run now**, then confirm a successful snapshot appears.

## Milestone gate

Do not call this baseline stable until these are all true:

`BUILD OK -> POSTGRES OK -> CONFIGMGR DROPDOWN OK -> CREATE MONITOR OK -> WORKER RUN OK -> QFE COUNTS MATCH v2.9.6 -> WEB DASHBOARD OK`
