# SCCM Web Deployment Console — Release 1

## Scope

This first release creates **SCCM Application deployments to existing Device Collections**.

It supports:

- Partial search by application name, version, or manufacturer
- Display of every returned application, including duplicate display names
- Explicit selection by Application `CI_ID`
- Partial search by Device Collection name or Collection ID
- Explicit selection by `CollectionID`
- Install or Uninstall
- Available or Required
- Availability and deadline
- User notification behavior
- Maintenance-window and metered-network options
- Exact collection-name confirmation
- Configurable blocked collections
- Local audit log

## Requirements

- Windows Server or Windows workstation
- Configuration Manager console installed
- Windows PowerShell 5.1
- An account with SCCM RBAC permission to read applications/collections and create application deployments
- Network access to the SMS Provider
- Run the launcher in an elevated PowerShell session

## Configure

Edit `config.json`:

```json
{
  "SiteCode": "PR1",
  "SmsProvider": "YOUR-SMS-PROVIDER-FQDN",
  "ListenUrl": "http://localhost:8787/",
  "MaxSearchResults": 200,
  "EnableDeploymentCreation": true
}
```

Set `SmsProvider` to the server hosting the SCCM SMS Provider.

The initial `SiteCode` is already set to `PR1`; change it if this environment uses another site.

Review the blocked collection names and IDs before testing.

## Start

Open **Windows PowerShell 5.1 as Administrator**:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
cd C:\Path\SCCM_Web_Deployment_R1
.\Start-SCCMWebDeploy.ps1
```

Open:

```text
http://localhost:8787/
```

Press `Ctrl+C` in PowerShell to stop the server.

## First safe test

1. Create or use a small test Device Collection.
2. Search and select the exact Application row by version and CI_ID.
3. Select the test collection.
4. Use `Available` for the first validation.
5. Review the summary.
6. Type the exact collection name.
7. Create the deployment.
8. Confirm the deployment in **Monitoring > Deployments** in the SCCM console.

## Audit logs

Logs are written to:

```text
.\logs\SCCMWebDeploy-YYYYMMDD.log
```

## Important behavior

The interface searches using friendly names, but deployment creation uses:

- Application `CI_ID`
- Device Collection `CollectionID`

Immediately before the write operation, the backend retrieves both objects again and verifies the collection name.

## Troubleshooting

### ConfigurationManager module not found

Install the Configuration Manager console on the computer hosting the web console.

### Cannot listen on port 8787

Run PowerShell as Administrator. Alternatively, reserve the URL for the service account:

```cmd
netsh http add urlacl url=http://localhost:8787/ user=DOMAIN\UserName
```

### Access denied from SCCM

Verify the Windows account running the PowerShell process has the required SCCM security role and security scopes.

### Browser opens but searches fail

Review the PowerShell console and the file under `logs`.

## Release 1 limitations

- Localhost only by default
- Application deployments only
- Existing Device Collections only
- No package, program, SUG, single-device temporary collection, approval workflow, or monitoring donut yet
- Authentication is inherited from the Windows account running the backend; this release is intended for controlled local testing
