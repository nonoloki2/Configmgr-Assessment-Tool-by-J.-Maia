SOFTWARE PACKAGING MANAGEMENT - EXECUTIVE MVP

How to use
1. Extract the ZIP file.
2. Open index.html in Microsoft Edge, Google Chrome or Firefox.
3. Use "Import ServiceNow PDF" to extract and review task fields before registration.
4. Use "+ Manual Request" only when no ServiceNow PDF is available.
4. Register ServiceNow task information.
5. Data remains stored locally in the browser using localStorage.
6. Use "Export Report" to generate an executive HTML report.

Priority executive fields included
- Request Date
- Requested / Expected Delivery Target
- Developer Assigned
- SW Packaging Phase
  - Data Gathering
  - Packaging Work
  - Testing
- Deployment Phase
  - Rollout
  - Monitoring / Reporting

Important
- Do not clear browser site data, or local records will be removed.
- Use the same browser and the same index.html location.
- PDF import is included. The first import requires internet access because the browser loads the Mozilla PDF.js reader library from jsDelivr. Text-based PDFs are supported; scanned image-only PDFs require OCR.
