const PHASES=[
  {name:"New Request",progress:0},
  {name:"Data Gathering",progress:10},
  {name:"Packaging Work",progress:55},
  {name:"Testing",progress:75},
  {name:"Rollout",progress:90},
  {name:"Monitoring / Reporting",progress:95},
  {name:"Completed",progress:100}
];
const STATUSES=["Not Started","In Progress","Waiting Requestor","Blocked","Completed"];
const STORAGE_KEY="softwarePackagingRequestsV1";
let requests=JSON.parse(localStorage.getItem(STORAGE_KEY)||"[]");

const $=id=>document.getElementById(id);
const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[m]));
const today=()=>new Date(new Date().toDateString());
const dateObj=s=>s?new Date(s+"T00:00:00"):null;
const fmt=s=>s?dateObj(s).toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"}):"—";
function addCalendarDays(isoDate,days=15){
  if(!isoDate)return "";
  const d=dateObj(isoDate);
  if(!d||isNaN(d))return "";
  d.setDate(d.getDate()+days);
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}
function applyManualSla(){
  const requestDate=$("requestDate").value;
  if(requestDate)$("deliveryTarget").value=addCalendarDays(requestDate,15);
}
function applyImportSla(){
  const requestDate=$("impRequestDate").value;
  if(requestDate)$("impDeliveryTarget").value=addCalendarDays(requestDate,15);
}
const phaseProgress=p=>(PHASES.find(x=>x.name===p)||PHASES[0]).progress;
const isCompleted=r=>r.phase==="Completed"||r.status==="Completed";
const isLate=r=>!isCompleted(r)&&dateObj(r.deliveryTarget)&&dateObj(r.deliveryTarget)<today();
const dueWeek=r=>{if(isCompleted(r)||!r.deliveryTarget)return false;const d=dateObj(r.deliveryTarget),t=today(),e=new Date(t);e.setDate(t.getDate()+7);return d>=t&&d<=e};
function save(){localStorage.setItem(STORAGE_KEY,JSON.stringify(requests))}
function badge(value){let c="";const v=value.toLowerCase();if(v.includes("blocked")||v.includes("late"))c="blocked";else if(v.includes("completed"))c="completed";else if(v.includes("waiting"))c="waiting";return `<span class="badge ${c}">${esc(value)}</span>`}
function progressCell(p){return `<div class="mini-progress"><div class="mini-track"><div class="mini-fill" style="width:${p}%"></div></div><strong>${p}%</strong></div>`}

function initSelects(){
  $("phase").innerHTML=PHASES.map(x=>`<option>${x.name}</option>`).join("");
  $("phaseFilter").innerHTML='<option value="">All phases</option>'+PHASES.map(x=>`<option>${x.name}</option>`).join("");
  $("status").innerHTML=STATUSES.map(x=>`<option>${x}</option>`).join("");
  $("statusFilter").innerHTML='<option value="">All statuses</option>'+STATUSES.map(x=>`<option>${x}</option>`).join("");
}
function renderDashboard(){
  const total=requests.length, completed=requests.filter(isCompleted).length, late=requests.filter(isLate).length;
  const blocked=requests.filter(r=>r.status==="Blocked").length, inProgress=total-completed;
  const due=requests.filter(dueWeek).length;
  const avg=total?Math.round(requests.reduce((a,r)=>a+phaseProgress(r.phase),0)/total):0;
  $("kpiTotal").textContent=total;$("kpiCompleted").textContent=completed;$("kpiProgress").textContent=inProgress;
  $("kpiLate").textContent=late;$("kpiBlocked").textContent=blocked;$("kpiDueWeek").textContent=due;
  $("overallPct").textContent=avg+"%";$("progressRing").style.setProperty("--progress",avg);
  $("progressTotal").textContent=total;$("progressCompleted").textContent=completed;$("progressRemaining").textContent=total-completed;

  renderBars("phaseChart",PHASES.map(p=>({label:p.name,value:requests.filter(r=>r.phase===p.name).length})));
  const developers={};requests.filter(r=>!isCompleted(r)).forEach(r=>developers[r.developerAssigned||"Unassigned"]=(developers[r.developerAssigned||"Unassigned"]||0)+1);
  renderBars("developerChart",Object.entries(developers).map(([label,value])=>({label,value})).sort((a,b)=>b.value-a.value).slice(0,8));
  renderBars("deliveryChart",[
    {label:"Late",value:late,cls:"danger"},
    {label:"Due This Week",value:due,cls:"warning"},
    {label:"On Schedule",value:requests.filter(r=>!isCompleted(r)&&!isLate(r)&&!dueWeek(r)).length,cls:"success"},
    {label:"Completed",value:completed,cls:"success"}
  ]);
  const priority=[...requests].sort((a,b)=>{
    const score=r=>(isLate(r)?100:0)+(r.priority?.startsWith("1")?50:r.priority?.startsWith("2")?30:0)+(dueWeek(r)?20:0);
    return score(b)-score(a)||String(a.deliveryTarget).localeCompare(String(b.deliveryTarget));
  }).slice(0,8);
  $("priorityTable").innerHTML=priority.length?priority.map(r=>rowHtml(r,false)).join(""):`<tr><td colspan="8" class="empty">No requests registered yet.</td></tr>`;
}
function renderBars(id,items){
  const max=Math.max(1,...items.map(x=>x.value));
  $(id).innerHTML=items.length?items.map(x=>`<div class="bar-row ${x.cls||""}"><span class="bar-label" title="${esc(x.label)}">${esc(x.label)}</span><div class="bar-track"><div class="bar-fill" style="width:${(x.value/max)*100}%"></div></div><strong>${x.value}</strong></div>`).join(""):`<div class="empty">No data available.</div>`;
}
function rowHtml(r,actions=true){
  const late=isLate(r);
  return `<tr class="${late?"late-row":""}">
    <td><strong>${esc(r.taskNumber)}</strong></td><td>${esc(r.softwareName)}</td>
    ${actions?`<td>${esc(r.requestedBy)}</td>`:""}
    <td>${fmt(r.requestDate)}</td><td>${fmt(r.deliveryTarget)} ${late?badge("Late"):""}</td>
    <td>${esc(r.developerAssigned)}</td><td>${badge(r.phase)}</td><td>${badge(r.status)}</td>
    <td>${progressCell(phaseProgress(r.phase))}</td>
    ${actions?`<td><button class="action-btn" onclick="editRequest('${r.id}')">Edit</button></td>`:""}
  </tr>`;
}
function renderRequests(){
  const q=$("searchInput").value.trim().toLowerCase(), pf=$("phaseFilter").value, sf=$("statusFilter").value;
  const data=requests.filter(r=>{
    const text=[r.taskNumber,r.softwareName,r.requestedBy,r.requesterEmail,r.developerAssigned].join(" ").toLowerCase();
    return (!q||text.includes(q))&&(!pf||r.phase===pf)&&(!sf||r.status===sf);
  }).sort((a,b)=>String(a.deliveryTarget).localeCompare(String(b.deliveryTarget)));
  $("requestsTable").innerHTML=data.length?data.map(r=>rowHtml(r,true)).join(""):`<tr><td colspan="10" class="empty">No matching requests.</td></tr>`;
}
function showView(name){
  document.querySelectorAll(".view").forEach(v=>v.classList.remove("active"));
  document.querySelectorAll(".nav-item").forEach(v=>v.classList.remove("active"));
  $(name+"View").classList.add("active");
  document.querySelector(`[data-view="${name}"]`)?.classList.add("active");
  $("pageTitle").textContent=name==="dashboard"?"Executive Dashboard":"Software Requests";
  $("pageSubtitle").textContent=name==="dashboard"?"Software packaging portfolio status and delivery control":"Register, assign and track packaging and deployment requests";
  if(name==="dashboard")renderDashboard();else renderRequests();
}
function openModal(r=null){
  $("requestForm").reset();$("requestId").value=r?.id||"";
  $("modalTitle").textContent=r?"Edit Software Request":"New Software Request";
  $("deleteRequest").classList.toggle("hidden",!r);
  if(r){
    ["taskNumber","softwareName","requestedBy","requesterEmail","requestDate","deliveryTarget","developerAssigned","assignmentGroup","assignedTo","priority","phase","status","notes"].forEach(k=>$(k).value=r[k]??"");
    ["sourceFiles","prerequisites","documentation","requestorComplete"].forEach(k=>$(k).checked=!!r[k]);
  }else{
    $("requestDate").value=new Date().toISOString().slice(0,10);applyManualSla();$("phase").value="New Request";$("status").value="Not Started";
  }
  $("requestModal").showModal();
}
window.editRequest=id=>openModal(requests.find(r=>r.id===id));
function closeModal(){$("requestModal").close()}
function submitRequest(e){
  e.preventDefault();
  const id=$("requestId").value||crypto.randomUUID();
  const r={id};
  ["taskNumber","softwareName","requestedBy","requesterEmail","requestDate","deliveryTarget","developerAssigned","assignmentGroup","assignedTo","priority","phase","status","notes"].forEach(k=>r[k]=$(k).value.trim());
  ["sourceFiles","prerequisites","documentation","requestorComplete"].forEach(k=>r[k]=$(k).checked);
  r.updatedAt=new Date().toISOString();
  const idx=requests.findIndex(x=>x.id===id);if(idx>=0)requests[idx]=r;else requests.push(r);
  save();closeModal();renderDashboard();renderRequests();
}
function deleteCurrent(){
  const id=$("requestId").value;if(!id)return;
  if(confirm("Delete this request permanently?")){requests=requests.filter(r=>r.id!==id);save();closeModal();renderDashboard();renderRequests()}
}
function exportReport(){
  const rows=requests.map(r=>`<tr><td>${esc(r.taskNumber)}</td><td>${esc(r.softwareName)}</td><td>${fmt(r.requestDate)}</td><td>${fmt(r.deliveryTarget)}</td><td>${esc(r.developerAssigned)}</td><td>${esc(r.phase)}</td><td>${esc(r.status)}</td><td>${phaseProgress(r.phase)}%</td></tr>`).join("");
  const html=`<!doctype html><html><head><meta charset="utf-8"><title>Software Packaging Executive Report</title><style>body{font-family:Segoe UI,Arial;padding:30px;color:#172033}h1{margin-bottom:4px}.muted{color:#687386}table{width:100%;border-collapse:collapse;margin-top:22px}th,td{border-bottom:1px solid #ddd;padding:9px;text-align:left;font-size:12px}th{background:#173b75;color:#fff}.kpis{display:flex;gap:12px;margin-top:20px}.k{padding:14px 20px;border:1px solid #ddd;border-radius:10px}.k strong{display:block;font-size:26px}</style></head><body><h1>Software Packaging Executive Report</h1><div class="muted">Generated ${new Date().toLocaleString()}</div><div class="kpis"><div class="k">Total<strong>${requests.length}</strong></div><div class="k">Completed<strong>${requests.filter(isCompleted).length}</strong></div><div class="k">Late<strong>${requests.filter(isLate).length}</strong></div><div class="k">Blocked<strong>${requests.filter(r=>r.status==="Blocked").length}</strong></div></div><table><thead><tr><th>Task</th><th>Software</th><th>Request Date</th><th>Delivery Target</th><th>Developer</th><th>Phase</th><th>Status</th><th>Progress</th></tr></thead><tbody>${rows}</tbody></table></body></html>`;
  const blob=new Blob([html],{type:"text/html"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="Software_Packaging_Executive_Report.html";a.click();URL.revokeObjectURL(a.href);
}
document.querySelectorAll("[data-view]").forEach(b=>b.onclick=()=>showView(b.dataset.view));
document.querySelectorAll("[data-go-requests]").forEach(b=>b.onclick=()=>showView("requests"));
$("newRequestSide").onclick=()=>openModal();$("newRequestTop").onclick=()=>openModal();
$("closeModal").onclick=closeModal;$("cancelModal").onclick=closeModal;$("requestForm").onsubmit=submitRequest;$("deleteRequest").onclick=deleteCurrent;
$("exportBtn").onclick=exportReport;
["searchInput","phaseFilter","statusFilter"].forEach(id=>$(id).addEventListener("input",renderRequests));
$("clearFilters").onclick=()=>{$("searchInput").value="";$("phaseFilter").value="";$("statusFilter").value="";renderRequests()};
initSelects();renderDashboard();renderRequests();
$("requestDate").addEventListener("change",applyManualSla);
$("impRequestDate").addEventListener("change",applyImportSla);


// ServiceNow PDF import
const IMPORT_FIELDS=[
  "impTaskNumber","impSoftwareName","impRequestedBy","impRequesterEmail","impRequestDate","impDeliveryTarget","impDeveloperAssigned","impAssignmentGroup","impAssignedTo"
];
let pdfExtractedText="";

function openPdfImport(){
  $("pdfImportModal").showModal();
  $("pdfPreview").classList.add("hidden");
  $("pdfProcessing").classList.add("hidden");
  $("pdfError").classList.add("hidden");
  $("pdfDropZone").classList.remove("hidden");
  $("pdfFileInput").value="";
}
function closePdfImport(){ $("pdfImportModal").close(); }
function normalizeSpace(v){return String(v||"").replace(/\s+/g," ").trim()}
function escapeRx(v){return v.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}
function extractLabeled(text,labels,nextLabels){
  const all=[...labels,...nextLabels].map(escapeRx).join("|");
  for(const label of labels){
    const rx=new RegExp(`(?:^|\\n|\\s)${escapeRx(label)}\\s*[:\\-]?\\s*(.*?)(?=\\s+(?:${all})\\s*[:\\-]?|\\n|$)`,`i`);
    const m=text.match(rx); if(m&&normalizeSpace(m[1])) return normalizeSpace(m[1]);
  }
  return "";
}
function toISODate(value){
  if(!value)return "";
  const v=value.trim();
  let m=v.match(/(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/); if(m)return `${m[1]}-${m[2].padStart(2,"0")}-${m[3].padStart(2,"0")}`;
  m=v.match(/(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})/); if(m)return `${m[3]}-${m[2].padStart(2,"0")}-${m[1].padStart(2,"0")}`;
  const d=new Date(v); return isNaN(d)?"":d.toISOString().slice(0,10);
}
function mapPriority(v){
  const s=(v||"").toLowerCase();
  if(/critical|p1|1\s*-/.test(s))return "1 - Critical";
  if(/high|p2|2\s*-/.test(s))return "2 - High";
  if(/low|p4|4\s*-/.test(s))return "4 - Low";
  return "3 - Moderate";
}
function parseServiceNowText(raw){
  const text=raw.replace(/\u00a0/g," ").replace(/[ \t]+/g," ").replace(/\r/g,"\n");
  const labels=["Requested by","Requestor","Number","Opened","E-mail","Email","Assignment group","Assigned to","Priority","Premium software","Date needed by","Needed by","Due date","Short description","Description"];
  const get=(names)=>extractLabeled(text,names,labels);
  let number=get(["Number"]);
  if(!number){const m=text.match(/\b(?:SCTASK|RITM|REQ)\d+\b/i);number=m?m[0].toUpperCase():""}
  let email=get(["E-mail","Email"]);
  if(!email){const m=text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);email=m?m[0]:""}
  let software=get(["Premium software"]);
  if(!software) software=get(["Short description"]);
  return {
    taskNumber:number,
    softwareName:software,
    requestedBy:get(["Requested by","Requestor"]),
    requesterEmail:email,
    requestDate:toISODate(get(["Opened"])),
    deliveryTarget:addCalendarDays(toISODate(get(["Opened"])),15),
    developerAssigned:get(["Assigned to"]),
    assignmentGroup:get(["Assignment group"]),
    assignedTo:get(["Assigned to"]),
    priority:mapPriority(get(["Priority"]))
  };
}
async function readPdf(file){
  if(!window.pdfjsLib){
    throw new Error("The local browser blocked the PDF reader library. Use the Paste PDF Text fallback shown below.");
  }
  const data=new Uint8Array(await file.arrayBuffer());
  const doc=await window.pdfjsLib.getDocument({data, disableWorker:true}).promise;
  let pages=[];
  for(let n=1;n<=doc.numPages;n++){
    const page=await doc.getPage(n), content=await page.getTextContent();
    const items=content.items.filter(x=>x.str).sort((a,b)=>{
      const ay=a.transform?.[5]||0,by=b.transform?.[5]||0;
      return Math.abs(by-ay)>3?by-ay:(a.transform?.[4]||0)-(b.transform?.[4]||0);
    });
    let lines=[],current=[],lastY=null;
    for(const item of items){
      const y=item.transform?.[5]||0;
      if(lastY!==null&&Math.abs(y-lastY)>3){lines.push(current.join(" "));current=[]}
      current.push(item.str);lastY=y;
    }
    if(current.length)lines.push(current.join(" "));
    pages.push(lines.join("\n"));
  }
  return pages.join("\n\n");
}
function populateImport(data){
  const values={
    impTaskNumber:data.taskNumber,impSoftwareName:data.softwareName,impRequestedBy:data.requestedBy,
    impRequesterEmail:data.requesterEmail,impRequestDate:data.requestDate,impDeliveryTarget:data.deliveryTarget,
    impDeveloperAssigned:data.developerAssigned,impAssignmentGroup:data.assignmentGroup,impAssignedTo:data.assignedTo
  };
  let count=0;
  Object.entries(values).forEach(([id,v])=>{ $(id).value=v||"";$(id).classList.toggle("missing-field",!v);if(v)count++ });
  if(data.requestDate)data.deliveryTarget=addCalendarDays(data.requestDate,15);
  $("impPriority").value=data.priority;
  $("impPhase").value="New Request";$("impStatus").value="Not Started";
  $("recognizedCount").textContent=`${count} fields recognized`;
  $("pdfRawText").value=pdfExtractedText;
  $("pdfPreview").classList.remove("hidden");
}
async function handlePdf(file){
  if(!file||!file.name.toLowerCase().endsWith(".pdf")){ $("pdfError").textContent="Select a valid PDF file.";$("pdfError").classList.remove("hidden");return }
  $("pdfDropZone").classList.add("hidden");$("pdfPreview").classList.add("hidden");$("pdfError").classList.add("hidden");$("pdfProcessing").classList.remove("hidden");
  try{
    pdfExtractedText=await readPdf(file);
    if(!pdfExtractedText.trim())throw new Error("The PDF contains no extractable text. It may be a scanned image PDF.");
    populateImport(parseServiceNowText(pdfExtractedText));
  }catch(e){
    $("pdfError").innerHTML=`PDF import failed: ${esc(e.message)}<br><small>Use the Paste PDF Text fallback below if the browser blocks the PDF reader. Scanned image PDFs still require OCR.</small>`;
    $("pdfError").classList.remove("hidden");$("pdfDropZone").classList.remove("hidden");
  }finally{$("pdfProcessing").classList.add("hidden")}
}
function confirmPdfImport(){
  const required=["impTaskNumber","impSoftwareName","impRequestedBy","impRequesterEmail","impRequestDate","impDeliveryTarget","impDeveloperAssigned"];
  let missing=false;required.forEach(id=>{const x=$(id);const m=!x.value.trim();x.classList.toggle("missing-field",m);missing=missing||m});
  if(missing){$("pdfError").textContent="Complete all required yellow fields before creating the request.";$("pdfError").classList.remove("hidden");return}
  const r={id:crypto.randomUUID(),taskNumber:$("impTaskNumber").value.trim(),softwareName:$("impSoftwareName").value.trim(),requestedBy:$("impRequestedBy").value.trim(),requesterEmail:$("impRequesterEmail").value.trim(),requestDate:$("impRequestDate").value,deliveryTarget:$("impDeliveryTarget").value,developerAssigned:$("impDeveloperAssigned").value.trim(),assignmentGroup:$("impAssignmentGroup").value.trim(),assignedTo:$("impAssignedTo").value.trim(),priority:$("impPriority").value,phase:$("impPhase").value,status:$("impStatus").value,notes:"Imported from ServiceNow PDF",sourceFiles:false,prerequisites:false,documentation:false,requestorComplete:false,updatedAt:new Date().toISOString()};
  const duplicate=requests.find(x=>x.taskNumber.toLowerCase()===r.taskNumber.toLowerCase());
  if(duplicate&&!confirm(`Task ${r.taskNumber} already exists. Import another record anyway?`))return;
  requests.push(r);save();closePdfImport();renderDashboard();renderRequests();showView("requests");
}

$("impPhase").innerHTML=PHASES.map(x=>`<option>${x.name}</option>`).join("");
$("impStatus").innerHTML=STATUSES.map(x=>`<option>${x}</option>`).join("");
function choosePdf(){
  $("pdfFileInput").value="";
  $("pdfFileInput").click();
}
$("importPdfTop").addEventListener("click",choosePdf);
$("importPdfSide").addEventListener("click",choosePdf);
$("closePdfModal").addEventListener("click",closePdfImport);
$("cancelPdfImport").addEventListener("click",closePdfImport);
$("confirmPdfImport").addEventListener("click",confirmPdfImport);
$("pdfDropZone").addEventListener("click",choosePdf);
$("pdfFileInput").addEventListener("change",e=>{
  const file=e.target.files&&e.target.files[0];
  if(!file)return;
  openPdfImport();
  handlePdf(file);
});
$("parsePastedText").addEventListener("click",()=>{
  const text=$("pastedPdfText").value.trim();
  if(!text){$("pdfError").textContent="Paste the PDF text first.";$("pdfError").classList.remove("hidden");return;}
  pdfExtractedText=text;
  $("pdfDropZone").classList.add("hidden");
  $("pdfError").classList.add("hidden");
  populateImport(parseServiceNowText(text));
});
$("pdfDropZone").ondragover=e=>{e.preventDefault();$("pdfDropZone").classList.add("dragover")};
$("pdfDropZone").ondragleave=()=>$("pdfDropZone").classList.remove("dragover");
$("pdfDropZone").ondrop=e=>{e.preventDefault();$("pdfDropZone").classList.remove("dragover");handlePdf(e.dataTransfer.files[0])};
