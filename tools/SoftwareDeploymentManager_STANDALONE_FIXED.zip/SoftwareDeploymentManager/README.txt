SOFTWARE DEPLOYMENT MANAGER — STANDALONE FIX
============================================

This build uses a single index.html file.

Why
---
The previous build depended on external JavaScript files. If IIS failed to
serve one of those files, the visual interface loaded but all buttons stopped
working.

This version embeds the CSS and JavaScript directly in index.html.

IIS
---
1. Copy index.html to:
   C:\inetpub\SoftwareDeploymentManager\index.html

2. Create an IIS Application or Virtual Directory.

3. Browse to:
   http://YOUR-SERVER/SoftwareDeploymentManager/

4. Press Ctrl+F5.

Verified behavior
-----------------
- Top + New Package button opens the form.
- Sidebar New Package opens the form.
- Save Package stores the record.
- All Packages displays the saved record.
- IndexedDB is used when available.
- localStorage fallback is used if IndexedDB fails.
