@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-SCCM-PatchDashboard-Web.ps1"
echo.
echo The server stopped or an error occurred.
pause
