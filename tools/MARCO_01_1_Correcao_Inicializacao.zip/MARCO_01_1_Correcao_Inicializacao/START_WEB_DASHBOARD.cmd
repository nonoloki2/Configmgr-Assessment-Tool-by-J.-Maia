@echo off
setlocal
cd /d "%~dp0"
start "SCCM Patch Dashboard Backend" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-SCCM-PatchDashboard-Web.ps1"
exit /b 0
