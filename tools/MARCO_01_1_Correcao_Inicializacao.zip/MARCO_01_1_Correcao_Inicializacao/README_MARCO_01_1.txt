MARCO 01.1 - CORRECAO DE INICIALIZACAO

1. Do not modify or replace your stable script.
2. Extract this folder to a local path.
3. Double-click START_WEB_DASHBOARD.cmd.
4. The PowerShell backend will remain minimized because it must stay running.
5. The browser should open automatically.

If the browser does not open or the page does not load:
- Run START_DIAGNOSTIC_MODE.cmd instead.
- Keep the window open and capture the displayed error.

Important:
The PowerShell process is the local web server. Closing it stops the web page.
The stable v2.2 script remains included and untouched for rollback.
