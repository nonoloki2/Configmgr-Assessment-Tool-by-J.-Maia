SOFTWARE DEPLOYMENT MANAGER — FIXED BUILD 1.1
=============================================

FIXES
-----
- The top + New Package button works.
- The New Package sidebar item works.
- Navigation loads before IndexedDB initialization.
- IndexedDB failure no longer disables the interface.
- localStorage fallback added.
- Backup restore supports both storage engines.
- Incorrect English labels corrected.
- JavaScript cache busting added.

IIS DEPLOYMENT
--------------
Copy the extracted folder to:

C:\inetpub\SoftwareDeploymentManager

Create an IIS Application or Virtual Directory and browse to:

http://YOUR-SERVER/SoftwareDeploymentManager/

TEST
----
1. Open the application.
2. Click + New Package.
3. Click New Package in the sidebar.
4. Save a package.
5. Confirm it under All Packages.
6. Refresh and verify persistence.
