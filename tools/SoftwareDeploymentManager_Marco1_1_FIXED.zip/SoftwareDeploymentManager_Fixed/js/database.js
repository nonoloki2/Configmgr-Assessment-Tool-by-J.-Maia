
const DB_NAME = "SoftwareDeploymentManagerDB";
const DB_VERSION = 2;
const STORES = { packages: "packages", activities: "activities", settings: "settings" };

let db = null;
let storageMode = "indexeddb";
const FALLBACK_KEY = "SDM_FALLBACK_DATABASE_V1";

function getFallbackDatabase() {
  try {
    const parsed = JSON.parse(localStorage.getItem(FALLBACK_KEY) || "{}");
    return {
      packages: Array.isArray(parsed.packages) ? parsed.packages : [],
      activities: Array.isArray(parsed.activities) ? parsed.activities : [],
      settings: Array.isArray(parsed.settings) ? parsed.settings : []
    };
  } catch {
    return { packages: [], activities: [], settings: [] };
  }
}

function saveFallbackDatabase(data) {
  localStorage.setItem(FALLBACK_KEY, JSON.stringify(data));
}

function openDatabase() {
  return new Promise(resolve => {
    if (!("indexedDB" in window)) {
      storageMode = "localstorage";
      resolve(null);
      return;
    }

    let completed = false;
    const fallback = () => {
      if (completed) return;
      completed = true;
      storageMode = "localstorage";
      db = null;
      resolve(null);
    };

    try {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = event => {
        const upgradeDb = event.target.result;

        if (!upgradeDb.objectStoreNames.contains(STORES.packages)) {
          const store = upgradeDb.createObjectStore(STORES.packages, { keyPath: "id" });
          store.createIndex("status", "status", { unique: false });
          store.createIndex("phase", "phase", { unique: false });
          store.createIndex("assignedAnalyst", "assignedAnalyst", { unique: false });
          store.createIndex("priority", "priority", { unique: false });
          store.createIndex("updatedAt", "updatedAt", { unique: false });
        }

        if (!upgradeDb.objectStoreNames.contains(STORES.activities)) {
          const store = upgradeDb.createObjectStore(STORES.activities, {
            keyPath: "activityId",
            autoIncrement: true
          });
          store.createIndex("packageId", "packageId", { unique: false });
          store.createIndex("timestamp", "timestamp", { unique: false });
        }

        if (!upgradeDb.objectStoreNames.contains(STORES.settings)) {
          upgradeDb.createObjectStore(STORES.settings, { keyPath: "key" });
        }
      };

      request.onsuccess = event => {
        if (completed) return;
        completed = true;
        db = event.target.result;
        storageMode = "indexeddb";
        resolve(db);
      };

      request.onerror = fallback;
      request.onblocked = fallback;
      setTimeout(fallback, 4000);
    } catch {
      fallback();
    }
  });
}

function idbStore(storeName, mode = "readonly") {
  if (!db) throw new Error("IndexedDB unavailable");
  return db.transaction(storeName, mode).objectStore(storeName);
}

async function getAll(storeName) {
  if (storageMode === "localstorage") return [...(getFallbackDatabase()[storeName] || [])];
  return new Promise((resolve, reject) => {
    const request = idbStore(storeName).getAll();
    request.onsuccess = () => resolve(request.result || []);
    request.onerror = () => reject(request.error);
  });
}

async function getOne(storeName, key) {
  if (storageMode === "localstorage") {
    const items = getFallbackDatabase()[storeName] || [];
    const keyName = storeName === STORES.settings ? "key" : storeName === STORES.activities ? "activityId" : "id";
    return items.find(item => item[keyName] === key);
  }
  return new Promise((resolve, reject) => {
    const request = idbStore(storeName).get(key);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function putOne(storeName, value) {
  if (storageMode === "localstorage") {
    const data = getFallbackDatabase();
    const items = data[storeName] || [];
    const keyName = storeName === STORES.settings ? "key" : storeName === STORES.activities ? "activityId" : "id";
    const index = items.findIndex(item => item[keyName] === value[keyName]);
    if (index >= 0) items[index] = value;
    else items.push(value);
    data[storeName] = items;
    saveFallbackDatabase(data);
    return value;
  }
  return new Promise((resolve, reject) => {
    const request = idbStore(storeName, "readwrite").put(value);
    request.onsuccess = () => resolve(value);
    request.onerror = () => reject(request.error);
  });
}

async function addOne(storeName, value) {
  if (storageMode === "localstorage") {
    const data = getFallbackDatabase();
    const items = data[storeName] || [];
    if (storeName === STORES.activities && !value.activityId) {
      value.activityId = items.reduce((max, item) => Math.max(max, Number(item.activityId) || 0), 0) + 1;
    }
    items.push(value);
    data[storeName] = items;
    saveFallbackDatabase(data);
    return value;
  }
  return new Promise((resolve, reject) => {
    const request = idbStore(storeName, "readwrite").add(value);
    request.onsuccess = () => resolve(value);
    request.onerror = () => reject(request.error);
  });
}

async function deleteOne(storeName, key) {
  if (storageMode === "localstorage") {
    const data = getFallbackDatabase();
    const keyName = storeName === STORES.settings ? "key" : storeName === STORES.activities ? "activityId" : "id";
    data[storeName] = (data[storeName] || []).filter(item => item[keyName] !== key);
    saveFallbackDatabase(data);
    return;
  }
  return new Promise((resolve, reject) => {
    const request = idbStore(storeName, "readwrite").delete(key);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

async function clearStore(storeName) {
  if (storageMode === "localstorage") {
    const data = getFallbackDatabase();
    data[storeName] = [];
    saveFallbackDatabase(data);
    return;
  }
  return new Promise((resolve, reject) => {
    const request = idbStore(storeName, "readwrite").clear();
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

async function addActivity(packageId, action, details, user = "Local User") {
  return addOne(STORES.activities, {
    packageId, action, details, user, timestamp: new Date().toISOString()
  });
}

async function saveSetting(key, value) {
  return putOne(STORES.settings, { key, value });
}

async function loadSetting(key, fallback = null) {
  const item = await getOne(STORES.settings, key);
  return item ? item.value : fallback;
}

function getStorageMode() {
  return storageMode;
}

window.SDMDB = {
  openDatabase, getAll, getOne, putOne, addOne, deleteOne, clearStore,
  addActivity, saveSetting, loadSetting, getStorageMode, STORES
};
