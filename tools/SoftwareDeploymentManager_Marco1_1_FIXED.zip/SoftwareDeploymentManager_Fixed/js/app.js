
const { STORES } = SDMDB;

const PHASES = [
  "New Request","Triage","Waiting for Source","Ready for Packaging","Packaging",
  "Internal Testing","Owner UAT","Ready for Deployment","Pilot Deployment",
  "Production Deployment","Monitoring","Completed","Blocked","On Hold","Cancelled"
];

const PRIORITIES = ["Critical","High","Medium","Low"];
const COMPLEXITIES = ["Low","Medium","High","Very High"];
const TEST_RESULTS = ["Pending","Passed","Passed with Notes","Failed","Not Applicable"];
const INSTALLER_TYPES = ["MSI","EXE","MSIX","APPX","CAB","MSU","Script","Other"];

const state = {
  packages: [],
  activities: [],
  currentView: "dashboard",
  search: "",
  editingId: null
};

const viewContainer = document.getElementById("viewContainer");
const pageTitle = document.getElementById("pageTitle");
const pageSubtitle = document.getElementById("pageSubtitle");
const modal = document.getElementById("modal");
const modalBody = document.getElementById("modalBody");
const modalTitle = document.getElementById("modalTitle");
const toast = document.getElementById("toast");

function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, ch => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[ch]));
}

function formatDate(date) {
  if (!date) return "—";
  return new Date(date + (date.length === 10 ? "T00:00:00" : "")).toLocaleDateString("en-US");
}

function daysBetween(date) {
  if (!date) return 0;
  const then = new Date(date);
  return Math.floor((Date.now() - then.getTime()) / 86400000);
}

function badgeClass(value = "") {
  return String(value).toLowerCase().replaceAll(" ", "-");
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.remove("hidden");
  setTimeout(() => toast.classList.add("hidden"), 2800);
}

function setViewTitle(title, subtitle) {
  pageTitle.textContent = title;
  pageSubtitle.textContent = subtitle;
}

function calculateScore(pkg) {
  const weights = { Critical:100, High:60, Medium:30, Low:10 };
  let score = weights[pkg.priority] || 0;
  if (pkg.expectedDeliveryDate) {
    const diff = Math.ceil((new Date(pkg.expectedDeliveryDate) - new Date()) / 86400000);
    if (diff < 0) score += 50;
    else if (diff <= 3) score += 30;
  }
  score += Math.max(0, daysBetween(pkg.requestDate));
  if (pkg.blocked) score -= 20;
  if (pkg.complexity === "High") score += 15;
  if (pkg.complexity === "Very High") score += 25;
  return score;
}

function generateId() {
  const year = new Date().getFullYear();
  const nums = state.packages
    .filter(p => p && typeof p.id === "string" && p.id.startsWith(`PKG-${year}-`))
    .map(p => Number(p.id.split("-").pop()))
    .filter(Number.isFinite);
  const next = (nums.length ? Math.max(...nums) : 0) + 1;
  return `PKG-${year}-${String(next).padStart(4,"0")}`;
}

async function refreshData() {
  state.packages = await SDMDB.getAll(STORES.packages);
  state.activities = await SDMDB.getAll(STORES.activities);
}

function filteredPackages(extraFilter = () => true) {
  const q = state.search.trim().toLowerCase();
  return state.packages.filter(p => {
    const haystack = Object.values(p).join(" ").toLowerCase();
    return (!q || haystack.includes(q)) && extraFilter(p);
  });
}

function renderDashboard() {
  setViewTitle("Dashboard", "Operational overview");
  const pkgs = state.packages;
  const today = new Date().toISOString().slice(0,10);
  const metrics = [
    ["Total Packages", pkgs.length, "All records"],
    ["In Development", pkgs.filter(p => ["Packaging","Ready for Packaging"].includes(p.phase)).length, "Packages being prepared"],
    ["Awaiting UAT", pkgs.filter(p => p.phase === "Owner UAT").length, "Waiting for business owner"],
    ["Overdue", pkgs.filter(p => p.expectedDeliveryDate && p.expectedDeliveryDate < today && p.phase !== "Completed").length, "Past due date"],
    ["Blocked", pkgs.filter(p => p.blocked || p.phase === "Blocked").length, "Action required"],
    ["Ready for Deployment", pkgs.filter(p => p.phase === "Ready for Deployment").length, "Awaiting publication"],
    ["Completed", pkgs.filter(p => p.phase === "Completed").length, "Finished"],
    ["No Update > 7 Days", pkgs.filter(p => daysBetween(p.updatedAt) > 7 && p.phase !== "Completed").length, "Attention required"]
  ];

  const phaseCounts = PHASES.map(phase => [phase, pkgs.filter(p => p.phase === phase).length]).filter(x => x[1] > 0);
  const max = Math.max(1, ...phaseCounts.map(x => x[1]));

  const alerts = [];
  pkgs.forEach(p => {
    if (p.expectedDeliveryDate && p.expectedDeliveryDate < today && p.phase !== "Completed")
      alerts.push(`<div class="alert danger"><strong>${escapeHtml(p.id)} — ${escapeHtml(p.packageName)}</strong><br>Delivery overdue since ${formatDate(p.expectedDeliveryDate)}.</div>`);
    else if (daysBetween(p.updatedAt) > 7 && p.phase !== "Completed")
      alerts.push(`<div class="alert"><strong>${escapeHtml(p.id)} — ${escapeHtml(p.packageName)}</strong><br>No update for ${daysBetween(p.updatedAt)} days.</div>`);
  });

  viewContainer.innerHTML = `
    <div class="grid cards">
      ${metrics.map(m => `<div class="card metric"><div class="label">${m[0]}</div><div class="value">${m[1]}</div><div class="hint">${m[2]}</div></div>`).join("")}
    </div>
    <div class="grid" style="grid-template-columns:1.2fr .8fr; margin-top:18px;">
      <div class="card">
        <div class="section-title"><h3>Distribution by Phase</h3></div>
        <div class="chart-list">
          ${phaseCounts.length ? phaseCounts.map(([name,count]) => `
            <div class="chart-row"><span>${escapeHtml(name)}</span><div class="chart-bar"><span style="width:${count/max*100}%"></span></div><strong>${count}</strong></div>
          `).join("") : `<div class="empty">Create the first package to populate the dashboard.</div>`}
        </div>
      </div>
      <div class="card">
        <div class="section-title"><h3>Operational Alerts</h3></div>
        ${alerts.slice(0,8).join("") || `<div class="empty">No critical alerts.</div>`}
      </div>
    </div>`;
}

function renderPackages(filterFn = () => true, title = "All Packages", subtitle = "Complete package record management") {
  setViewTitle(title, subtitle);
  const list = filteredPackages(filterFn);
  viewContainer.innerHTML = `
    <div class="toolbar">
      <select id="filterPriority"><option value="">All Priorities</option>${PRIORITIES.map(x=>`<option>${x}</option>`).join("")}</select>
      <select id="filterPhase"><option value="">All Phases</option>${PHASES.map(x=>`<option>${x}</option>`).join("")}</select>
      <input id="filterAnalyst" placeholder="Filter by Analyst">
      <button id="applyFilters" class="secondary">Apply Filters</button>
      <button id="exportFiltered" class="secondary">Export HTML</button>
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr>
          <th>ID</th><th>Package</th><th>Version</th><th>Analyst</th><th>Priority</th>
          <th>Phase</th><th>Due Date</th><th>Score</th><th>Last Update</th><th>Actions</th>
        </tr></thead>
        <tbody id="packageRows">
          ${list.length ? list.map(packageRow).join("") : `<tr><td colspan="10" class="empty">No packages found.</td></tr>`}
        </tbody>
      </table>
    </div>`;

  document.getElementById("applyFilters").onclick = () => {
    const pr = document.getElementById("filterPriority").value;
    const ph = document.getElementById("filterPhase").value;
    const an = document.getElementById("filterAnalyst").value.toLowerCase();
    const rows = filteredPackages(p => (!pr || p.priority===pr) && (!ph || p.phase===ph) && (!an || (p.assignedAnalyst||"").toLowerCase().includes(an)));
    document.getElementById("packageRows").innerHTML = rows.length ? rows.map(packageRow).join("") : `<tr><td colspan="10" class="empty">No packages found.</td></tr>`;
    attachRowActions();
  };
  document.getElementById("exportFiltered").onclick = () => exportHtml(list, title);
  attachRowActions();
}

function packageRow(p) {
  return `<tr>
    <td><strong>${escapeHtml(p.id)}</strong></td>
    <td>${escapeHtml(p.packageName)}<br><small>${escapeHtml(p.vendor||"")}</small></td>
    <td>${escapeHtml(p.version||"—")}</td>
    <td>${escapeHtml(p.assignedAnalyst||"Unassigned")}</td>
    <td><span class="badge ${badgeClass(p.priority)}">${escapeHtml(p.priority)}</span></td>
    <td><span class="badge ${badgeClass(p.phase)}">${escapeHtml(p.phase)}</span></td>
    <td>${formatDate(p.expectedDeliveryDate)}</td>
    <td>${calculateScore(p)}</td>
    <td>${formatDate(p.updatedAt)}</td>
    <td>
      <button class="secondary view-btn" data-id="${p.id}">View</button>
      <button class="secondary edit-btn" data-id="${p.id}">Edit</button>
    </td>
  </tr>`;
}

function attachRowActions() {
  document.querySelectorAll(".view-btn").forEach(btn => btn.onclick = () => showPackage(btn.dataset.id));
  document.querySelectorAll(".edit-btn").forEach(btn => btn.onclick = () => renderPackageForm(btn.dataset.id));
}

function packageFormHtml(pkg = {}) {
  const p = { id: generateId(), priority:"Medium", complexity:"Medium", phase:"New Request", internalTestResult:"Pending", ownerTestResult:"Pending", blocked:false, ...pkg };
  return `
  <form id="packageForm">
    <div class="form-card">
      <div class="section-title"><h3>Request Details</h3></div>
      <div class="form-grid">
        ${field("id","Package ID",p.id,"text",true)}
        ${field("packageName","Package Name",p.packageName,"text",true)}
        ${field("vendor","Vendor",p.vendor)}
        ${field("version","Version",p.version)}
        ${field("requester","Requester",p.requester)}
        ${field("businessOwner","Business Owner",p.businessOwner)}
        ${field("requestDate","Request Date",p.requestDate||new Date().toISOString().slice(0,10),"date")}
        ${field("expectedDeliveryDate","Expected Delivery Date",p.expectedDeliveryDate,"date")}
        ${selectField("priority","Priority",PRIORITIES,p.priority)}
        <div class="form-group full">${textArea("businessJustification","Business Justification",p.businessJustification)}</div>
      </div>
    </div>

    <div class="form-card">
      <div class="section-title"><h3>Ownership and Queue</h3></div>
      <div class="form-grid">
        ${field("assignedAnalyst","Assigned Analyst",p.assignedAnalyst)}
        ${field("backupAnalyst","Analyst backup",p.backupAnalyst)}
        ${field("queuePosition","Manual Queue Position",p.queuePosition,"number")}
        ${selectField("complexity","Complexity",COMPLEXITIES,p.complexity)}
        ${field("estimatedEffort","Estimated Effort (Hours)",p.estimatedEffort,"number")}
        ${selectField("phase","Phase atual",PHASES,p.phase)}
        ${field("status","Detailed Status",p.status||"Open")}
        ${field("blockingReason","Blocking Reason",p.blockingReason)}
        <div class="form-group"><label><input type="checkbox" name="blocked" ${p.blocked?"checked":""}> Package bloqueado</label></div>
      </div>
    </div>

    <div class="form-card">
      <div class="section-title"><h3>Technical Information</h3></div>
      <div class="form-grid">
        ${field("sourcePath","Source Path",p.sourcePath)}
        ${selectField("installerType","Installer Type",INSTALLER_TYPES,p.installerType)}
        ${field("architecture","Architecture",p.architecture||"x64")}
        ${field("installContext","Install Context",p.installContext||"System")}
        <div class="form-group full">${textArea("installCommand","Install Command",p.installCommand)}</div>
        <div class="form-group full">${textArea("uninstallCommand","Uninstall Command",p.uninstallCommand)}</div>
        <div class="form-group full">${textArea("detectionMethod","Detection Method",p.detectionMethod)}</div>
        ${field("prerequisites","Prerequisites",p.prerequisites)}
        ${field("dependencies","Dependencies",p.dependencies)}
        ${field("rebootBehavior","Reboot Behavior",p.rebootBehavior||"Not Required")}
        <div class="form-group full">${textArea("installationSteps","Installation Steps",p.installationSteps)}</div>
      </div>
    </div>

    <div class="form-card">
      <div class="section-title"><h3>Testing, UAT and Deployment</h3></div>
      <div class="form-grid">
        ${field("internalTester","Internal Tester",p.internalTester)}
        ${field("internalTestDate","Internal Test Date",p.internalTestDate,"date")}
        ${selectField("internalTestResult","Internal Test Result",TEST_RESULTS,p.internalTestResult)}
        ${field("ownerTester","Business Owner Tester",p.ownerTester)}
        ${field("ownerTestDate","UAT Date",p.ownerTestDate,"date")}
        ${selectField("ownerTestResult","UAT Result",TEST_RESULTS,p.ownerTestResult)}
        <div class="form-group full">${textArea("issuesFound","Issues Found",p.issuesFound)}</div>
        <div class="form-group full">${textArea("resolution","Resolution",p.resolution)}</div>
        ${field("deploymentPlatform","Deployment Platform",p.deploymentPlatform||"SCCM")}
        ${field("applicationId","Application ID",p.applicationId)}
        ${field("targetGroup","Collection / Grupo",p.targetGroup)}
        ${field("pilotDate","Pilot Date",p.pilotDate,"date")}
        ${field("productionDate","Production Date",p.productionDate,"date")}
        ${field("compliance","Compliance (%)",p.compliance,"number")}
        <div class="form-group full">${textArea("notes","Notes",p.notes)}</div>
      </div>
      <div class="form-actions">
        <button type="button" class="secondary" id="cancelEdit">Cancel</button>
        <button type="submit" class="primary">Save Package</button>
      </div>
    </div>
  </form>`;
}

function field(name,label,value="",type="text",required=false) {
  return `<div class="form-group"><label>${label}</label><input name="${name}" type="${type}" value="${escapeHtml(value??"")}" ${required?"required":""}></div>`;
}
function textArea(name,label,value="") {
  return `<label>${label}</label><textarea name="${name}">${escapeHtml(value??"")}</textarea>`;
}
function selectField(name,label,options,value) {
  return `<div class="form-group"><label>${label}</label><select name="${name}">${options.map(o=>`<option ${o===value?"selected":""}>${o}</option>`).join("")}</select></div>`;
}

async function renderPackageForm(id = null) {
  state.currentView = "new-package";
  document.querySelectorAll(".nav-item").forEach(x=>x.classList.toggle("active",x.dataset.view==="new-package"));
  const pkg = id ? await SDMDB.getOne(STORES.packages,id) : null;
  state.editingId = id;
  setViewTitle(id ? `Edit ${id}` : "Novo pacote", "Complete software package registration");
  viewContainer.innerHTML = packageFormHtml(pkg || {});
  document.getElementById("cancelEdit").onclick = () => navigate("packages");
  document.getElementById("packageForm").onsubmit = savePackageForm;
}

async function savePackageForm(event) {
  event.preventDefault();
  const fd = new FormData(event.target);
  const existing = state.editingId ? await SDMDB.getOne(STORES.packages,state.editingId) : null;
  const obj = Object.fromEntries(fd.entries());
  obj.blocked = event.target.elements.blocked.checked;
  obj.queuePosition = Number(obj.queuePosition||0);
  obj.estimatedEffort = Number(obj.estimatedEffort||0);
  obj.compliance = Number(obj.compliance||0);
  obj.createdAt = existing?.createdAt || new Date().toISOString();
  obj.updatedAt = new Date().toISOString();
  obj.deleted = false;

  await SDMDB.putOne(STORES.packages,obj);
  await SDMDB.addActivity(obj.id, existing ? "Updated" : "Created", existing ? "Registro atualizado" : "Package criado");
  await refreshData();
  showToast("Package salvo com sucesso.");
  navigate("packages");
}

async function showPackage(id) {
  const p = await SDMDB.getOne(STORES.packages,id);
  const acts = state.activities.filter(a=>a.packageId===id).sort((a,b)=>b.timestamp.localeCompare(a.timestamp));
  modalTitle.textContent = `${p.id} — ${p.packageName}`;
  modalBody.innerHTML = `
    <div class="grid cards">
      <div class="card metric"><div class="label">Priority</div><div class="value" style="font-size:22px">${escapeHtml(p.priority)}</div></div>
      <div class="card metric"><div class="label">Phase</div><div class="value" style="font-size:22px">${escapeHtml(p.phase)}</div></div>
      <div class="card metric"><div class="label">Analyst</div><div class="value" style="font-size:22px">${escapeHtml(p.assignedAnalyst||"—")}</div></div>
      <div class="card metric"><div class="label">Score</div><div class="value" style="font-size:22px">${calculateScore(p)}</div></div>
    </div>
    <div class="form-card" style="margin-top:18px">
      <div class="form-grid">
        ${detail("Version",p.version)}${detail("Vendor",p.vendor)}${detail("Due Date",formatDate(p.expectedDeliveryDate))}
        ${detail("Fonte",p.sourcePath)}${detail("Instalador",p.installerType)}${detail("Architecture",p.architecture)}
        ${detail("Installation",p.installCommand)}${detail("Uninstallation",p.uninstallCommand)}${detail("Detection",p.detectionMethod)}
        ${detail("Teste interno",p.internalTestResult)}${detail("UAT",p.ownerTestResult)}${detail("Deployment Platform",p.deploymentPlatform)}
      </div>
    </div>
    <div class="form-card">
      <h3>Activity History</h3>
      ${acts.length?acts.map(a=>`<div class="alert"><strong>${new Date(a.timestamp).toLocaleString("en-US")}</strong> — ${escapeHtml(a.action)}<br><small>${escapeHtml(a.details)} | ${escapeHtml(a.user)}</small></div>`).join(""):`<div class="empty">No activity history.</div>`}
      <div class="form-actions">
        <button class="danger" id="deletePackage">Delete</button>
        <button class="secondary" id="editFromModal">Edit</button>
      </div>
    </div>`;
  modal.classList.remove("hidden");
  document.getElementById("editFromModal").onclick = ()=>{ modal.classList.add("hidden"); renderPackageForm(id); };
  document.getElementById("deletePackage").onclick = async ()=>{
    if(confirm(`Delete ${id}? This action removes the local record.`)){
      await SDMDB.deleteOne(STORES.packages,id);
      await SDMDB.addActivity(id,"Deleted","Record deleted");
      modal.classList.add("hidden");
      await refreshData();
      navigate("packages");
      showToast("Package deleted.");
    }
  };
}

function detail(label,value) {
  return `<div class="form-group"><label>${label}</label><div>${escapeHtml(value||"—")}</div></div>`;
}

function renderQueue() {
  setViewTitle("Work Queue","Suggested order based on priority, due date, age and complexity");
  const list = filteredPackages(p=>!["Completed","Cancelled"].includes(p.phase)).sort((a,b)=>calculateScore(b)-calculateScore(a));
  viewContainer.innerHTML = `
    <div class="card">
      <div class="section-title"><h3>Suggested Queue</h3><span class="badge">Automatic Score</span></div>
      <div class="table-wrap"><table><thead><tr><th>#</th><th>ID</th><th>Package</th><th>Analyst</th><th>Priority</th><th>Complexity</th><th>Due Date</th><th>Score</th><th>Manual Position</th></tr></thead>
      <tbody>${list.map((p,i)=>`<tr><td>${i+1}</td><td>${p.id}</td><td>${escapeHtml(p.packageName)}</td><td>${escapeHtml(p.assignedAnalyst||"—")}</td><td>${p.priority}</td><td>${p.complexity}</td><td>${formatDate(p.expectedDeliveryDate)}</td><td><strong>${calculateScore(p)}</strong></td><td>${p.queuePosition||"—"}</td></tr>`).join("")}</tbody></table></div>
    </div>`;
}

function renderKanban() {
  setViewTitle("Kanban","Visual package workflow");
  const cols = ["New Request","Waiting for Source","Packaging","Internal Testing","Owner UAT","Ready for Deployment","Production Deployment","Completed"];
  viewContainer.innerHTML = `<div class="kanban">${cols.map(phase=>`
    <div class="kanban-column" data-phase="${phase}">
      <h4>${phase}<span>${state.packages.filter(p=>p.phase===phase).length}</span></h4>
      ${state.packages.filter(p=>p.phase===phase).map(p=>`
        <div class="kanban-card" draggable="true" data-id="${p.id}">
          <strong>${escapeHtml(p.packageName)}</strong>
          <small>${p.id} • ${escapeHtml(p.version||"No version")}</small>
          <small>${escapeHtml(p.assignedAnalyst||"Unassigned")} • ${p.priority}</small>
          <small>Due Date: ${formatDate(p.expectedDeliveryDate)}</small>
        </div>`).join("")}
    </div>`).join("")}</div>`;
  document.querySelectorAll(".kanban-card").forEach(card=>{
    card.addEventListener("dragstart",e=>e.dataTransfer.setData("text/plain",card.dataset.id));
  });
  document.querySelectorAll(".kanban-column").forEach(col=>{
    col.addEventListener("dragover",e=>e.preventDefault());
    col.addEventListener("drop",async e=>{
      e.preventDefault();
      const id=e.dataTransfer.getData("text/plain");
      const p=await SDMDB.getOne(STORES.packages,id);
      const old=p.phase; p.phase=col.dataset.phase; p.updatedAt=new Date().toISOString();
      await SDMDB.putOne(STORES.packages,p);
      await SDMDB.addActivity(id,"Phase changed",`${old} → ${p.phase}`);
      await refreshData(); renderKanban(); showToast("Phase atualizada.");
    });
  });
}

function renderTesting() {
  renderPackages(p => ["Internal Testing","Owner UAT"].includes(p.phase) || ["Pending","Failed"].includes(p.internalTestResult) || ["Pending","Failed"].includes(p.ownerTestResult), "Testing & UAT", "Packages awaiting validation");
}

function renderBlocked() {
  renderPackages(p => p.blocked || p.phase==="Blocked", "Packages bloqueados", "Items requiring action");
}

function renderReports() {
  setViewTitle("Reports","Visual HTML exports");
  const options = [
    ["All Packages",()=>state.packages],
    ["Packages atrasados",()=>state.packages.filter(p=>p.expectedDeliveryDate && p.expectedDeliveryDate < new Date().toISOString().slice(0,10) && p.phase!=="Completed")],
    ["Packages bloqueados",()=>state.packages.filter(p=>p.blocked||p.phase==="Blocked")],
    ["Awaiting UAT",()=>state.packages.filter(p=>p.phase==="Owner UAT")],
    ["Completed",()=>state.packages.filter(p=>p.phase==="Completed")],
    ["Prioritized Queue",()=>[...state.packages].sort((a,b)=>calculateScore(b)-calculateScore(a))]
  ];
  viewContainer.innerHTML = `<div class="report-options">${options.map((o,i)=>`
    <div class="report-option"><h4>${o[0]}</h4><p>Generates a clean, printable HTML report that can be easily saved as PDF.</p><button class="primary report-btn" data-index="${i}">Generate Report</button></div>`).join("")}</div>`;
  document.querySelectorAll(".report-btn").forEach(btn=>btn.onclick=()=>exportHtml(options[btn.dataset.index][1](),options[btn.dataset.index][0]));
}

function exportHtml(list,title) {
  const rows = list.map(p=>`<tr><td>${p.id}</td><td>${escapeHtml(p.packageName)}</td><td>${escapeHtml(p.version||"")}</td><td>${escapeHtml(p.assignedAnalyst||"")}</td><td>${p.priority}</td><td>${p.phase}</td><td>${formatDate(p.expectedDeliveryDate)}</td><td>${calculateScore(p)}</td></tr>`).join("");
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title><style>body{font-family:Segoe UI,Arial;padding:30px;color:#172033}h1{margin-bottom:4px}p{color:#667085}table{border-collapse:collapse;width:100%;margin-top:25px}th,td{border:1px solid #d7dde7;padding:9px;text-align:left;font-size:12px}th{background:#eef3f8}</style></head><body><h1>${title}</h1><p>Generated on ${new Date().toLocaleString("en-US")} • ${list.length} records</p><table><thead><tr><th>ID</th><th>Package</th><th>Version</th><th>Analyst</th><th>Priority</th><th>Phase</th><th>Due Date</th><th>Score</th></tr></thead><tbody>${rows}</tbody></table></body></html>`;
  downloadBlob(new Blob([html],{type:"text/html"}),`${title.replace(/\s+/g,"_")}_${Date.now()}.html`);
}

function renderBackup() {
  setViewTitle("Backup & Restore","Protect the browser local database");
  viewContainer.innerHTML = `
    <div class="grid" style="grid-template-columns:1fr 1fr">
      <div class="card"><h3>Full Backup</h3><p>Exports packages, activity history and settings to JSON.</p><button id="backupBtn" class="primary">Generate JSON Backup</button></div>
      <div class="card"><h3>Restore Backup</h3><p>Replaces the current content with the selected file.</p><input id="restoreFile" type="file" accept=".json"><button id="restoreBtn" class="secondary" style="margin-top:12px">Restore</button></div>
    </div>
    <div class="card" style="margin-top:18px"><h3>Data Safety</h3><div id="lastBackupInfo">Last backup: checking...</div><p>Data is associated with this browser, profile and computer. Keep JSON backup copies outside this machine.</p></div>`;
  loadLastBackup();
  document.getElementById("backupBtn").onclick = backupDatabase;
  document.getElementById("restoreBtn").onclick = restoreDatabase;
}

async function loadLastBackup() {
  const last = await SDMDB.loadSetting("lastBackup");
  document.getElementById("lastBackupInfo").textContent = `Last backup: ${last ? new Date(last).toLocaleString("en-US") : "never performed"}`;
}

async function backupDatabase() {
  const data = {
    schemaVersion: 1,
    exportedAt: new Date().toISOString(),
    packages: await SDMDB.getAll(STORES.packages),
    activities: await SDMDB.getAll(STORES.activities),
    settings: await SDMDB.getAll(STORES.settings)
  };
  downloadBlob(new Blob([JSON.stringify(data,null,2)],{type:"application/json"}),`SoftwareDeployment_Backup_${new Date().toISOString().replace(/[:.]/g,"-")}.json`);
  await SDMDB.saveSetting("lastBackup",new Date().toISOString());
  loadLastBackup();
  showToast("Backup generated successfully.");
}

async function restoreDatabase() {
  const file=document.getElementById("restoreFile").files[0];
  if(!file) return alert("Select a JSON file.");
  if(!confirm("Restoration will replace the current database. Continue?")) return;
  try{
    const data=JSON.parse(await file.text());
    await SDMDB.clearStore(STORES.packages);
    await SDMDB.clearStore(STORES.activities);
    for(const p of data.packages||[]) await SDMDB.putOne(STORES.packages,p);
    for(const a of data.activities||[]) {
      const copy = {...a};
      delete copy.activityId;
      await SDMDB.addOne(STORES.activities, copy);
    }
    await refreshData();
    showToast("Backup restored.");
    navigate("dashboard");
  }catch(e){ alert("Restore failed: "+e.message); }
}

function downloadBlob(blob,filename) {
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download=filename; a.click(); setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}

function renderSettings() {
  setViewTitle("Settings","Local preferences");
  viewContainer.innerHTML = `
    <div class="card" style="max-width:700px">
      <h3>Local Identity</h3>
      <div class="form-group"><label>User name for activity history</label><input id="localUser" placeholder="Your name"></div>
      <div class="form-actions"><button id="saveSettings" class="primary">Save Settings</button></div>
    </div>
    <div class="card" style="max-width:700px;margin-top:18px">
      <h3>Demo Data</h3>
      <p>Adds sample packages to test the dashboard, reports and Kanban.</p>
      <button id="seedDemo" class="secondary">Load Demo Data</button>
    </div>`;
  SDMDB.loadSetting("localUser","Local User").then(v=>document.getElementById("localUser").value=v);
  document.getElementById("saveSettings").onclick=async()=>{await SDMDB.saveSetting("localUser",document.getElementById("localUser").value||"Local User");showToast("Settings salvas.");};
  document.getElementById("seedDemo").onclick=seedDemo;
}

async function seedDemo(){
  if(state.packages.length && !confirm("Data already exists. Add demo records anyway?")) return;
  const samples=[
    {packageName:"7-Zip",vendor:"Igor Pavlov",version:"24.09",assignedAnalyst:"José",priority:"High",complexity:"Low",phase:"Packaging",expectedDeliveryDate:new Date(Date.now()+3*86400000).toISOString().slice(0,10),requestDate:new Date(Date.now()-4*86400000).toISOString().slice(0,10),installerType:"EXE",internalTestResult:"Pending",ownerTestResult:"Pending"},
    {packageName:"Microsoft Edge Enterprise",vendor:"Microsoft",version:"Current",assignedAnalyst:"Ana",priority:"Critical",complexity:"Medium",phase:"Owner UAT",expectedDeliveryDate:new Date(Date.now()-2*86400000).toISOString().slice(0,10),requestDate:new Date(Date.now()-12*86400000).toISOString().slice(0,10),installerType:"MSI",internalTestResult:"Passed",ownerTestResult:"Pending"},
    {packageName:"M-Files Online",vendor:"M-Files",version:"26.5",assignedAnalyst:"Carlos",priority:"Medium",complexity:"Very High",phase:"Blocked",blocked:true,blockingReason:"Waiting for license and documentation",expectedDeliveryDate:new Date(Date.now()+7*86400000).toISOString().slice(0,10),requestDate:new Date(Date.now()-9*86400000).toISOString().slice(0,10),installerType:"MSI",internalTestResult:"Failed",ownerTestResult:"Pending"},
    {packageName:"Think-cell",vendor:"think-cell",version:"12",assignedAnalyst:"Marina",priority:"Low",complexity:"Medium",phase:"Completed",expectedDeliveryDate:new Date(Date.now()-10*86400000).toISOString().slice(0,10),requestDate:new Date(Date.now()-30*86400000).toISOString().slice(0,10),installerType:"MSI",internalTestResult:"Passed",ownerTestResult:"Passed",compliance:97}
  ];
  for(const s of samples){
    const p={id:generateId(),status:"Open",queuePosition:0,estimatedEffort:0,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),...s};
    state.packages.push(p);
    await SDMDB.putOne(STORES.packages,p); await SDMDB.addActivity(p.id,"Created","Demo record created");
  }
  await refreshData(); showToast("Demo Data adicionados."); navigate("dashboard");
}

function navigate(view) {
  state.currentView = view;
  document.querySelectorAll(".nav-item").forEach(x=>x.classList.toggle("active",x.dataset.view===view));
  if(view==="dashboard") renderDashboard();
  if(view==="packages") renderPackages();
  if(view==="new-package") renderPackageForm();
  if(view==="queue") renderQueue();
  if(view==="kanban") renderKanban();
  if(view==="testing") renderTesting();
  if(view==="blocked") renderBlocked();
  if(view==="reports") renderReports();
  if(view==="backup") renderBackup();
  if(view==="settings") renderSettings();
}

function bindGlobalEvents() {
  document.querySelectorAll(".nav-item").forEach(button => {
    button.addEventListener("click", () => navigate(button.dataset.view));
  });

  document.getElementById("quickAdd").addEventListener("click", () => navigate("new-package"));

  document.getElementById("themeToggle").addEventListener("click", () => {
    document.body.classList.toggle("dark");
    localStorage.setItem("sdm-theme", document.body.classList.contains("dark") ? "dark" : "light");
  });

  document.getElementById("globalSearch").addEventListener("input", event => {
    state.search = event.target.value;
    if (state.currentView === "packages") renderPackages();
  });

  document.getElementById("modalClose").addEventListener("click", () => modal.classList.add("hidden"));
  modal.addEventListener("click", event => {
    if (event.target === modal) modal.classList.add("hidden");
  });
}

async function init() {
  if (localStorage.getItem("sdm-theme") === "dark") {
    document.body.classList.add("dark");
  }

  // Critical fix: register buttons before opening the database.
  bindGlobalEvents();
  renderDashboard();

  const status = document.getElementById("dbStatus");

  try {
    await SDMDB.openDatabase();
    await refreshData();

    status.textContent = SDMDB.getStorageMode() === "indexeddb"
      ? "Local database ready"
      : "Fallback local storage active";

    renderDashboard();
  } catch (error) {
    console.error(error);
    status.textContent = "Storage initialization failed";
    showToast("Storage failed, but navigation remains available.");
  }
}

init();
