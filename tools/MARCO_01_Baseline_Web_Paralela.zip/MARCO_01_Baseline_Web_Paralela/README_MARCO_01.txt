MARCO 01 - BASELINE WEB PARALELA
================================

Objetivo
--------
Executar o fluxo principal em uma interface web local sem alterar a versao WPF estavel.

Arquivos
--------
1. Start-SCCM-PatchDashboard-Web.ps1
   Nova versao web paralela para teste.

2. SCCM_Monthly_Patch_Dashboard_Prototype_v2.2_STABLE.ps1
   Copia congelada da versao que ja funciona. Nao foi modificada.

Como testar
-----------
1. Extraia a pasta para um diretorio local no Windows.
2. Abra PowerShell 5.1 com a mesma conta usada no SCCM.
3. Execute:
   powershell.exe -ExecutionPolicy Bypass -File .\Start-SCCM-PatchDashboard-Web.ps1
4. O navegador abrira automaticamente.
5. Primeiro teste Demo mode.
6. Depois informe SMS Provider e Site Code e clique Connect and load.
7. Selecione um deployment e clique Generate dashboard.
8. Nao feche a janela do PowerShell enquanto estiver usando o dashboard ou o botao Check Pending Reboot.

Rollback
--------
A versao estavel continua no mesmo pacote e pode ser executada normalmente.
