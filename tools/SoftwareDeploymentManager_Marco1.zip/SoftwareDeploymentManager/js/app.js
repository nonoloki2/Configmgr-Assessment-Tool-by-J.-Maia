
const { STORES } = SDMDB;

const PHASES = [
  "New Request","Triage","Waiting for Source","Ready for Packaging","Packaging",
  "Internal Testing","Owner UAT","Ready for Deployment","Pilot Deployment",
  "Production Deployment","Monitoring","Completed","Blocked","On Hold","Cancelled"
];

const PRIORITIES = ["Critical","High","Medium","Low"];
const COMPLEXITIES = ["Low","Medium","High","Very High"];
const TEST_RESULTS = ["Pending","Passed","Passed with Notes","Failed","Not Applicable"];
const INSTALLER_TYPES = ["MSI","EXE","MSIX","APPX","CAB","MSU","Script","Other"];

const state = {
  packages: [],
  activities: [],
  currentView: "dashboard",
  search: "",
  editingId: null
};

const viewContainer = document.getElementById("viewContainer");
const pageTitle = document.getElementById("pageTitle");
const pageSubtitle = document.getElementById("pageSubtitle");
const modal = document.getElementById("modal");
const modalBody = document.getElementById("modalBody");
const modalTitle = document.getElementById("modalTitle");
const toast = document.getElementById("toast");

function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, ch => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[ch]));
}

function formatDate(date) {
  if (!date) return "—";
  return new Date(date + (date.length === 10 ? "T00:00:00" : "")).toLocaleDateString("pt-BR");
}

function daysBetween(date) {
  if (!date) return 0;
  const then = new Date(date);
  return Math.floor((Date.now() - then.getTime()) / 86400000);
}

function badgeClass(value = "") {
  return String(value).toLowerCase().replaceAll(" ", "-");
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.remove("hidden");
  setTimeout(() => toast.classList.add("hidden"), 2800);
}

function setViewTitle(title, subtitle) {
  pageTitle.textContent = title;
  pageSubtitle.textContent = subtitle;
}

function calculateScore(pkg) {
  const weights = { Critical:100, High:60, Medium:30, Low:10 };
  let score = weights[pkg.priority] || 0;
  if (pkg.expectedDeliveryDate) {
    const diff = Math.ceil((new Date(pkg.expectedDeliveryDate) - new Date()) / 86400000);
    if (diff < 0) score += 50;
    else if (diff <= 3) score += 30;
  }
  score += Math.max(0, daysBetween(pkg.requestDate));
  if (pkg.blocked) score -= 20;
  if (pkg.complexity === "High") score += 15;
  if (pkg.complexity === "Very High") score += 25;
  return score;
}

function generateId() {
  const year = new Date().getFullYear();
  const nums = state.packages
    .filter(p => p.id.startsWith(`PKG-${year}-`))
    .map(p => Number(p.id.split("-").pop()))
    .filter(Number.isFinite);
  const next = (nums.length ? Math.max(...nums) : 0) + 1;
  return `PKG-${year}-${String(next).padStart(4,"0")}`;
}

async function refreshData() {
  state.packages = await SDMDB.getAll(STORES.packages);
  state.activities = await SDMDB.getAll(STORES.activities);
}

function filteredPackages(extraFilter = () => true) {
  const q = state.search.trim().toLowerCase();
  return state.packages.filter(p => {
    const haystack = Object.values(p).join(" ").toLowerCase();
    return (!q || haystack.includes(q)) && extraFilter(p);
  });
}

function renderDashboard() {
  setViewTitle("Dashboard", "Visão geral da operação");
  const pkgs = state.packages;
  const today = new Date().toISOString().slice(0,10);
  const metrics = [
    ["Total de pacotes", pkgs.length, "Todos os registros"],
    ["Em desenvolvimento", pkgs.filter(p => ["Packaging","Ready for Packaging"].includes(p.phase)).length, "Pacotes em preparação"],
    ["Aguardando UAT", pkgs.filter(p => p.phase === "Owner UAT").length, "Dependem do owner"],
    ["Atrasados", pkgs.filter(p => p.expectedDeliveryDate && p.expectedDeliveryDate < today && p.phase !== "Completed").length, "Prazo expirado"],
    ["Bloqueados", pkgs.filter(p => p.blocked || p.phase === "Blocked").length, "Demandam ação"],
    ["Prontos para deployment", pkgs.filter(p => p.phase === "Ready for Deployment").length, "Aguardando publicação"],
    ["Concluídos", pkgs.filter(p => p.phase === "Completed").length, "Finalizados"],
    ["Sem atualização > 7 dias", pkgs.filter(p => daysBetween(p.updatedAt) > 7 && p.phase !== "Completed").length, "Atenção necessária"]
  ];

  const phaseCounts = PHASES.map(phase => [phase, pkgs.filter(p => p.phase === phase).length]).filter(x => x[1] > 0);
  const max = Math.max(1, ...phaseCounts.map(x => x[1]));

  const alerts = [];
  pkgs.forEach(p => {
    if (p.expectedDeliveryDate && p.expectedDeliveryDate < today && p.phase !== "Completed")
      alerts.push(`<div class="alert danger"><strong>${escapeHtml(p.id)} — ${escapeHtml(p.packageName)}</strong><br>Entrega vencida em ${formatDate(p.expectedDeliveryDate)}.</div>`);
    else if (daysBetween(p.updatedAt) > 7 && p.phase !== "Completed")
      alerts.push(`<div class="alert"><strong>${escapeHtml(p.id)} — ${escapeHtml(p.packageName)}</strong><br>Sem atualização há ${daysBetween(p.updatedAt)} dias.</div>`);
  });

  viewContainer.innerHTML = `
    <div class="grid cards">
      ${metrics.map(m => `<div class="card metric"><div class="label">${m[0]}</div><div class="value">${m[1]}</div><div class="hint">${m[2]}</div></div>`).join("")}
    </div>
    <div class="grid" style="grid-template-columns:1.2fr .8fr; margin-top:18px;">
      <div class="card">
        <div class="section-title"><h3>Distribuição por fase</h3></div>
        <div class="chart-list">
          ${phaseCounts.length ? phaseCounts.map(([name,count]) => `
            <div class="chart-row"><span>${escapeHtml(name)}</span><div class="chart-bar"><span style="width:${count/max*100}%"></span></div><strong>${count}</strong></div>
          `).join("") : `<div class="empty">Cadastre o primeiro pacote para alimentar o dashboard.</div>`}
        </div>
      </div>
      <div class="card">
        <div class="section-title"><h3>Alertas operacionais</h3></div>
        ${alerts.slice(0,8).join("") || `<div class="empty">Nenhum alerta crítico.</div>`}
      </div>
    </div>`;
}

function renderPackages(filterFn = () => true, title = "Todos os pacotes", subtitle = "Gestão completa dos registros") {
  setViewTitle(title, subtitle);
  const list = filteredPackages(filterFn);
  viewContainer.innerHTML = `
    <div class="toolbar">
      <select id="filterPriority"><option value="">Todas as prioridades</option>${PRIORITIES.map(x=>`<option>${x}</option>`).join("")}</select>
      <select id="filterPhase"><option value="">Todas as fases</option>${PHASES.map(x=>`<option>${x}</option>`).join("")}</select>
      <input id="filterAnalyst" placeholder="Filtrar por analista">
      <button id="applyFilters" class="secondary">Aplicar filtros</button>
      <button id="exportFiltered" class="secondary">Exportar HTML</button>
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr>
          <th>ID</th><th>Pacote</th><th>Versão</th><th>Analista</th><th>Prioridade</th>
          <th>Fase</th><th>Prazo</th><th>Score</th><th>Atualização</th><th>Ações</th>
        </tr></thead>
        <tbody id="packageRows">
          ${list.length ? list.map(packageRow).join("") : `<tr><td colspan="10" class="empty">Nenhum pacote encontrado.</td></tr>`}
        </tbody>
      </table>
    </div>`;

  document.getElementById("applyFilters").onclick = () => {
    const pr = document.getElementById("filterPriority").value;
    const ph = document.getElementById("filterPhase").value;
    const an = document.getElementById("filterAnalyst").value.toLowerCase();
    const rows = filteredPackages(p => (!pr || p.priority===pr) && (!ph || p.phase===ph) && (!an || (p.assignedAnalyst||"").toLowerCase().includes(an)));
    document.getElementById("packageRows").innerHTML = rows.length ? rows.map(packageRow).join("") : `<tr><td colspan="10" class="empty">Nenhum pacote encontrado.</td></tr>`;
    attachRowActions();
  };
  document.getElementById("exportFiltered").onclick = () => exportHtml(list, title);
  attachRowActions();
}

function packageRow(p) {
  return `<tr>
    <td><strong>${escapeHtml(p.id)}</strong></td>
    <td>${escapeHtml(p.packageName)}<br><small>${escapeHtml(p.vendor||"")}</small></td>
    <td>${escapeHtml(p.version||"—")}</td>
    <td>${escapeHtml(p.assignedAnalyst||"Não atribuído")}</td>
    <td><span class="badge ${badgeClass(p.priority)}">${escapeHtml(p.priority)}</span></td>
    <td><span class="badge ${badgeClass(p.phase)}">${escapeHtml(p.phase)}</span></td>
    <td>${formatDate(p.expectedDeliveryDate)}</td>
    <td>${calculateScore(p)}</td>
    <td>${formatDate(p.updatedAt)}</td>
    <td>
      <button class="secondary view-btn" data-id="${p.id}">Ver</button>
      <button class="secondary edit-btn" data-id="${p.id}">Editar</button>
    </td>
  </tr>`;
}

function attachRowActions() {
  document.querySelectorAll(".view-btn").forEach(btn => btn.onclick = () => showPackage(btn.dataset.id));
  document.querySelectorAll(".edit-btn").forEach(btn => btn.onclick = () => renderPackageForm(btn.dataset.id));
}

function packageFormHtml(pkg = {}) {
  const p = { id: generateId(), priority:"Medium", complexity:"Medium", phase:"New Request", internalTestResult:"Pending", ownerTestResult:"Pending", blocked:false, ...pkg };
  return `
  <form id="packageForm">
    <div class="form-card">
      <div class="section-title"><h3>Identificação e solicitação</h3></div>
      <div class="form-grid">
        ${field("id","Package ID",p.id,"text",true)}
        ${field("packageName","Nome do pacote",p.packageName,"text",true)}
        ${field("vendor","Fabricante",p.vendor)}
        ${field("version","Versão",p.version)}
        ${field("requester","Solicitante",p.requester)}
        ${field("businessOwner","Business Owner",p.businessOwner)}
        ${field("requestDate","Data da solicitação",p.requestDate||new Date().toISOString().slice(0,10),"date")}
        ${field("expectedDeliveryDate","Data esperada",p.expectedDeliveryDate,"date")}
        ${selectField("priority","Prioridade",PRIORITIES,p.priority)}
        <div class="form-group full">${textArea("businessJustification","Justificativa",p.businessJustification)}</div>
      </div>
    </div>

    <div class="form-card">
      <div class="section-title"><h3>Responsabilidade e fila</h3></div>
      <div class="form-grid">
        ${field("assignedAnalyst","Analista responsável",p.assignedAnalyst)}
        ${field("backupAnalyst","Analista backup",p.backupAnalyst)}
        ${field("queuePosition","Posição manual na fila",p.queuePosition,"number")}
        ${selectField("complexity","Complexidade",COMPLEXITIES,p.complexity)}
        ${field("estimatedEffort","Esforço estimado (horas)",p.estimatedEffort,"number")}
        ${selectField("phase","Fase atual",PHASES,p.phase)}
        ${field("status","Status detalhado",p.status||"Open")}
        ${field("blockingReason","Motivo do bloqueio",p.blockingReason)}
        <div class="form-group"><label><input type="checkbox" name="blocked" ${p.blocked?"checked":""}> Pacote bloqueado</label></div>
      </div>
    </div>

    <div class="form-card">
      <div class="section-title"><h3>Informações técnicas</h3></div>
      <div class="form-grid">
        ${field("sourcePath","Caminho da fonte",p.sourcePath)}
        ${selectField("installerType","Tipo de instalador",INSTALLER_TYPES,p.installerType)}
        ${field("architecture","Arquitetura",p.architecture||"x64")}
        ${field("installContext","Contexto",p.installContext||"System")}
        <div class="form-group full">${textArea("installCommand","Comando de instalação",p.installCommand)}</div>
        <div class="form-group full">${textArea("uninstallCommand","Comando de desinstalação",p.uninstallCommand)}</div>
        <div class="form-group full">${textArea("detectionMethod","Método de detecção",p.detectionMethod)}</div>
        ${field("prerequisites","Pré-requisitos",p.prerequisites)}
        ${field("dependencies","Dependências",p.dependencies)}
        ${field("rebootBehavior","Comportamento de reboot",p.rebootBehavior||"Not Required")}
        <div class="form-group full">${textArea("installationSteps","Passos de instalação",p.installationSteps)}</div>
      </div>
    </div>

    <div class="form-card">
      <div class="section-title"><h3>Testes, UAT e implantação</h3></div>
      <div class="form-grid">
        ${field("internalTester","Testador interno",p.internalTester)}
        ${field("internalTestDate","Data do teste interno",p.internalTestDate,"date")}
        ${selectField("internalTestResult","Resultado interno",TEST_RESULTS,p.internalTestResult)}
        ${field("ownerTester","Testado pelo owner",p.ownerTester)}
        ${field("ownerTestDate","Data do UAT",p.ownerTestDate,"date")}
        ${selectField("ownerTestResult","Resultado UAT",TEST_RESULTS,p.ownerTestResult)}
        <div class="form-group full">${textArea("issuesFound","Issues encontrados",p.issuesFound)}</div>
        <div class="form-group full">${textArea("resolution","Resolução",p.resolution)}</div>
        ${field("deploymentPlatform","Plataforma",p.deploymentPlatform||"SCCM")}
        ${field("applicationId","Application ID",p.applicationId)}
        ${field("targetGroup","Collection / Grupo",p.targetGroup)}
        ${field("pilotDate","Data do piloto",p.pilotDate,"date")}
        ${field("productionDate","Data de produção",p.productionDate,"date")}
        ${field("compliance","Compliance (%)",p.compliance,"number")}
        <div class="form-group full">${textArea("notes","Notas",p.notes)}</div>
      </div>
      <div class="form-actions">
        <button type="button" class="secondary" id="cancelEdit">Cancelar</button>
        <button type="submit" class="primary">Salvar pacote</button>
      </div>
    </div>
  </form>`;
}

function field(name,label,value="",type="text",required=false) {
  return `<div class="form-group"><label>${label}</label><input name="${name}" type="${type}" value="${escapeHtml(value??"")}" ${required?"required":""}></div>`;
}
function textArea(name,label,value="") {
  return `<label>${label}</label><textarea name="${name}">${escapeHtml(value??"")}</textarea>`;
}
function selectField(name,label,options,value) {
  return `<div class="form-group"><label>${label}</label><select name="${name}">${options.map(o=>`<option ${o===value?"selected":""}>${o}</option>`).join("")}</select></div>`;
}

async function renderPackageForm(id = null) {
  state.currentView = "new-package";
  document.querySelectorAll(".nav-item").forEach(x=>x.classList.toggle("active",x.dataset.view==="new-package"));
  const pkg = id ? await SDMDB.getOne(STORES.packages,id) : null;
  state.editingId = id;
  setViewTitle(id ? `Editar ${id}` : "Novo pacote", "Cadastro completo de software");
  viewContainer.innerHTML = packageFormHtml(pkg || {});
  document.getElementById("cancelEdit").onclick = () => navigate("packages");
  document.getElementById("packageForm").onsubmit = savePackageForm;
}

async function savePackageForm(event) {
  event.preventDefault();
  const fd = new FormData(event.target);
  const existing = state.editingId ? await SDMDB.getOne(STORES.packages,state.editingId) : null;
  const obj = Object.fromEntries(fd.entries());
  obj.blocked = event.target.elements.blocked.checked;
  obj.queuePosition = Number(obj.queuePosition||0);
  obj.estimatedEffort = Number(obj.estimatedEffort||0);
  obj.compliance = Number(obj.compliance||0);
  obj.createdAt = existing?.createdAt || new Date().toISOString();
  obj.updatedAt = new Date().toISOString();
  obj.deleted = false;

  await SDMDB.putOne(STORES.packages,obj);
  await SDMDB.addActivity(obj.id, existing ? "Updated" : "Created", existing ? "Registro atualizado" : "Pacote criado");
  await refreshData();
  showToast("Pacote salvo com sucesso.");
  navigate("packages");
}

async function showPackage(id) {
  const p = await SDMDB.getOne(STORES.packages,id);
  const acts = state.activities.filter(a=>a.packageId===id).sort((a,b)=>b.timestamp.localeCompare(a.timestamp));
  modalTitle.textContent = `${p.id} — ${p.packageName}`;
  modalBody.innerHTML = `
    <div class="grid cards">
      <div class="card metric"><div class="label">Prioridade</div><div class="value" style="font-size:22px">${escapeHtml(p.priority)}</div></div>
      <div class="card metric"><div class="label">Fase</div><div class="value" style="font-size:22px">${escapeHtml(p.phase)}</div></div>
      <div class="card metric"><div class="label">Analista</div><div class="value" style="font-size:22px">${escapeHtml(p.assignedAnalyst||"—")}</div></div>
      <div class="card metric"><div class="label">Score</div><div class="value" style="font-size:22px">${calculateScore(p)}</div></div>
    </div>
    <div class="form-card" style="margin-top:18px">
      <div class="form-grid">
        ${detail("Versão",p.version)}${detail("Fabricante",p.vendor)}${detail("Prazo",formatDate(p.expectedDeliveryDate))}
        ${detail("Fonte",p.sourcePath)}${detail("Instalador",p.installerType)}${detail("Arquitetura",p.architecture)}
        ${detail("Instalação",p.installCommand)}${detail("Desinstalação",p.uninstallCommand)}${detail("Detecção",p.detectionMethod)}
        ${detail("Teste interno",p.internalTestResult)}${detail("UAT",p.ownerTestResult)}${detail("Plataforma",p.deploymentPlatform)}
      </div>
    </div>
    <div class="form-card">
      <h3>Histórico</h3>
      ${acts.length?acts.map(a=>`<div class="alert"><strong>${new Date(a.timestamp).toLocaleString("pt-BR")}</strong> — ${escapeHtml(a.action)}<br><small>${escapeHtml(a.details)} | ${escapeHtml(a.user)}</small></div>`).join(""):`<div class="empty">Sem histórico.</div>`}
      <div class="form-actions">
        <button class="danger" id="deletePackage">Excluir</button>
        <button class="secondary" id="editFromModal">Editar</button>
      </div>
    </div>`;
  modal.classList.remove("hidden");
  document.getElementById("editFromModal").onclick = ()=>{ modal.classList.add("hidden"); renderPackageForm(id); };
  document.getElementById("deletePackage").onclick = async ()=>{
    if(confirm(`Excluir ${id}? Esta ação remove o registro local.`)){
      await SDMDB.deleteOne(STORES.packages,id);
      await SDMDB.addActivity(id,"Deleted","Registro excluído");
      modal.classList.add("hidden");
      await refreshData();
      navigate("packages");
      showToast("Pacote excluído.");
    }
  };
}

function detail(label,value) {
  return `<div class="form-group"><label>${label}</label><div>${escapeHtml(value||"—")}</div></div>`;
}

function renderQueue() {
  setViewTitle("Fila de trabalho","Ordem sugerida por prioridade, prazo, idade e complexidade");
  const list = filteredPackages(p=>!["Completed","Cancelled"].includes(p.phase)).sort((a,b)=>calculateScore(b)-calculateScore(a));
  viewContainer.innerHTML = `
    <div class="card">
      <div class="section-title"><h3>Fila sugerida</h3><span class="badge">Score automático</span></div>
      <div class="table-wrap"><table><thead><tr><th>#</th><th>ID</th><th>Pacote</th><th>Analista</th><th>Prioridade</th><th>Complexidade</th><th>Prazo</th><th>Score</th><th>Posição manual</th></tr></thead>
      <tbody>${list.map((p,i)=>`<tr><td>${i+1}</td><td>${p.id}</td><td>${escapeHtml(p.packageName)}</td><td>${escapeHtml(p.assignedAnalyst||"—")}</td><td>${p.priority}</td><td>${p.complexity}</td><td>${formatDate(p.expectedDeliveryDate)}</td><td><strong>${calculateScore(p)}</strong></td><td>${p.queuePosition||"—"}</td></tr>`).join("")}</tbody></table></div>
    </div>`;
}

function renderKanban() {
  setViewTitle("Kanban","Fluxo visual dos pacotes");
  const cols = ["New Request","Waiting for Source","Packaging","Internal Testing","Owner UAT","Ready for Deployment","Production Deployment","Completed"];
  viewContainer.innerHTML = `<div class="kanban">${cols.map(phase=>`
    <div class="kanban-column" data-phase="${phase}">
      <h4>${phase}<span>${state.packages.filter(p=>p.phase===phase).length}</span></h4>
      ${state.packages.filter(p=>p.phase===phase).map(p=>`
        <div class="kanban-card" draggable="true" data-id="${p.id}">
          <strong>${escapeHtml(p.packageName)}</strong>
          <small>${p.id} • ${escapeHtml(p.version||"Sem versão")}</small>
          <small>${escapeHtml(p.assignedAnalyst||"Não atribuído")} • ${p.priority}</small>
          <small>Prazo: ${formatDate(p.expectedDeliveryDate)}</small>
        </div>`).join("")}
    </div>`).join("")}</div>`;
  document.querySelectorAll(".kanban-card").forEach(card=>{
    card.addEventListener("dragstart",e=>e.dataTransfer.setData("text/plain",card.dataset.id));
  });
  document.querySelectorAll(".kanban-column").forEach(col=>{
    col.addEventListener("dragover",e=>e.preventDefault());
    col.addEventListener("drop",async e=>{
      e.preventDefault();
      const id=e.dataTransfer.getData("text/plain");
      const p=await SDMDB.getOne(STORES.packages,id);
      const old=p.phase; p.phase=col.dataset.phase; p.updatedAt=new Date().toISOString();
      await SDMDB.putOne(STORES.packages,p);
      await SDMDB.addActivity(id,"Phase changed",`${old} → ${p.phase}`);
      await refreshData(); renderKanban(); showToast("Fase atualizada.");
    });
  });
}

function renderTesting() {
  renderPackages(p => ["Internal Testing","Owner UAT"].includes(p.phase) || ["Pending","Failed"].includes(p.internalTestResult) || ["Pending","Failed"].includes(p.ownerTestResult), "Testes e UAT", "Pacotes aguardando validação");
}

function renderBlocked() {
  renderPackages(p => p.blocked || p.phase==="Blocked", "Pacotes bloqueados", "Itens que demandam ação");
}

function renderReports() {
  setViewTitle("Relatórios","Exportações visuais em HTML");
  const options = [
    ["Todos os pacotes",()=>state.packages],
    ["Pacotes atrasados",()=>state.packages.filter(p=>p.expectedDeliveryDate && p.expectedDeliveryDate < new Date().toISOString().slice(0,10) && p.phase!=="Completed")],
    ["Pacotes bloqueados",()=>state.packages.filter(p=>p.blocked||p.phase==="Blocked")],
    ["Aguardando UAT",()=>state.packages.filter(p=>p.phase==="Owner UAT")],
    ["Concluídos",()=>state.packages.filter(p=>p.phase==="Completed")],
    ["Fila priorizada",()=>[...state.packages].sort((a,b)=>calculateScore(b)-calculateScore(a))]
  ];
  viewContainer.innerHTML = `<div class="report-options">${options.map((o,i)=>`
    <div class="report-option"><h4>${o[0]}</h4><p>Gera um relatório HTML limpo, imprimível e fácil de converter para PDF.</p><button class="primary report-btn" data-index="${i}">Gerar relatório</button></div>`).join("")}</div>`;
  document.querySelectorAll(".report-btn").forEach(btn=>btn.onclick=()=>exportHtml(options[btn.dataset.index][1](),options[btn.dataset.index][0]));
}

function exportHtml(list,title) {
  const rows = list.map(p=>`<tr><td>${p.id}</td><td>${escapeHtml(p.packageName)}</td><td>${escapeHtml(p.version||"")}</td><td>${escapeHtml(p.assignedAnalyst||"")}</td><td>${p.priority}</td><td>${p.phase}</td><td>${formatDate(p.expectedDeliveryDate)}</td><td>${calculateScore(p)}</td></tr>`).join("");
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title><style>body{font-family:Segoe UI,Arial;padding:30px;color:#172033}h1{margin-bottom:4px}p{color:#667085}table{border-collapse:collapse;width:100%;margin-top:25px}th,td{border:1px solid #d7dde7;padding:9px;text-align:left;font-size:12px}th{background:#eef3f8}</style></head><body><h1>${title}</h1><p>Gerado em ${new Date().toLocaleString("pt-BR")} • ${list.length} registros</p><table><thead><tr><th>ID</th><th>Pacote</th><th>Versão</th><th>Analista</th><th>Prioridade</th><th>Fase</th><th>Prazo</th><th>Score</th></tr></thead><tbody>${rows}</tbody></table></body></html>`;
  downloadBlob(new Blob([html],{type:"text/html"}),`${title.replace(/\s+/g,"_")}_${Date.now()}.html`);
}

function renderBackup() {
  setViewTitle("Backup e restauração","Proteja o banco local do navegador");
  viewContainer.innerHTML = `
    <div class="grid" style="grid-template-columns:1fr 1fr">
      <div class="card"><h3>Backup completo</h3><p>Exporta pacotes, histórico e configurações para JSON.</p><button id="backupBtn" class="primary">Gerar backup JSON</button></div>
      <div class="card"><h3>Restaurar backup</h3><p>Substitui o conteúdo atual pelo arquivo selecionado.</p><input id="restoreFile" type="file" accept=".json"><button id="restoreBtn" class="secondary" style="margin-top:12px">Restaurar</button></div>
    </div>
    <div class="card" style="margin-top:18px"><h3>Segurança</h3><div id="lastBackupInfo">Último backup: verificando...</div><p>Os dados ficam associados a este navegador, perfil e computador. Mantenha cópias do JSON fora da máquina.</p></div>`;
  loadLastBackup();
  document.getElementById("backupBtn").onclick = backupDatabase;
  document.getElementById("restoreBtn").onclick = restoreDatabase;
}

async function loadLastBackup() {
  const last = await SDMDB.loadSetting("lastBackup");
  document.getElementById("lastBackupInfo").textContent = `Último backup: ${last ? new Date(last).toLocaleString("pt-BR") : "nunca realizado"}`;
}

async function backupDatabase() {
  const data = {
    schemaVersion: 1,
    exportedAt: new Date().toISOString(),
    packages: await SDMDB.getAll(STORES.packages),
    activities: await SDMDB.getAll(STORES.activities),
    settings: await SDMDB.getAll(STORES.settings)
  };
  downloadBlob(new Blob([JSON.stringify(data,null,2)],{type:"application/json"}),`SoftwareDeployment_Backup_${new Date().toISOString().replace(/[:.]/g,"-")}.json`);
  await SDMDB.saveSetting("lastBackup",new Date().toISOString());
  loadLastBackup();
  showToast("Backup gerado com sucesso.");
}

async function restoreDatabase() {
  const file=document.getElementById("restoreFile").files[0];
  if(!file) return alert("Selecione um arquivo JSON.");
  if(!confirm("A restauração substituirá o banco atual. Continuar?")) return;
  try{
    const data=JSON.parse(await file.text());
    await SDMDB.clearStore(STORES.packages);
    await SDMDB.clearStore(STORES.activities);
    for(const p of data.packages||[]) await SDMDB.putOne(STORES.packages,p);
    for(const a of data.activities||[]) {
      const copy={...a}; delete copy.activityId;
      await new Promise((res,rej)=>{const r=db.transaction(STORES.activities,"readwrite").objectStore(STORES.activities).add(copy);r.onsuccess=res;r.onerror=()=>rej(r.error);});
    }
    await refreshData();
    showToast("Backup restaurado.");
    navigate("dashboard");
  }catch(e){ alert("Falha ao restaurar: "+e.message); }
}

function downloadBlob(blob,filename) {
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download=filename; a.click(); setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}

function renderSettings() {
  setViewTitle("Configurações","Preferências locais");
  viewContainer.innerHTML = `
    <div class="card" style="max-width:700px">
      <h3>Identidade local</h3>
      <div class="form-group"><label>Nome do usuário para o histórico</label><input id="localUser" placeholder="Seu nome"></div>
      <div class="form-actions"><button id="saveSettings" class="primary">Salvar configurações</button></div>
    </div>
    <div class="card" style="max-width:700px;margin-top:18px">
      <h3>Dados de demonstração</h3>
      <p>Adiciona alguns pacotes para testar o dashboard, relatórios e Kanban.</p>
      <button id="seedDemo" class="secondary">Carregar dados de demonstração</button>
    </div>`;
  SDMDB.loadSetting("localUser","Local User").then(v=>document.getElementById("localUser").value=v);
  document.getElementById("saveSettings").onclick=async()=>{await SDMDB.saveSetting("localUser",document.getElementById("localUser").value||"Local User");showToast("Configurações salvas.");};
  document.getElementById("seedDemo").onclick=seedDemo;
}

async function seedDemo(){
  if(state.packages.length && !confirm("Já existem dados. Adicionar exemplos mesmo assim?")) return;
  const samples=[
    {packageName:"7-Zip",vendor:"Igor Pavlov",version:"24.09",assignedAnalyst:"José",priority:"High",complexity:"Low",phase:"Packaging",expectedDeliveryDate:new Date(Date.now()+3*86400000).toISOString().slice(0,10),requestDate:new Date(Date.now()-4*86400000).toISOString().slice(0,10),installerType:"EXE",internalTestResult:"Pending",ownerTestResult:"Pending"},
    {packageName:"Microsoft Edge Enterprise",vendor:"Microsoft",version:"Current",assignedAnalyst:"Ana",priority:"Critical",complexity:"Medium",phase:"Owner UAT",expectedDeliveryDate:new Date(Date.now()-2*86400000).toISOString().slice(0,10),requestDate:new Date(Date.now()-12*86400000).toISOString().slice(0,10),installerType:"MSI",internalTestResult:"Passed",ownerTestResult:"Pending"},
    {packageName:"M-Files Online",vendor:"M-Files",version:"26.5",assignedAnalyst:"Carlos",priority:"Medium",complexity:"Very High",phase:"Blocked",blocked:true,blockingReason:"Aguardando licença e documentação",expectedDeliveryDate:new Date(Date.now()+7*86400000).toISOString().slice(0,10),requestDate:new Date(Date.now()-9*86400000).toISOString().slice(0,10),installerType:"MSI",internalTestResult:"Failed",ownerTestResult:"Pending"},
    {packageName:"Think-cell",vendor:"think-cell",version:"12",assignedAnalyst:"Marina",priority:"Low",complexity:"Medium",phase:"Completed",expectedDeliveryDate:new Date(Date.now()-10*86400000).toISOString().slice(0,10),requestDate:new Date(Date.now()-30*86400000).toISOString().slice(0,10),installerType:"MSI",internalTestResult:"Passed",ownerTestResult:"Passed",compliance:97}
  ];
  for(const s of samples){
    const p={id:generateId(),status:"Open",queuePosition:0,estimatedEffort:0,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),...s};
    state.packages.push(p);
    await SDMDB.putOne(STORES.packages,p); await SDMDB.addActivity(p.id,"Created","Registro de demonstração criado");
  }
  await refreshData(); showToast("Dados de demonstração adicionados."); navigate("dashboard");
}

function navigate(view) {
  state.currentView = view;
  document.querySelectorAll(".nav-item").forEach(x=>x.classList.toggle("active",x.dataset.view===view));
  if(view==="dashboard") renderDashboard();
  if(view==="packages") renderPackages();
  if(view==="new-package") renderPackageForm();
  if(view==="queue") renderQueue();
  if(view==="kanban") renderKanban();
  if(view==="testing") renderTesting();
  if(view==="blocked") renderBlocked();
  if(view==="reports") renderReports();
  if(view==="backup") renderBackup();
  if(view==="settings") renderSettings();
}

async function init() {
  await SDMDB.openDatabase();
  await refreshData();
  const theme = localStorage.getItem("sdm-theme");
  if(theme==="dark") document.body.classList.add("dark");

  document.querySelectorAll(".nav-item").forEach(btn=>btn.onclick=()=>navigate(btn.dataset.view));
  document.getElementById("quickAdd").onclick=()=>navigate("new-package");
  document.getElementById("themeToggle").onclick=()=>{
    document.body.classList.toggle("dark");
    localStorage.setItem("sdm-theme",document.body.classList.contains("dark")?"dark":"light");
  };
  document.getElementById("globalSearch").addEventListener("input",e=>{
    state.search=e.target.value;
    if(state.currentView==="packages") renderPackages();
  });
  document.getElementById("modalClose").onclick=()=>modal.classList.add("hidden");
  modal.addEventListener("click",e=>{ if(e.target===modal) modal.classList.add("hidden"); });
  renderDashboard();
}

init().catch(err=>{
  document.getElementById("dbStatus").textContent="Erro no IndexedDB";
  alert("Falha ao iniciar o banco local: "+err.message);
});
