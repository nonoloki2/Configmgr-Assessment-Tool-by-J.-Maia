
SOFTWARE DEPLOYMENT MANAGER
===========================

Como executar
-------------
1. Extraia a pasta completa.
2. Abra o arquivo index.html no navegador.
3. Use preferencialmente Chrome, Edge ou Firefox atualizados.
4. Não use janela anônima/privativa.
5. Faça backups periódicos em "Backup e restauração".

Armazenamento
-------------
- Os pacotes e históricos são armazenados em IndexedDB.
- O tema visual fica em localStorage.
- Os dados pertencem ao navegador, perfil e computador utilizados.
- Limpar dados do site/navegador pode remover o banco.

Funções incluídas
-----------------
- Dashboard
- Cadastro completo
- Edição e exclusão
- Fila inteligente por score
- Kanban com arrastar e soltar
- Testes e UAT
- Bloqueios
- Pesquisa e filtros
- Relatórios HTML
- Backup e restauração JSON
- Histórico de alterações
- Modo claro/escuro
- Dados de demonstração

Observação
----------
Para uso mais confiável, execute com um pequeno servidor local. Exemplo com Python:

python -m http.server 8080

Depois abra:
http://localhost:8080
