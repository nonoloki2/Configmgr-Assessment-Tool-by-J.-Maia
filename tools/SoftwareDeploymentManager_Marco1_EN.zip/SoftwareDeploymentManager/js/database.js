
const DB_NAME = "SoftwareDeploymentManagerDB";
const DB_VERSION = 1;
const STORES = {
  packages: "packages",
  activities: "activities",
  settings: "settings"
};

let db;

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = event => {
      db = event.target.result;

      if (!db.objectStoreNames.contains(STORES.packages)) {
        const store = db.createObjectStore(STORES.packages, { keyPath: "id" });
        store.createIndex("status", "status");
        store.createIndex("phase", "phase");
        store.createIndex("assignedAnalyst", "assignedAnalyst");
        store.createIndex("priority", "priority");
        store.createIndex("updatedAt", "updatedAt");
      }

      if (!db.objectStoreNames.contains(STORES.activities)) {
        const activityStore = db.createObjectStore(STORES.activities, { keyPath: "activityId", autoIncrement: true });
        activityStore.createIndex("packageId", "packageId");
        activityStore.createIndex("timestamp", "timestamp");
      }

      if (!db.objectStoreNames.contains(STORES.settings)) {
        db.createObjectStore(STORES.settings, { keyPath: "key" });
      }
    };

    request.onsuccess = event => {
      db = event.target.result;
      resolve(db);
    };

    request.onerror = () => reject(request.error);
  });
}

function storeTransaction(storeName, mode = "readonly") {
  return db.transaction(storeName, mode).objectStore(storeName);
}

function getAll(storeName) {
  return new Promise((resolve, reject) => {
    const request = storeTransaction(storeName).getAll();
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function getOne(storeName, key) {
  return new Promise((resolve, reject) => {
    const request = storeTransaction(storeName).get(key);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function putOne(storeName, value) {
  return new Promise((resolve, reject) => {
    const request = storeTransaction(storeName, "readwrite").put(value);
    request.onsuccess = () => resolve(value);
    request.onerror = () => reject(request.error);
  });
}

function deleteOne(storeName, key) {
  return new Promise((resolve, reject) => {
    const request = storeTransaction(storeName, "readwrite").delete(key);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

function clearStore(storeName) {
  return new Promise((resolve, reject) => {
    const request = storeTransaction(storeName, "readwrite").clear();
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

async function addActivity(packageId, action, details, user = "Local User") {
  const activity = {
    packageId,
    action,
    details,
    user,
    timestamp: new Date().toISOString()
  };
  return new Promise((resolve, reject) => {
    const request = storeTransaction(STORES.activities, "readwrite").add(activity);
    request.onsuccess = () => resolve(activity);
    request.onerror = () => reject(request.error);
  });
}

async function saveSetting(key, value) {
  return putOne(STORES.settings, { key, value });
}

async function loadSetting(key, fallback = null) {
  const item = await getOne(STORES.settings, key);
  return item ? item.value : fallback;
}

window.SDMDB = {
  openDatabase, getAll, getOne, putOne, deleteOne, clearStore,
  addActivity, saveSetting, loadSetting, STORES
};
