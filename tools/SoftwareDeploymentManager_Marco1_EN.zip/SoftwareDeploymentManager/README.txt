SOFTWARE DEPLOYMENT MANAGER
===========================

How to run
----------
1. Extract the complete folder.
2. Open index.html in your browser.
3. Prefer a current version of Chrome, Edge, or Firefox.
4. Do not use InPrivate or Incognito mode.
5. Create regular backups under "Backup & Restore".

Storage
-------
- Packages and activity history are stored in IndexedDB.
- The visual theme is stored in localStorage.
- Data belongs to the browser, browser profile, and computer being used.
- Clearing browser site data may remove the local database.

Included features
-----------------
- Dashboard
- Complete package registration
- Edit and delete
- Intelligent work queue
- Drag-and-drop Kanban
- Testing and UAT tracking
- Blocked package tracking
- Search and filters
- HTML reports
- JSON backup and restore
- Activity history
- Light and dark themes
- Optional demo data

Recommended local server
------------------------
Run this command inside the extracted folder:

python -m http.server 8080

Then open:

http://localhost:8080
