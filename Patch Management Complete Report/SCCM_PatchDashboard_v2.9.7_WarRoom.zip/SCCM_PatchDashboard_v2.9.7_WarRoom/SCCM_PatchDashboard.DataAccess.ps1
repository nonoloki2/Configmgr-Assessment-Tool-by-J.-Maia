﻿function ConvertTo-NormalizedDeploymentStatus {
    <#
        Mapeia o Status_State (texto vindo de v_StateNames) para os 4
        buckets do dashboard: Success / InProgress / Error / Unknown.
        Baseado nos valores REAIS confirmados no ambiente (via
        03_Diagnostico_Status_State.sql), nao mais em suposicao.
        Qualquer valor novo/nao previsto cai em Unknown (e eh logado).
    #>
    param([string]$StatusState, [string]$LogPath)

    if ([string]::IsNullOrWhiteSpace($StatusState)) { return 'Unknown' }

    switch ($StatusState.Trim()) {
        'Compliant'                       { return 'Success' }
        'Successfully installed update(s)' { return 'Success' }

        'Failed to install update(s)'     { return 'Error' }
        'Failed to download update(s)'    { return 'Error' }

        'Downloaded update(s)'            { return 'InProgress' }
        'Pending system restart'          { return 'InProgress' }
        'Waiting for restart'             { return 'InProgress' }

        'Enforcement state unknown'       { return 'Unknown' }
        'Non-compliant'                   { return 'Unknown' }

        default {
            if ($LogPath) { Write-Log $LogPath "Status_State '$StatusState' sem mapeamento conhecido; tratado como Unknown." 'WARN' }
            return 'Unknown'
        }
    }
}

# ================================================================
# CAMADA SQL - ADO.NET puro (System.Data.SqlClient), sem depender
# de nenhum modulo externo (nada a instalar no servidor).
# ================================================================

Add-Type -AssemblyName System.Data -ErrorAction SilentlyContinue

function New-SqlConnectionString {
    param(
        [Parameter(Mandatory)][string]$Server,
        [Parameter(Mandatory)][string]$Database
    )
    # Autenticacao Windows Integrada (conta de servico da automacao).
    # Se o ambiente exigir login SQL, troque a linha abaixo por:
    #   "Server=$Server;Database=$Database;User ID=SEU_USER;Password=SUA_SENHA;TrustServerCertificate=True;Connection Timeout=30;"
    return "Server=$Server;Database=$Database;Integrated Security=True;TrustServerCertificate=True;Connection Timeout=30;"
}

function ConvertFrom-DataTable {
    <#
        Converte um System.Data.DataTable em uma lista de PSCustomObject,
        preservando [DBNull]::Value como esta (codigo existente ja checa isso).
    #>
    param([Parameter(Mandatory)][System.Data.DataTable]$Table)

    $colNames = @($Table.Columns | ForEach-Object { $_.ColumnName })
    $result = New-Object System.Collections.Generic.List[object]
    foreach ($row in $Table.Rows) {
        $props = [ordered]@{}
        foreach ($c in $colNames) { $props[$c] = $row[$c] }
        $result.Add([pscustomobject]$props)
    }
    return $result.ToArray()
}

function Get-SqlDataSet {
    <#
        Executa uma query (texto ou arquivo .sql) e devolve um DataSet.
        Suporta multiplos result sets (o SqlDataAdapter preenche
        $ds.Tables[0], [1], [2]... na ordem em que a query os retorna).
    #>
    param(
        [Parameter(Mandatory)][string]$ConnectionString,
        [string]$Query,
        [string]$InputFile,
        [int]$TimeoutSeconds = 300
    )

    if ($InputFile) { $Query = Get-Content -LiteralPath $InputFile -Raw -Encoding UTF8 }
    if ([string]::IsNullOrWhiteSpace($Query)) { throw "Get-SqlDataSet: nenhuma query informada (Query ou InputFile)." }

    $conn = New-Object System.Data.SqlClient.SqlConnection $ConnectionString
    $cmd  = New-Object System.Data.SqlClient.SqlCommand $Query, $conn
    $cmd.CommandTimeout = $TimeoutSeconds
    $ds = New-Object System.Data.DataSet
    $da = New-Object System.Data.SqlClient.SqlDataAdapter $cmd
    try {
        $da.Fill($ds) | Out-Null
    }
    finally {
        $conn.Close()
        $conn.Dispose()
    }
    return $ds
}

function Invoke-SqlNonQuery {
    <# Executa comandos sem retorno de linhas (INSERT/UPDATE/MERGE). #>
    param(
        [Parameter(Mandatory)][string]$ConnectionString,
        [Parameter(Mandatory)][string]$Query,
        [int]$TimeoutSeconds = 60
    )
    $conn = New-Object System.Data.SqlClient.SqlConnection $ConnectionString
    $cmd  = New-Object System.Data.SqlClient.SqlCommand $Query, $conn
    $cmd.CommandTimeout = $TimeoutSeconds
    try {
        $conn.Open()
        $cmd.ExecuteNonQuery() | Out-Null
    }
    finally {
        $conn.Close()
        $conn.Dispose()
    }
}

# ================================================================
# ETAPA 1 - extracao via SQL (substitui Get-SmsProviderData / WMI)
# ================================================================

function Get-SqlComplianceRows {
    <#
        Executa a query da ETAPA 1 (01_Compliance_Query_AutoResolve.sql) via
        ADO.NET e devolve os dispositivos ja no MESMO formato de objeto que
        Convert-AssetsToRows produz hoje, para o dashboard nao precisar mudar.
        Colunas que so existiam via WMI (ClientType, Preferred DP, Pending
        Reboot, scans, etc.) ficam em branco nesta etapa, por decisao combinada.
    #>
    param(
        [Parameter(Mandatory)][string]$SqlServer,
        [Parameter(Mandatory)][string]$Database,
        [Parameter(Mandatory)][string]$DeploymentNamePattern,
        [Parameter(Mandatory)][string]$QueryFilePath,
        [Parameter(Mandatory)][string]$LogPath
    )

    $connStr = New-SqlConnectionString -Server $SqlServer -Database $Database

    $sqlText = Get-Content -LiteralPath $QueryFilePath -Raw -Encoding UTF8
    $sqlText = $sqlText -replace `
        "DECLARE @DeploymentNamePattern NVARCHAR\(200\) =\s*\r?\n\s*'.*?';", `
        "DECLARE @DeploymentNamePattern NVARCHAR(200) = '$DeploymentNamePattern';"

    Write-Log $LogPath "Executando query de compliance via ADO.NET (AssignmentID/KBs/ciclo resolvidos dinamicamente pelo proprio T-SQL)."

    $ds = Get-SqlDataSet -ConnectionString $connStr -Query $sqlText -TimeoutSeconds 300

    if ($ds.Tables.Count -lt 3) {
        throw "A query nao devolveu os 3 result sets esperados (diagnostico, compliant, non-compliant). Verifique se ela rodou ate o fim sem erro no SQL Server."
    }

    $diagRows = ConvertFrom-DataTable -Table $ds.Tables[0]
    $diag = $diagRows | Select-Object -First 1

    Write-Log $LogPath ("Resolvido -> AssignmentID={0} | Deployment='{1}' | Cycle_Start={2} | Cycle_Day={3} | KBs={4}" -f `
        $diag.Resolved_AssignmentID, $diag.Resolved_DeploymentName, $diag.Cycle_Start_Date, $diag.Cycle_Day_Number, $diag.Resolved_KBs)

    $compliantRows    = ConvertFrom-DataTable -Table $ds.Tables[1]
    $nonCompliantRows = ConvertFrom-DataTable -Table $ds.Tables[2]

    # "Preferred Distribution Points" nao tem fonte SQL confiavel neste
    # ambiente (v_CombinedDeviceResources nao tem coluna de boundary group
    # por dispositivo) - fica em branco de proposito, ver nota no .sql.

    $rows = New-Object System.Collections.Generic.List[object]

    function Get-SqlVal($value) { if ($null -eq $value -or $value -eq [DBNull]::Value) { return $null } else { return $value } }

    foreach ($r in @($compliantRows) + @($nonCompliantRows)) {
        $statusState = [string]$r.Status_State
        $complianceBucket = [string]$r.Compliance_Bucket

        <#
            Classificacao dos cards do dashboard: prioriza compliance REAL
            (v_UpdateComplianceStatus, a mesma fonte do "% Compliant" oficial
            do console) sobre o status de enforcement (v_CIAssignmentStatus).
            - Compliant  -> Success (bate com o % do console)
            - NaoCompliant -> refina com Status_State (In Progress / Error /
              Unknown); se Status_State disser "Success" mas o dispositivo
              nao esta realmente compliant (ex.: pendente reavaliacao),
              cai em Unknown em vez de inflar o Success.
        #>
        if ($complianceBucket -eq 'Compliant') {
            $deploymentStatus = 'Success'
        } else {
            $normalized = ConvertTo-NormalizedDeploymentStatus -StatusState $statusState -LogPath $LogPath
            $deploymentStatus = if ($normalized -eq 'Success') { 'Unknown' } else { $normalized }
        }

        $errorCodeValue = [UInt64]0
        if ($deploymentStatus -eq 'Error' -and $r.Hex_Error_Code -ne [DBNull]::Value -and $r.Hex_Error_Code) {
            $hexStr = [string]$r.Hex_Error_Code
            if ($hexStr -match '^0x[0-9A-Fa-f]+$') {
                try { $errorCodeValue = [Convert]::ToUInt64($hexStr.Substring(2), 16) }
                catch { Write-Log $LogPath "Falha ao converter Hex_Error_Code '$hexStr' para numero (device $([string]$r.ComputerName))." 'WARN' }
            } else {
                Write-Log $LogPath "Hex_Error_Code em formato inesperado: '$hexStr' (device $([string]$r.ComputerName))." 'WARN'
            }
        }
        $errorDetail = if ($errorCodeValue -ne 0) {
            Get-ErrorDetail -Code $errorCodeValue -LastEnforcementMessage '' -StatusDescription ''
        } else { '' }
        $recommendedActions = if ($errorCodeValue -ne 0) { Get-ErrorRecommendations -Code $errorCodeValue } else { '' }

        $hasOSDomain = $r.PSObject.Properties.Name -contains 'OSDomain'

        $clientInstalledRaw = Get-SqlVal $r.ClientInstalled
        $client = if ($clientInstalledRaw -eq 1) { 'Yes' } elseif ($null -ne $clientInstalledRaw) { 'No' } else { '' }
        $clientStatus = Get-ClientStatusLabel (Get-SqlVal $r.ClientActiveStatus) $clientInstalledRaw
        $clientCheckResult = Get-ClientCheckResultLabel (Get-SqlVal $r.ClientCheckPassRaw) $null
        $policyRequest = Format-DateValue (Get-SqlVal $r.LastPolicyRequest)
        $heartbeatDdr  = Format-DateValue (Get-SqlVal $r.LastDDR)
        $hardwareScan  = Format-DateValue (Get-SqlVal $r.LastHW)
        $softwareScan  = Format-DateValue (Get-SqlVal $r.LastSW)
        $adSite        = [string](Get-SqlVal $r.ADSiteName)
        $siteCodeVal   = [string](Get-SqlVal $r.SiteCode)
        $managementPointVal = [string](Get-SqlVal $r.LastMPServerName)
        $statusMessageVal   = Format-DateValue (Get-SqlVal $r.LastStatusMessageRaw)

        $preferredDPs = ''  # sem fonte SQL confiavel neste ambiente (ver nota no .sql)
        $osCaption     = [string](Get-SqlVal $r.OSCaption)
        $osBuildStr    = [string]$r.FullOSBuild
        $buildParts    = $osBuildStr -split '\.'
        $buildForVersionLookup = if ($buildParts.Count -ge 3) { $buildParts[2] } else { $osBuildStr }
        $osVersionLabel = Get-WindowsVersionLabel -Caption $osCaption -Build $buildForVersionLookup
        $uptimeVal     = Format-Uptime (Get-SqlVal $r.LastBootUpTime)

        # Pending Reboot / Reason - mesmo bitmask ClientState que o script original
        # decodificava a partir de SMS_CombinedDeviceResources (aqui via v_CombinedDeviceResources).
        $pendingRestart = ''
        $rebootReason = ''
        $clientStateRaw = Get-SqlVal $r.ClientStateRaw
        if ($null -ne $clientStateRaw) {
            $stateInt = 0
            if ([int]::TryParse([string]$clientStateRaw, [ref]$stateInt)) {
                if ($stateInt -eq 0) {
                    $pendingRestart = 'No'
                } else {
                    $pendingRestart = 'Yes'
                    $reasons = New-Object System.Collections.Generic.List[string]
                    if (($stateInt -band 1) -ne 0) { $reasons.Add('Configuration Manager') }
                    if (($stateInt -band 2) -ne 0) { $reasons.Add('File Rename') }
                    if (($stateInt -band 4) -ne 0) { $reasons.Add('Windows Update') }
                    if (($stateInt -band 8) -ne 0) { $reasons.Add('Add or Remove Feature') }
                    $knownMask = 1 -bor 2 -bor 4 -bor 8
                    $unknownBits = $stateInt -band (-bnot $knownMask)
                    if ($unknownBits -ne 0) { $reasons.Add("Other SCCM reason bits: $unknownBits") }
                    if ($reasons.Count -eq 0) { $reasons.Add("ClientState $stateInt") }
                    $rebootReason = ($reasons -join ' + ')
                }
            }
        }

        $rows.Add([pscustomobject]@{
            Device                      = [string]$r.ComputerName
            ClientType                  = ''
            Client                      = $client
            CurrentLoggedOnUser         = [string]$r.UserId
            UserUPN                     = [string]$r.User_Email
            SiteCode                    = $siteCodeVal
            ClientStatus                = $clientStatus
            ClientCheckResult           = $clientCheckResult
            PolicyRequest               = $policyRequest
            HeartbeatDDR                = $heartbeatDdr
            HardwareScan                = $hardwareScan
            SoftwareScan                = $softwareScan
            ManagementPoint             = $managementPointVal
            StatusMessage                = $statusMessageVal
            PreferredDistributionPoints = $preferredDPs
            ADSite                      = $adSite
            Domain                      = if ($hasOSDomain) { [string]$r.OSDomain } else { '' }
            ADComputerStatus            = 'Unknown'
            DomainTrustStatus           = 'Not tested'
            DomainTrustDetail           = ''
            Uptime                      = $uptimeVal
            OperatingSystem             = $osCaption
            OSVersion                   = $osVersionLabel
            OSBuildNumber               = [string]$r.FullOSBuild
            PendingRestart              = $pendingRestart
            RebootReason                = $rebootReason
            RebootClientState           = ''
            DeploymentStatus            = $deploymentStatus
            ErrorCode                   = if ($deploymentStatus -eq 'Error' -and $r.Hex_Error_Code -ne [DBNull]::Value) { [string]$r.Hex_Error_Code } else { '' }
            ErrorDetail                 = $errorDetail
            RecommendedActions          = $recommendedActions
            LastStatusTime              = if ($r.Last_Modification -ne [DBNull]::Value) { [string]$r.Last_Modification } else { '' }
            ResourceID                  = 0
            ComplianceBucket            = [string]$r.Compliance_Bucket
            CycleStartDate              = [string]$diag.Cycle_Start_Date
            CycleDayNumber              = [int]$diag.Cycle_Day_Number
        })
    }

    [pscustomobject]@{
        Rows           = $rows.ToArray()
        AssignmentID   = [string]$diag.Resolved_AssignmentID
        DeploymentName = [string]$diag.Resolved_DeploymentName
        CollectionID   = [string]$diag.CollectionID
        CollectionName = [string]$diag.Resolved_CollectionName
        CycleStartDate = [datetime]$diag.Cycle_Start_Date
        CycleDayNumber = [int]$diag.Cycle_Day_Number
        ResolvedKBs    = [string]$diag.Resolved_KBs
    }
}



function Add-SmsProviderErrorEnrichment {
    <#
        Restores the error-code fidelity of the original v2.8 dashboard.
        SQL remains the primary data source. When the SMS Provider is reachable,
        SMS_SUMDeploymentAssetDetails is queried only to enrich StatusErrorCode /
        LastEnforcementErrorCode and the provider's descriptions.
    #>
    param(
        [Parameter(Mandatory)][object[]]$Rows,
        [Parameter(Mandatory)][string]$SqlServer,
        [Parameter(Mandatory)][string]$Database,
        [Parameter(Mandatory)][int]$AssignmentID,
        [Parameter(Mandatory)][string]$LogPath
    )

    if ($Rows.Count -eq 0) { return $Rows }
    $siteCode = ($Database -replace '^CM_','').Trim()
    if ([string]::IsNullOrWhiteSpace($siteCode)) { return $Rows }

    try {
        $connStr = New-SqlConnectionString -Server $SqlServer -Database $Database
        $ds = Get-SqlDataSet -ConnectionString $connStr -Query 'SELECT TOP 1 * FROM v_Identification' -TimeoutSeconds 30
        if ($ds.Tables.Count -lt 1 -or $ds.Tables[0].Rows.Count -lt 1) { throw 'v_Identification returned no rows.' }
        $id = (ConvertFrom-DataTable -Table $ds.Tables[0] | Select-Object -First 1)

        $providerCandidates = New-Object System.Collections.Generic.List[string]
        foreach ($prop in $id.PSObject.Properties) {
            $name = [string]$prop.Name
            $val = if ($prop.Value -eq [DBNull]::Value) { '' } else { [string]$prop.Value }
            if ([string]::IsNullOrWhiteSpace($val)) { continue }
            if ($name -match 'Provider|SiteServer|ServerName') {
                $clean = $val.Trim().TrimStart('\\')
                if ($clean -match '^([^\\,; ]+)') { $clean = $matches[1] }
                if (-not [string]::IsNullOrWhiteSpace($clean) -and -not $providerCandidates.Contains($clean)) { $providerCandidates.Add($clean) }
            }
        }

        if ($providerCandidates.Count -eq 0) { throw 'Could not discover an SMS Provider/site server candidate from v_Identification.' }

        $assets = $null
        $usedProvider = ''
        foreach ($candidate in $providerCandidates) {
            try {
                # A site server exposes SMS_ProviderLocation in root\\SMS even when the provider role is remote.
                $locations = @(Get-CimInstance -ComputerName $candidate -Namespace 'root\SMS' -ClassName SMS_ProviderLocation -OperationTimeoutSec 20 -ErrorAction Stop)
                $provider = @($locations | Where-Object { $_.ProviderForLocalSite } | Select-Object -First 1)
                $providerMachine = if ($provider.Count -gt 0) { [string]$provider[0].Machine } else { '' }
                if ([string]::IsNullOrWhiteSpace($providerMachine)) { $providerMachine = $candidate }
                $providerMachine = $providerMachine.TrimStart('\\')

                $assets = @(Get-CimInstance -ComputerName $providerMachine -Namespace "root\SMS\site_$siteCode" `
                    -Query "SELECT ResourceID,DeviceName,StatusErrorCode,LastEnforcementErrorCode,StatusDescription,LastEnforcementMessageDesc,StatusType,StatusTime FROM SMS_SUMDeploymentAssetDetails WHERE AssignmentID = $AssignmentID" `
                    -OperationTimeoutSec 90 -ErrorAction Stop)
                if ($assets.Count -gt 0) { $usedProvider = $providerMachine; break }
            } catch {
                Write-Log $LogPath "SMS Provider enrichment candidate '$candidate' failed: $($_.Exception.Message)" 'WARN'
            }
        }

        if ($null -eq $assets -or $assets.Count -eq 0) { throw 'SMS_SUMDeploymentAssetDetails returned no records from the discovered provider candidates.' }
        Write-Log $LogPath "Top-error enrichment restored from SMS Provider '$usedProvider': $($assets.Count) asset records."

        $map = @{}
        foreach ($a in $assets) { $map[[string]$a.DeviceName] = $a }
        foreach ($row in $Rows) {
            if (-not $map.ContainsKey([string]$row.Device)) { continue }
            $a = $map[[string]$row.Device]
            if ($a.ResourceID) { $row.ResourceID = [int]$a.ResourceID }
            $code = [UInt64]0
            if ([UInt64]$a.StatusErrorCode -ne 0) { $code = [UInt64]$a.StatusErrorCode }
            elseif ([UInt64]$a.LastEnforcementErrorCode -ne 0) { $code = [UInt64]$a.LastEnforcementErrorCode }

            if ($row.DeploymentStatus -eq 'Error' -and $code -ne 0) {
                $row.ErrorCode = Get-ErrorHex $code
                $row.ErrorDetail = Get-ErrorDetail -Code $code `
                    -LastEnforcementMessage ([string]$a.LastEnforcementMessageDesc) `
                    -StatusDescription ([string]$a.StatusDescription)
                $row.RecommendedActions = Get-ErrorRecommendations -Code $code
            }
        }


        # Preferred Distribution Points: restore the v2.8 provider-side logic.
        # This is NOT a connection to endpoints. All calls below target only the SMS Provider.
        try {
            function Get-ShortDpName([string]$value) {
                if ([string]::IsNullOrWhiteSpace($value)) { return '' }
                $v = $value.Trim()
                if ($v -match '\\\\([^\\\]\[]+)') { $v = $matches[1] }
                elseif ($v -match '^([^\\/]+)$') { $v = $matches[1] }
                $v = ($v -replace '^[\\/\[\]"]+|[\\/\[\]"]+$','')
                if ($v -match '^([^\.]+)\.') { $v = $matches[1] }
                return $v.Trim()
            }

            $resourceIds = @($assets | ForEach-Object { [int]$_.ResourceID } | Where-Object { $_ -gt 0 } | Sort-Object -Unique)
            $resourceMap = @{}
            $batchSize = 200
            for ($i=0; $i -lt $resourceIds.Count; $i += $batchSize) {
                $end = [Math]::Min($i + $batchSize - 1, $resourceIds.Count - 1)
                $ids = ($resourceIds[$i..$end] -join ',')
                $resources = @(Get-CimInstance -ComputerName $usedProvider -Namespace "root\SMS\site_$siteCode" `
                    -Query "SELECT * FROM SMS_CombinedDeviceResources WHERE ResourceID IN ($ids)" -OperationTimeoutSec 120 -ErrorAction Stop)
                foreach ($r in $resources) { $resourceMap[[int]$r.ResourceID] = $r }
            }

            $bgNameToId = @{}
            $groups = @(Get-CimInstance -ComputerName $usedProvider -Namespace "root\SMS\site_$siteCode" `
                -Query 'SELECT GroupID,Name FROM SMS_BoundaryGroup' -OperationTimeoutSec 120 -ErrorAction Stop)
            foreach ($g in $groups) { if ($g.Name) { $bgNameToId[[string]$g.Name] = [int]$g.GroupID } }

            $dpNames = @{}
            $dps = @(Get-CimInstance -ComputerName $usedProvider -Namespace "root\SMS\site_$siteCode" `
                -Query 'SELECT * FROM SMS_DistributionPointInfo' -OperationTimeoutSec 120 -ErrorAction Stop)
            foreach ($dp in $dps) {
                $candidate = [string](Get-ResourcePropertyValue $dp @('ServerName','Name','NALPath'))
                $short = Get-ShortDpName $candidate
                if ($short) { $dpNames[$short.ToLowerInvariant()] = $true }
            }

            $bgDpMap = @{}
            $systems = @(Get-CimInstance -ComputerName $usedProvider -Namespace "root\SMS\site_$siteCode" `
                -Query 'SELECT GroupID,ServerNALPath,SiteCode FROM SMS_BoundaryGroupSiteSystems' -OperationTimeoutSec 120 -ErrorAction Stop)
            foreach ($ss in $systems) {
                $short = Get-ShortDpName ([string]$ss.ServerNALPath)
                if (-not $short) { continue }
                if ($dpNames.Count -gt 0 -and -not $dpNames.ContainsKey($short.ToLowerInvariant())) { continue }
                $gid=[int]$ss.GroupID
                if (-not $bgDpMap.ContainsKey($gid)) { $bgDpMap[$gid]=New-Object System.Collections.Generic.List[string] }
                if (-not $bgDpMap[$gid].Contains($short)) { $bgDpMap[$gid].Add($short) }
            }

            foreach ($row in $Rows) {
                if (-not $map.ContainsKey([string]$row.Device)) { continue }
                $rid=[int]$map[[string]$row.Device].ResourceID
                if (-not $resourceMap.ContainsKey($rid)) { continue }
                $res=$resourceMap[$rid]
                $raw=Get-ResourcePropertyValue $res @('BoundaryGroupNames','BoundaryGroups','BoundaryGroupName','BoundaryGroup')
                $names=New-Object System.Collections.Generic.List[string]
                if ($raw -is [System.Array]) { foreach($n in $raw){ if($n){$names.Add([string]$n)} } }
                elseif ($null -ne $raw) { foreach($n in ([string]$raw -split '[;,]')){ if(-not [string]::IsNullOrWhiteSpace($n)){$names.Add($n.Trim())} } }
                $found=New-Object System.Collections.Generic.List[string]
                foreach($n in $names){
                    if($bgNameToId.ContainsKey($n)){
                        $gid=[int]$bgNameToId[$n]
                        if($bgDpMap.ContainsKey($gid)){ foreach($dpn in @($bgDpMap[$gid])){ if(-not $found.Contains($dpn)){$found.Add($dpn)} } }
                    }
                }
                if($found.Count -gt 0){ $row.PreferredDistributionPoints = (($found | Sort-Object) -join '; ') }
                $row.ResourceID = $rid
            }
            Write-Log $LogPath ("Preferred DP enrichment completed via SMS Provider only: {0} devices received DP data." -f @($Rows | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_.PreferredDistributionPoints) }).Count)
        }
        catch {
            Write-Log $LogPath "Preferred DP enrichment unavailable; patch report continues without DP. $($_.Exception.Message)" 'WARN'
        }
    }
    catch {
        Write-Log $LogPath "SMS Provider error enrichment unavailable; SQL LastEnforcementErrorCode fallback will be used. $($_.Exception.Message)" 'WARN'
    }
    return $Rows
}

function Add-DomainTrustHealth {
    <#
        Adds a separate domain-trust health signal without altering patch status.
        AD is used to validate computer-account existence/disabled state. The actual
        secure-channel test is executed remotely with Test-ComputerSecureChannel.
        A remote transport/auth failure is reported as Unverified, never as Broken.
    #>
    param(
        [Parameter(Mandatory)][object[]]$Rows,
        [Parameter(Mandatory)][string]$LogPath,
        [int]$ThrottleLimit = 24,
        [int]$OpenTimeoutMs = 3500,
        [int]$OperationTimeoutMs = 7000
    )
    if ($script:EndpointRealtimeBlocked) { Write-Log $LogPath 'Domain Trust skipped: server-side mode blocks endpoint connections.' 'WARN'; return $Rows }

    foreach ($r in $Rows) {
        Add-Member -InputObject $r -NotePropertyName DomainTrustStatus -NotePropertyValue 'Not tested' -Force
        Add-Member -InputObject $r -NotePropertyName DomainTrustDetail -NotePropertyValue '' -Force
        Add-Member -InputObject $r -NotePropertyName ADComputerStatus -NotePropertyValue 'Unknown' -Force
    }

    # AD account validation via LDAP; no ActiveDirectory PowerShell module required.
    $adMap = @{}
    try {
        $rootDse = [ADSI]'LDAP://RootDSE'
        $base = [ADSI]("LDAP://" + [string]$rootDse.defaultNamingContext)
        $searcher = New-Object System.DirectoryServices.DirectorySearcher($base)
        $searcher.PageSize = 1000
        foreach ($prop in @('samaccountname','useraccountcontrol','dnshostname')) { [void]$searcher.PropertiesToLoad.Add($prop) }
        $names = @($Rows | ForEach-Object { [string]$_.Device } | Where-Object { $_ } | Sort-Object -Unique)
        for ($i=0; $i -lt $names.Count; $i += 80) {
            $end = [Math]::Min($i+79,$names.Count-1)
            $parts = foreach ($n in $names[$i..$end]) {
                $esc = $n.Replace('\','\5c').Replace('*','\2a').Replace('(','\28').Replace(')','\29')
                "(sAMAccountName=$esc`$)"
            }
            $searcher.Filter = "(&(objectCategory=computer)(|$($parts -join '')))"
            foreach ($res in @($searcher.FindAll())) {
                $sam = [string]$res.Properties['samaccountname'][0]
                $name = $sam.TrimEnd('$')
                $uac = 0
                if ($res.Properties['useraccountcontrol'].Count -gt 0) { $uac = [int]$res.Properties['useraccountcontrol'][0] }
                $adMap[$name.ToUpperInvariant()] = [pscustomobject]@{ Disabled=(($uac -band 2) -ne 0); DnsHostName=([string]$res.Properties['dnshostname'][0]) }
            }
        }
    } catch {
        Write-Log $LogPath "AD computer-account lookup unavailable: $($_.Exception.Message)" 'WARN'
    }

    foreach ($r in $Rows) {
        $key = ([string]$r.Device).ToUpperInvariant()
        if ($adMap.Count -gt 0) {
            if (-not $adMap.ContainsKey($key)) {
                $r.ADComputerStatus = 'Missing'
                $r.DomainTrustStatus = 'AD issue'
                $r.DomainTrustDetail = 'Computer account was not found in Active Directory.'
            } elseif ($adMap[$key].Disabled) {
                $r.ADComputerStatus = 'Disabled'
                $r.DomainTrustStatus = 'AD issue'
                $r.DomainTrustDetail = 'Computer account is disabled in Active Directory.'
            } else {
                $r.ADComputerStatus = 'Enabled'
            }
        }
    }

    $targets = @($Rows | Where-Object { $_.DomainTrustStatus -notin @('AD issue') -and -not [string]::IsNullOrWhiteSpace([string]$_.Device) } | Select-Object -ExpandProperty Device -Unique)
    if ($targets.Count -eq 0) { return $Rows }

    try {
        $sessionOption = New-PSSessionOption -OpenTimeout $OpenTimeoutMs -OperationTimeout $OperationTimeoutMs -CancelTimeout 2000
        $errs = @()
        $results = @(Invoke-Command -ComputerName $targets -ThrottleLimit $ThrottleLimit -SessionOption $sessionOption `
            -ScriptBlock {
                try {
                    [pscustomobject]@{ Computer=$env:COMPUTERNAME; SecureChannel=[bool](Test-ComputerSecureChannel -ErrorAction Stop); Detail='' }
                } catch {
                    [pscustomobject]@{ Computer=$env:COMPUTERNAME; SecureChannel=$null; Detail=$_.Exception.Message }
                }
            } -ErrorAction SilentlyContinue -ErrorVariable +errs)

        $resultMap = @{}
        foreach ($x in $results) { if ($x.Computer) { $resultMap[[string]$x.Computer.ToUpperInvariant()] = $x } }
        foreach ($r in $Rows) {
            if ($r.DomainTrustStatus -eq 'AD issue') { continue }
            $key = ([string]$r.Device).ToUpperInvariant()
            if ($resultMap.ContainsKey($key)) {
                $x = $resultMap[$key]
                if ($null -eq $x.SecureChannel) {
                    $r.DomainTrustStatus = 'Unverified'
                    $r.DomainTrustDetail = [string]$x.Detail
                } elseif ([bool]$x.SecureChannel) {
                    $r.DomainTrustStatus = 'Healthy'
                    $r.DomainTrustDetail = 'Secure channel with the domain verified successfully.'
                } else {
                    $r.DomainTrustStatus = 'Broken'
                    $r.DomainTrustDetail = 'Test-ComputerSecureChannel returned False.'
                }
            } else {
                $r.DomainTrustStatus = 'Unverified'
                $r.DomainTrustDetail = 'Remote secure-channel test could not be executed (offline, WinRM unavailable, firewall, or authentication failure).'
            }
        }
        Write-Log $LogPath "Domain trust health completed: Healthy=$(@($Rows|? DomainTrustStatus -eq 'Healthy').Count), Broken=$(@($Rows|? DomainTrustStatus -eq 'Broken').Count), ADIssue=$(@($Rows|? DomainTrustStatus -eq 'AD issue').Count), Unverified=$(@($Rows|? DomainTrustStatus -eq 'Unverified').Count)."
    } catch {
        Write-Log $LogPath "Domain secure-channel verification unavailable: $($_.Exception.Message)" 'WARN'
        foreach ($r in $Rows) {
            if ($r.DomainTrustStatus -notin @('AD issue')) {
                $r.DomainTrustStatus = 'Unverified'
                $r.DomainTrustDetail = 'Remote secure-channel verification was unavailable from the report runner.'
            }
        }
    }
    return $Rows
}

# ================================================================
# ETAPA 2 - historico diario em ARQUIVO JSON LOCAL (nao no SQL de
# producao). O script so faz SELECT no banco do SCCM; nenhuma
# escrita, nenhum CREATE/INSERT/MERGE la. Todo estado de histórico
# fica isolado num arquivo ao lado do script, na maquina de automacao.
# ================================================================

function Import-CycleHistory {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    $raw = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    if ([string]::IsNullOrWhiteSpace($raw)) { return @() }
    return @($raw | ConvertFrom-Json)
}

function Export-CycleHistory {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][object[]]$Records
    )
    $sorted = $Records | Sort-Object CycleLabel, DayNumber
    $sorted | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $Path -Encoding UTF8
}

function Save-CycleSnapshot {
    <#
        Grava (ou atualiza) a linha do dia corrente no arquivo JSON de
        historico (ETAPA 2). Nao toca em nada no SQL Server.
    #>
    param(
        [Parameter(Mandatory)][string]$HistoryPath,
        [Parameter(Mandatory)][string]$CycleLabel,
        [Parameter(Mandatory)][int]$DayNumber,
        [Parameter(Mandatory)][datetime]$CalendarDate,
        [Parameter(Mandatory)][int]$PopulationTotal,
        [Parameter(Mandatory)][int]$CorrectedCount,
        [Parameter(Mandatory)][string]$LogPath
    )

    $percent = if ($PopulationTotal -gt 0) { [math]::Round(($CorrectedCount / $PopulationTotal) * 100, 2) } else { 0 }

    try {
        $history = [System.Collections.Generic.List[object]](Import-CycleHistory -Path $HistoryPath)
        $existing = $history | Where-Object { $_.CycleLabel -eq $CycleLabel -and $_.DayNumber -eq $DayNumber } | Select-Object -First 1

        $record = [pscustomobject]@{
            CycleLabel       = $CycleLabel
            DayNumber        = $DayNumber
            CalendarDate     = $CalendarDate.ToString('yyyy-MM-dd')
            PopulationTotal  = $PopulationTotal
            CorrectedCount   = $CorrectedCount
            PercentCompliant = $percent
            IsSeedData       = $false
        }

        if ($existing) {
            $newHistory = New-Object System.Collections.Generic.List[object]
            foreach ($item in $history) {
                if ($item.CycleLabel -eq $CycleLabel -and $item.DayNumber -eq $DayNumber) {
                    $newHistory.Add($record)
                } else {
                    $newHistory.Add($item)
                }
            }
            $history = $newHistory
        } else {
            $history.Add($record)
        }

        Export-CycleHistory -Path $HistoryPath -Records $history.ToArray()
        Write-Log $LogPath "Snapshot gravado no JSON: ciclo $CycleLabel, dia $DayNumber ($($CalendarDate.ToString('yyyy-MM-dd'))), $CorrectedCount/$PopulationTotal ($percent%)."
    }
    catch {
        Write-Log $LogPath "Falha ao gravar snapshot no historico JSON (nao interrompe a geracao do dashboard): $($_.Exception.Message)" 'WARN'
    }

    return $percent
}

function Get-PreviousCycleLabel {
    param([string]$CycleLabel)  # 'YYYY-MM'
    $dt = [datetime]::ParseExact($CycleLabel + '-01', 'yyyy-MM-dd', $null)
    $prev = $dt.AddMonths(-1)
    return $prev.ToString('yyyy-MM')
}

function ConvertTo-ScalarDouble {
    <# Protege contra valores vindos do JSON como array/duplicados em vez de numero unico. #>
    param($Value)
    if ($null -eq $Value) { return $null }
    if ($Value -is [array]) {
        if ($Value.Count -eq 0) { return $null }
        $Value = $Value[0]
    }
    try { return [double]$Value } catch { return $null }
}

function Get-CycleFooterHtml {
    <#
        Monta o HTML do rodape (tabela dia-a-dia, resumo semanal,
        fechamento do ciclo) lendo o histórico direto do JSON local -
        nenhuma consulta ao SQL Server aqui.
    #>
    param(
        [Parameter(Mandatory)][string]$HistoryPath,
        [Parameter(Mandatory)][string]$CycleLabel,
        [Parameter(Mandatory)][string]$LogPath
    )

    try {
        $prevLabel = Get-PreviousCycleLabel -CycleLabel $CycleLabel
        $history = Import-CycleHistory -Path $HistoryPath

        $curRows  = @($history | Where-Object CycleLabel -eq $CycleLabel)
        $prevRows = @($history | Where-Object CycleLabel -eq $prevLabel)

        if ($curRows.Count -eq 0) {
            Write-Log $LogPath "Sem linhas de historico (JSON) para o ciclo $CycleLabel; rodape comparativo nao sera exibido hoje." 'WARN'
            return ''
        }

        $prevByDay = @{}
        foreach ($p in $prevRows) { $prevByDay[[int]$p.DayNumber] = $p }

        # Se houver linhas duplicadas para o mesmo DayNumber (ex.: JSON antigo com
        # lixo de execucao anterior), fica so com a ULTIMA por dia.
        $curByDay = [ordered]@{}
        foreach ($c in $curRows) { $curByDay[[int]$c.DayNumber] = $c }

        $days = $curByDay.Keys | Sort-Object { [int]$_ } | ForEach-Object {
            $cur = $curByDay[$_]
            $prev = $prevByDay[[int]$cur.DayNumber]
            $curPercentD  = ConvertTo-ScalarDouble $cur.PercentCompliant
            $prevPercentD = if ($prev) { ConvertTo-ScalarDouble $prev.PercentCompliant } else { $null }
            $delta = if ($null -ne $curPercentD -and $null -ne $prevPercentD) {
                [math]::Round($curPercentD - $prevPercentD, 2)
            } else { $null }

            [pscustomobject]@{
                DayNumber       = [int]$cur.DayNumber
                CalendarDate    = $cur.CalendarDate
                CurrentPercent  = $curPercentD
                PreviousPercent = $prevPercentD
                DeltaPercent    = $delta
            }
        }
        $days = @($days)

        $rowsHtml = ($days | ForEach-Object {
            $curPct  = if ($null -ne $_.CurrentPercent)  { '{0:N2}%' -f [double]$_.CurrentPercent }  else { '-' }
            $prevPct = if ($null -ne $_.PreviousPercent) { '{0:N2}%' -f [double]$_.PreviousPercent } else { '-' }
            $delta   = if ($null -ne $_.DeltaPercent) {
                $d = [double]$_.DeltaPercent
                $cls = if ($d -gt 0) { 'deltaPos' } elseif ($d -lt 0) { 'deltaNeg' } else { 'deltaFlat' }
                $sign = if ($d -gt 0) { '+' } else { '' }
                "<span class='$cls'>$sign$([math]::Round($d,2))%</span>"
            } else { '-' }
            $curDate = if ($_.CalendarDate) { try { ([datetime]$_.CalendarDate).ToString('dd/MM') } catch { '' } } else { '' }
            "<tr><td>Dia $($_.DayNumber)</td><td>$curDate</td><td>$curPct</td><td>$prevPct</td><td>$delta</td></tr>"
        }) -join "`n"

        $withData     = @($days | Where-Object { $null -ne $_.CurrentPercent })
        $lastWithData = if ($withData.Count -gt 0) { $withData[$withData.Count - 1] } else { $null }
        $weekSlice    = if ($withData.Count -gt 0) { $withData | Select-Object -Last 7 } else { @() }
        $weekSlice    = @($weekSlice)
        $firstOfWeek  = if ($weekSlice.Count -gt 0) { $weekSlice[0] } else { $null }

        $weeklyGain = if ($lastWithData -and $firstOfWeek -and $lastWithData.DayNumber -ne $firstOfWeek.DayNumber) {
            '{0:N2}%' -f ([double]$lastWithData.CurrentPercent - [double]$firstOfWeek.CurrentPercent)
        } else { 'N/A' }

        $day31Match = @($days | Where-Object { $_.DayNumber -eq 31 })
        $day31 = if ($day31Match.Count -gt 0) { $day31Match[0] } else { $null }

        $cycleEndSummary = if ($day31 -and $null -ne $day31.CurrentPercent) {
            "Fechamento do ciclo (dia 31): <strong>{0:N2}%</strong>" -f [double]$day31.CurrentPercent
        } elseif ($lastWithData) {
            "Ciclo em andamento - ultimo dia com dado: <strong>{0:N2}%</strong> (Dia $($lastWithData.DayNumber))" -f [double]$lastWithData.CurrentPercent
        } else { "Ciclo em andamento - sem dado ainda." }

        $overallDelta = if ($day31 -and $null -ne $day31.DeltaPercent) {
            "Ganho/perda total no fechamento vs ciclo anterior: <strong>{0:+0.00;-0.00;0.00}%</strong>" -f [double]$day31.DeltaPercent
        } elseif ($lastWithData -and $null -ne $lastWithData.DeltaPercent) {
            "Ganho/perda ate agora vs mesmo dia do ciclo anterior: <strong>{0:+0.00;-0.00;0.00}%</strong>" -f [double]$lastWithData.DeltaPercent
        } else { '' }

        return @"
<section class="panel cycle-footer">
  <h2 style="margin-top:0">Comparativo do ciclo - $CycleLabel vs $prevLabel</h2>
  <div class="note">Ganho da semana (ultimos 7 dias com dado): <strong>$weeklyGain</strong> &nbsp;|&nbsp; $cycleEndSummary &nbsp;|&nbsp; $overallDelta</div>
  <table class="cycle-footer-table" style="width:100%;border-collapse:collapse;margin-top:10px;font-size:13px;">
    <thead>
      <tr style="text-align:left;border-bottom:2px solid #d8e1eb;">
        <th style="padding:6px">Dia do ciclo</th><th style="padding:6px">Data</th>
        <th style="padding:6px">% $CycleLabel</th><th style="padding:6px">% $prevLabel</th><th style="padding:6px">Delta</th>
      </tr>
    </thead>
    <tbody>
$rowsHtml
    </tbody>
  </table>
</section>
<style>
.deltaPos{color:#1f9d55;font-weight:600}
.deltaNeg{color:#d64545;font-weight:600}
.deltaFlat{color:#7b8794;font-weight:600}
.cycle-footer-table tbody tr:nth-child(even){background:#f7fafc}
</style>
"@
    }
    catch {
        Write-Log $LogPath "Falha ao montar o rodape comparativo (nao interrompe a geracao do dashboard): $($_.Exception.Message) | Linha interna: $($_.InvocationInfo.ScriptLineNumber)" 'WARN'
        return ''
    }
}



# ================================================================
# WAR ROOM CHECKPOINT HISTORY - isolated from PatchCycleHistory.json
# Preserves every dashboard execution so same-day checkpoints can be compared.
# It never modifies the SCCM result set and never writes to SCCM/SQL.
# ================================================================
function New-WarRoomCheckpointSummary {
    param(
        [Parameter(Mandatory)][object[]]$Rows,
        [Parameter(Mandatory)][string]$CheckpointHistoryPath,
        [Parameter(Mandatory)][string]$CycleLabel,
        [Parameter(Mandatory)][int]$CycleDayNumber,
        [string]$IncidentCommander = '',
        [string]$NextCheckpoint = '',
        [string]$NetworkEnforcementDeadline = '',
        [int]$ManualRemediation = 0,
        [int]$PendingExceptions = 0,
        [int]$ApprovedExceptions = 0,
        [string]$MajorProgressAchieved = '',
        [string]$NewIssuesIdentified = '',
        [int]$InactiveProxyCount = 0,
        [int]$InactiveProxyDays = 30,
        [Parameter(Mandatory)][string]$LogPath
    )

    $now = Get-Date
    $total = @($Rows).Count
    $patched = @($Rows | Where-Object { [string]$_.ComplianceBucket -eq 'Compliant' }).Count
    $remaining = [math]::Max(0, $total - $patched)
    $failed = @($Rows | Where-Object { [string]$_.DeploymentStatus -eq 'Error' -and [string]$_.ComplianceBucket -ne 'Compliant' }).Count
    $compliancePct = if ($total -gt 0) { [math]::Round(($patched / $total) * 100, 2) } else { 0 }
    $enforcementCandidates = [math]::Max(0, $remaining - [math]::Max(0,$ApprovedExceptions))

    $history = @()
    if (Test-Path -LiteralPath $CheckpointHistoryPath) {
        try {
            $raw = Get-Content -LiteralPath $CheckpointHistoryPath -Raw -Encoding UTF8
            if (-not [string]::IsNullOrWhiteSpace($raw)) { $history = @($raw | ConvertFrom-Json) }
        } catch {
            Write-Log $LogPath "War Room checkpoint history could not be read; starting a new in-memory list: $($_.Exception.Message)" 'WARN'
            $history = @()
        }
    }

    $previous = @($history | Where-Object { [string]$_.CycleLabel -eq $CycleLabel } | Sort-Object { try { [datetime]$_.Generated } catch { [datetime]::MinValue } } | Select-Object -Last 1)
    $previous = if ($previous.Count -gt 0) { $previous[0] } else { $null }
    $previousPatched = if ($previous) { [int]$previous.SuccessfullyPatched } else { $null }
    $previousPct = if ($previous) { [double]$previous.CompliancePct } else { $null }
    $patchedSince = if ($previous) { $patched - $previousPatched } else { $null }
    $netImprovement = if ($previous) { [math]::Round($compliancePct - $previousPct, 2) } else { $null }

    $deadline = $null
    if (-not [string]::IsNullOrWhiteSpace($NetworkEnforcementDeadline)) {
        try { $deadline = [datetime]::Parse($NetworkEnforcementDeadline) } catch { $deadline = $null }
    }

    $overallStatus = 'IN PROGRESS'
    $onTrack = 'IN PROGRESS'
    $statusReason = 'Patching is still in progress.'
    if ($remaining -eq 0) {
        $overallStatus = 'GREEN'
        $onTrack = 'YES'
        $statusReason = 'All devices in scope are compliant.'
    } elseif ($deadline -and $now -gt $deadline) {
        $overallStatus = 'RED'
        $onTrack = 'NO'
        $statusReason = 'Enforcement deadline has passed with devices still unpatched.'
    } elseif ($failed -gt 0) {
        $overallStatus = 'AMBER'
        $onTrack = 'AT RISK'
        $statusReason = 'One or more devices are currently reporting patch errors.'
    }

    $record = [pscustomobject]@{
        Generated            = $now.ToString('yyyy-MM-dd HH:mm:ss')
        CycleLabel           = $CycleLabel
        CycleDayNumber       = $CycleDayNumber
        TotalDevices         = $total
        SuccessfullyPatched  = $patched
        CompliancePct        = $compliancePct
        RemainingUnpatched   = $remaining
        FailedPatches        = $failed
    }

    try {
        $newHistory = @($history) + @($record)
        # Keep a bounded audit trail. Multiple runs on the same day are intentionally preserved.
        $newHistory = @($newHistory | Sort-Object { try { [datetime]$_.Generated } catch { [datetime]::MinValue } } | Select-Object -Last 500)
        if (Test-Path -LiteralPath $CheckpointHistoryPath) {
            Copy-Item -LiteralPath $CheckpointHistoryPath -Destination ($CheckpointHistoryPath + '.bak') -Force -ErrorAction SilentlyContinue
        }
        ConvertTo-Json -InputObject $newHistory -Depth 5 | Set-Content -LiteralPath $CheckpointHistoryPath -Encoding UTF8
        Write-Log $LogPath ("War Room checkpoint saved: {0}/{1} compliant ({2}%), previous checkpoint delta devices={3}, delta pct={4}." -f $patched,$total,$compliancePct,$patchedSince,$netImprovement)
    } catch {
        Write-Log $LogPath "War Room checkpoint could not be persisted; summary continues in memory: $($_.Exception.Message)" 'WARN'
    }

    return [pscustomobject]@{
        EventName                    = 'Zero-Day Patching Event'
        EventDate                    = $now.ToString('dd-MMM')
        IncidentCommander            = $IncidentCommander
        CheckpointTime               = $now.ToString('h:mm tt')
        NextCheckpoint               = $NextCheckpoint
        NetworkEnforcementDeadline   = if ($deadline) { $deadline.ToString('dddd, MMMM d, yyyy - h:mm tt') } else { $NetworkEnforcementDeadline }
        OverallStatus                = $overallStatus
        OnTrack                      = $onTrack
        StatusReason                 = $statusReason
        DataAsOf                     = $now.ToString('yyyy-MM-dd HH:mm:ss')
        DataSources                  = 'Configuration Manager SQL + SMS Provider'
        CycleLabel                   = $CycleLabel
        CycleDayNumber               = $CycleDayNumber
        TotalDevices                 = $total
        SuccessfullyPatched          = $patched
        CompliancePct                = $compliancePct
        PreviousSuccessfullyPatched  = $previousPatched
        PreviousCompliancePct        = $previousPct
        RemainingUnpatched           = $remaining
        FailedPatches                = $failed
        OfflineUnreachableProxy      = [math]::Max(0,$InactiveProxyCount)
        OfflineProxyDays             = $InactiveProxyDays
        ManualRemediation            = [math]::Max(0,$ManualRemediation)
        PendingExceptions            = [math]::Max(0,$PendingExceptions)
        ApprovedExceptions           = [math]::Max(0,$ApprovedExceptions)
        EnforcementCandidates        = $enforcementCandidates
        DevicesPatchedSinceLast      = $patchedSince
        NetComplianceImprovement     = $netImprovement
        MajorProgressAchieved        = $MajorProgressAchieved
        NewIssuesIdentified          = $NewIssuesIdentified
    }
}

# ================================================================
# ENDPOINT HEALTH - camada paralela ao Patch Report
# Nao altera a query de compliance, AssignmentID nem os 4 buckets.
# ================================================================
function Get-EndpointHealthData {
    <#
        SERVER-SIDE ONLY. Reads Configuration Manager SQL inventory/status data.
        No Test-Connection, WinRM, CIM/WMI, RPC, Remote Registry or other
        connection to individual endpoints is performed by this function.
    #>
    param(
        [Parameter(Mandatory)][string]$SqlServer,
        [Parameter(Mandatory)][string]$Database,
        [Parameter(Mandatory)][string]$CollectionID,
        [int]$DiskWarningPercent = 15,
        [int]$DiskCriticalPercent = 5,
        [int]$InactiveDays = 30,
        [Parameter(Mandatory)][string]$LogPath
    )

    if ($CollectionID -notmatch '^[A-Za-z0-9]{3,16}$') { throw "CollectionID invalido para Endpoint Health: '$CollectionID'." }
    if ($DiskCriticalPercent -lt 1 -or $DiskCriticalPercent -gt 50) { throw 'DiskCriticalPercent fora do intervalo esperado.' }
    if ($DiskWarningPercent -le $DiskCriticalPercent -or $DiskWarningPercent -gt 80) { throw 'DiskWarningPercent deve ser maior que Critical e <= 80.' }
    if ($InactiveDays -lt 1 -or $InactiveDays -gt 3650) { throw 'InactiveDays fora do intervalo esperado.' }

    $connStr = New-SqlConnectionString -Server $SqlServer -Database $Database
    $sql = @"
;WITH Members AS (
    SELECT DISTINCT ResourceID
    FROM v_FullCollectionMembership
    WHERE CollectionID = '$CollectionID'
),
DiskC AS (
    SELECT ResourceID,
           MAX(FreeSpace0) AS FreeSpaceMB,
           MAX(Size0)      AS SizeMB
    FROM v_GS_LOGICAL_DISK
    WHERE DeviceID0 = 'C:'
    GROUP BY ResourceID
)
SELECT
    rs.ResourceID,
    rs.Name0 AS Device,
    rs.Client0 AS ClientInstalled,
    ch.ClientActiveStatus,
    ch.LastActiveTime,
    cdr.ClientCheckPass AS ClientCheckPassRaw,
    dc.FreeSpaceMB,
    dc.SizeMB
FROM Members m
JOIN v_R_System rs ON rs.ResourceID = m.ResourceID
LEFT JOIN v_CH_ClientSummary ch ON ch.ResourceID = m.ResourceID
LEFT JOIN v_CombinedDeviceResources cdr ON cdr.MachineID = m.ResourceID
LEFT JOIN DiskC dc ON dc.ResourceID = m.ResourceID
ORDER BY rs.Name0;
"@

    Write-Log $LogPath "Endpoint Health: SQL/SCCM-only query started for collection $CollectionID. NO endpoint connections."
    $ds = Get-SqlDataSet -ConnectionString $connStr -Query $sql -TimeoutSeconds 180
    if ($ds.Tables.Count -lt 1) { throw 'Endpoint Health nao retornou result set.' }
    $rawRows = @(ConvertFrom-DataTable -Table $ds.Tables[0])
    $cutoff = (Get-Date).AddDays(-$InactiveDays)

    $all = New-Object System.Collections.Generic.List[object]
    foreach ($r in $rawRows) {
        $clientInstalledRaw = if ($r.ClientInstalled -eq [DBNull]::Value) { $null } else { $r.ClientInstalled }
        $clientActiveRaw = if ($r.ClientActiveStatus -eq [DBNull]::Value) { $null } else { $r.ClientActiveStatus }
        $clientCheckRaw = if ($r.ClientCheckPassRaw -eq [DBNull]::Value) { $null } else { $r.ClientCheckPassRaw }
        $lastActive = if ($r.LastActiveTime -eq [DBNull]::Value) { $null } else { [datetime]$r.LastActiveTime }
        $freeMB = if ($r.FreeSpaceMB -eq [DBNull]::Value) { $null } else { [double]$r.FreeSpaceMB }
        $sizeMB = if ($r.SizeMB -eq [DBNull]::Value) { $null } else { [double]$r.SizeMB }

        $clientStatus = Get-ClientStatusLabel $clientActiveRaw $clientInstalledRaw
        $clientCheck = Get-ClientCheckResultLabel $clientCheckRaw $null
        $freeGB = if ($null -ne $freeMB) { [math]::Round($freeMB / 1024, 2) } else { $null }
        $sizeGB = if ($null -ne $sizeMB) { [math]::Round($sizeMB / 1024, 2) } else { $null }
        $freePct = if ($null -ne $freeMB -and $null -ne $sizeMB -and $sizeMB -gt 0) { [math]::Round(($freeMB / $sizeMB) * 100, 1) } else { $null }
        $daysInactive = if ($null -ne $lastActive) { [math]::Floor(((Get-Date) - $lastActive).TotalDays) } else { $null }

        $diskStatus = 'Unknown'
        if ($null -ne $freePct) {
            if ($freePct -le $DiskCriticalPercent) { $diskStatus = 'Critical' }
            elseif ($freePct -le $DiskWarningPercent) { $diskStatus = 'Warning' }
            else { $diskStatus = 'Healthy' }
        }

        $all.Add([pscustomobject]@{
            ResourceID          = [int]$r.ResourceID
            Device              = [string]$r.Device
            ClientStatus        = $clientStatus
            ClientCheckResult   = $clientCheck
            LastActivity        = $lastActive
            DaysInactive        = $daysInactive
            FreeCGB             = $freeGB
            TotalCGB            = $sizeGB
            FreeCPct            = $freePct
            DiskStatus          = $diskStatus
            IsClientCheckFailed = ($clientCheck -eq 'Failed')
            IsInactive          = ($clientStatus -eq 'Inactive' -and $null -ne $lastActive -and $lastActive -lt $cutoff)
        })
    }

    $rows = $all.ToArray()
    $diskWarning = @($rows | Where-Object DiskStatus -eq 'Warning')
    $diskCritical = @($rows | Where-Object DiskStatus -eq 'Critical')
    $failed = @($rows | Where-Object IsClientCheckFailed)
    $inactive = @($rows | Where-Object IsInactive)

    [pscustomobject]@{
        TotalDevices            = $rows.Count
        DiskWarningPercent      = $DiskWarningPercent
        DiskCriticalPercent     = $DiskCriticalPercent
        InactiveDays            = $InactiveDays
        DiskWarningCount        = $diskWarning.Count
        DiskCriticalCount       = $diskCritical.Count
        ClientCheckFailedCount  = $failed.Count
        InactiveCount           = $inactive.Count
        DiskWarningRows         = $diskWarning
        DiskCriticalRows        = $diskCritical
        ClientCheckFailedRows   = $failed
        InactiveRows            = $inactive
    }
}

function New-EndpointHealthArtifacts {
    param(
        [Parameter(Mandatory)]$EndpointHealth,
        [Parameter(Mandatory)][string]$ReportFolder,
        [Parameter(Mandatory)][hashtable]$Meta
    )

    function EH-Pct([int]$n,[int]$t) { if ($t -le 0) { return 0 } return [math]::Round(($n/$t)*100,2) }
    function EH-Date($d) { if ($null -eq $d -or [string]::IsNullOrWhiteSpace([string]$d)) { return '' }; try { return ([datetime]$d).ToString('yyyy-MM-dd HH:mm') } catch { return [string]$d } }
    function EH-Num($n) { if ($null -eq $n) { return '' } return [string]$n }

    $total = [int]$EndpointHealth.TotalDevices

    # One disk detail report containing both severities and an explicit status filter.
    $diskRows = @($EndpointHealth.DiskCriticalRows) + @($EndpointHealth.DiskWarningRows)
    $diskTableRows = foreach ($r in $diskRows) {
        $badgeClass = if ($r.DiskStatus -eq 'Critical') { 'critical' } else { 'warning' }
        "<tr data-diskstatus='$(ConvertTo-HtmlSafe $r.DiskStatus)'><td>$(ConvertTo-HtmlSafe $r.Device)</td><td><span class='badge $badgeClass'>$(ConvertTo-HtmlSafe $r.DiskStatus)</span></td><td>$(ConvertTo-HtmlSafe (EH-Num $r.FreeCPct))%</td><td>$(ConvertTo-HtmlSafe (EH-Num $r.FreeCGB)) GB</td><td>$(ConvertTo-HtmlSafe (EH-Num $r.TotalCGB)) GB</td><td>Run disk cleanup/remediation.</td></tr>"
    }
    $diskAffected = $diskRows.Count
    $diskPct = EH-Pct $diskAffected $total
    $diskHtml = @"
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Disk Space Health</title>
<style>:root{--border:#d8e1eb;--yellow:#e7a900;--red:#d64545}body{margin:0;font-family:Segoe UI,Arial,sans-serif;background:#eef3f8;color:#132238}header{background:#10233f;color:white;padding:24px 30px}main{padding:24px}.summary{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:16px}.card{background:white;border:1px solid var(--border);border-radius:14px;padding:14px 18px;min-width:180px}.card strong{display:block;font-size:25px}.card span{color:#64748b;font-size:13px}.toolbar{margin:0 0 14px}.toolbar select,.toolbar input{padding:9px 12px;border:1px solid var(--border);border-radius:9px;background:white;margin-right:8px}.table-wrap{background:white;border:1px solid var(--border);border-radius:14px;overflow:auto}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:10px 12px;border-bottom:1px solid var(--border);text-align:left;white-space:nowrap}th{background:#edf2f8;position:sticky;top:0}.badge{display:inline-block;border-radius:999px;padding:4px 10px;font-weight:700}.warning{background:#fff2b8;color:#6f5200;border:1px solid #e7a900}.critical{background:#d64545;color:white;border:1px solid #b52f2f}.muted{color:#64748b}</style></head><body>
<header><h1 style="margin:0 0 8px">Disk Space Health</h1><div>SQL/SCCM inventory only - no live endpoint query</div></header><main>
<div class="summary"><div class="card"><strong>$($EndpointHealth.DiskWarningCount)</strong><span>Warning (&gt;$($EndpointHealth.DiskCriticalPercent)% and &le;$($EndpointHealth.DiskWarningPercent)% free)</span></div><div class="card"><strong>$($EndpointHealth.DiskCriticalCount)</strong><span>Critical (&le;$($EndpointHealth.DiskCriticalPercent)% free)</span></div><div class="card"><strong>$diskPct%</strong><span>Affected of $total devices</span></div></div>
<div class="toolbar"><select id="statusFilter"><option value="">All statuses</option><option value="Warning">Warning</option><option value="Critical">Critical</option></select><input id="search" type="search" placeholder="Filter hostname or status"></div>
<div class="table-wrap"><table id="diskTable"><thead><tr><th>Device</th><th>Status</th><th>Free %</th><th>Free GB</th><th>Total GB</th><th>Next steps</th></tr></thead><tbody>$($diskTableRows -join "`n")</tbody></table></div>
<p class="muted">Warning: more than $($EndpointHealth.DiskCriticalPercent)% and up to $($EndpointHealth.DiskWarningPercent)% free. Critical: $($EndpointHealth.DiskCriticalPercent)% free or less. Values are from SCCM inventory, not a live endpoint check.</p>
<script>const rows=[...document.querySelectorAll('#diskTable tbody tr')],sf=document.getElementById('statusFilter'),q=document.getElementById('search');function f(){const s=sf.value,t=q.value.toLowerCase().trim();rows.forEach(r=>{const okS=!s||r.dataset.diskstatus===s;const okT=!t||r.innerText.toLowerCase().includes(t);r.style.display=(okS&&okT)?'':'none';});}sf.addEventListener('change',f);q.addEventListener('input',f);</script>
</main></body></html>
"@
    Set-Content -LiteralPath (Join-Path $ReportFolder 'EndpointHealth_DiskSpace.html') -Value $diskHtml -Encoding UTF8
    $diskRows | Select-Object Device,DiskStatus,FreeCPct,FreeCGB,TotalCGB,ResourceID | Export-Csv -LiteralPath (Join-Path $ReportFolder 'EndpointHealth_DiskSpace.csv') -NoTypeInformation -Encoding UTF8

    $simpleItems = @(
        [pscustomobject]@{ Label='Client Check Failed'; Count=[int]$EndpointHealth.ClientCheckFailedCount; Rows=@($EndpointHealth.ClientCheckFailedRows); Page='EndpointHealth_ClientCheckFailed.html'; Csv='EndpointHealth_ClientCheckFailed.csv'; Next='Review ConfigMgr client health/CCMEval and remediate the client.'; Kind='ClientCheck' },
        [pscustomobject]@{ Label="Inactive > $($EndpointHealth.InactiveDays) Days"; Count=[int]$EndpointHealth.InactiveCount; Rows=@($EndpointHealth.InactiveRows); Page='EndpointHealth_Inactive30Days.html'; Csv='EndpointHealth_Inactive30Days.csv'; Next='Validate offline/retired devices and ownership before remediation or cleanup.'; Kind='Inactive' }
    )
    foreach ($item in $simpleItems) {
        $tableRows = foreach ($r in @($item.Rows)) {
            $detail = if ($item.Kind -eq 'ClientCheck') { "Client Check: $($r.ClientCheckResult)" } else { "Last activity $(EH-Date $r.LastActivity) - $($r.DaysInactive) days" }
            "<tr><td>$(ConvertTo-HtmlSafe $r.Device)</td><td>$(ConvertTo-HtmlSafe $item.Label)</td><td>$(ConvertTo-HtmlSafe $detail)</td><td>$(ConvertTo-HtmlSafe $r.ClientStatus)</td><td>$(ConvertTo-HtmlSafe $r.ClientCheckResult)</td><td>$(ConvertTo-HtmlSafe (EH-Date $r.LastActivity))</td><td>$(ConvertTo-HtmlSafe $item.Next)</td></tr>"
        }
        $pct = EH-Pct $item.Count $total
        $pageHtml = @"
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>$($item.Label) - Endpoint Health</title>
<style>body{margin:0;font-family:Segoe UI,Arial,sans-serif;background:#eef3f8;color:#132238}header{background:#10233f;color:white;padding:24px 30px}main{padding:24px}.summary{display:flex;gap:12px;margin-bottom:16px}.card{background:white;border:1px solid #d8e1eb;border-radius:14px;padding:14px 18px;min-width:180px}.card strong{display:block;font-size:25px}.card span{color:#64748b;font-size:13px}.table-wrap{background:white;border:1px solid #d8e1eb;border-radius:14px;overflow:auto}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:10px 12px;border-bottom:1px solid #d8e1eb;text-align:left;white-space:nowrap}th{background:#edf2f8;position:sticky;top:0}.muted{color:#64748b}</style></head><body>
<header><h1 style="margin:0 0 8px">$($item.Label)</h1><div>SQL/SCCM status only - no live endpoint query</div></header><main>
<div class="summary"><div class="card"><strong>$($item.Count)</strong><span>Affected devices</span></div><div class="card"><strong>$pct%</strong><span>Of $total devices in collection</span></div></div>
<div class="table-wrap"><table><thead><tr><th>Device</th><th>Status</th><th>Detail</th><th>Client Status</th><th>Client Check</th><th>Last Activity</th><th>Next steps</th></tr></thead><tbody>$($tableRows -join "`n")</tbody></table></div>
<p class="muted">Values are from Configuration Manager data. No endpoint connection is performed.</p></main></body></html>
"@
        Set-Content -LiteralPath (Join-Path $ReportFolder $item.Page) -Value $pageHtml -Encoding UTF8
        @($item.Rows) | Select-Object Device,ClientStatus,ClientCheckResult,LastActivity,DaysInactive,ResourceID | Export-Csv -LiteralPath (Join-Path $ReportFolder $item.Csv) -NoTypeInformation -Encoding UTF8
    }

    $warnPct = EH-Pct ([int]$EndpointHealth.DiskWarningCount) $total
    $critPct = EH-Pct ([int]$EndpointHealth.DiskCriticalCount) $total
    $failPct = EH-Pct ([int]$EndpointHealth.ClientCheckFailedCount) $total
    $inactivePct = EH-Pct ([int]$EndpointHealth.InactiveCount) $total
    return @"
<section class='panel' style='margin-top:18px'>
<h2 style='margin-top:0'>Endpoint Health</h2>
<div style='overflow:auto'><table style='width:100%;border-collapse:collapse;font-size:14px'>
<thead><tr><th style='text-align:left;padding:10px;border-bottom:1px solid var(--border)'># Devices</th><th style='text-align:left;padding:10px;border-bottom:1px solid var(--border)'>% Park</th><th style='text-align:left;padding:10px;border-bottom:1px solid var(--border)'>Status</th><th style='text-align:left;padding:10px;border-bottom:1px solid var(--border)'>Next steps</th></tr></thead>
<tbody>
<tr data-page='EndpointHealth_DiskSpace.html' style='cursor:pointer'><td style='padding:12px;border-bottom:1px solid var(--border)'><b>$($EndpointHealth.DiskWarningCount)</b></td><td style='padding:12px;border-bottom:1px solid var(--border)'>$warnPct%</td><td style='padding:12px;border-bottom:1px solid var(--border)'><span style='display:inline-block;border-radius:999px;padding:4px 10px;font-weight:700;background:#fff2b8;color:#6f5200;border:1px solid #e7a900'>WARNING</span> Disk free &le; $($EndpointHealth.DiskWarningPercent)% and &gt; $($EndpointHealth.DiskCriticalPercent)%</td><td style='padding:12px;border-bottom:1px solid var(--border)'>Run disk cleanup/remediation.</td></tr>
<tr data-page='EndpointHealth_DiskSpace.html' style='cursor:pointer'><td style='padding:12px;border-bottom:1px solid var(--border)'><b>$($EndpointHealth.DiskCriticalCount)</b></td><td style='padding:12px;border-bottom:1px solid var(--border)'>$critPct%</td><td style='padding:12px;border-bottom:1px solid var(--border)'><span style='display:inline-block;border-radius:999px;padding:4px 10px;font-weight:700;background:#d64545;color:white'>CRITICAL</span> Disk free &le; $($EndpointHealth.DiskCriticalPercent)%</td><td style='padding:12px;border-bottom:1px solid var(--border)'>Immediate disk cleanup/remediation.</td></tr>
<tr data-page='EndpointHealth_ClientCheckFailed.html' style='cursor:pointer'><td style='padding:12px;border-bottom:1px solid var(--border)'><b>$($EndpointHealth.ClientCheckFailedCount)</b></td><td style='padding:12px;border-bottom:1px solid var(--border)'>$failPct%</td><td style='padding:12px;border-bottom:1px solid var(--border)'><b>Client Check Failed</b></td><td style='padding:12px;border-bottom:1px solid var(--border)'>Review CCMEval/client health and remediate.</td></tr>
<tr data-page='EndpointHealth_Inactive30Days.html' style='cursor:pointer'><td style='padding:12px'><b>$($EndpointHealth.InactiveCount)</b></td><td style='padding:12px'>$inactivePct%</td><td style='padding:12px'><b>Inactive &gt; $($EndpointHealth.InactiveDays) Days</b></td><td style='padding:12px'>Validate offline/retired devices and ownership.</td></tr>
</tbody></table></div>
<div class='note'>Endpoint Health is SERVER-SIDE ONLY (SCCM SQL inventory/status). It never connects to individual endpoints and never changes Success, In Progress, Error or Unknown. Population used for percentages: <b>$total</b> devices.</div>
</section>
"@
}
