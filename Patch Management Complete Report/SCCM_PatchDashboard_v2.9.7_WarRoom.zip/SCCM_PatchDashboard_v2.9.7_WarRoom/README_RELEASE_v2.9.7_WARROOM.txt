SCCM PATCH DASHBOARD v2.9.7 - WAR ROOM LAYER
=============================================

BASELINE
- Built directly on v2.9.6 QFECompliance.
- 01_Compliance_Query_AutoResolve.sql is unchanged (SHA-256 preserved).
- Existing QFE classification, deployment buckets, Top 3 errors, MP/DP, Disk Space,
  Endpoint Health and PatchCycleHistory logic are not used as mutable inputs by War Room.

NEW WAR ROOM LAYER
- Zero-Day Patching War Room panel added above the existing dashboard.
- Incident Commander, checkpoint, next checkpoint and enforcement deadline.
- Data As Of and Data Source(s).
- QFE-based Total In Scope, Successfully Patched, Compliance %, Remaining Unpatched.
- Failed Patches = devices in Error that are not QFE-compliant.
- Offline / Unreachable is explicitly shown only as a ConfigMgr inactivity proxy (>30 days),
  never as a live connectivity test.
- Manual Remediation, Pending Exceptions and Approved Exceptions are editable inputs in
  Run-Unattended.ps1 and default to zero.
- Enforcement Candidates = Remaining Unpatched - Approved Exceptions (minimum zero).
- Devices Patched Since Last Checkpoint and Net Compliance Improvement are automatic.
- Major Progress Achieved and New Issues Identified are optional manual text inputs.

CHECKPOINT HISTORY SAFETY
- New file: WarRoomCheckpointHistory.json, created on first successful run.
- Every report execution is preserved (including multiple checkpoints on the same day).
- The file is isolated from PatchCycleHistory.json and SCCM data.
- A .bak copy is made before updating an existing checkpoint history.
- History is capped at the most recent 500 checkpoints.
- If War Room calculation/history fails, the main dashboard still generates without it.

AUTO STATUS
- GREEN / YES: no remaining unpatched devices.
- RED / NO: enforcement deadline has passed and devices remain unpatched.
- AMBER / AT RISK: patch errors exist before the deadline.
- IN PROGRESS otherwise.

CONFIGURATION
Edit only the War Room variables near the top of Run-Unattended.ps1 when needed:
  $IncidentCommander
  $NextCheckpoint
  $NetworkEnforcementDeadline
  $ManualRemediation
  $PendingExceptions
  $ApprovedExceptions
  $MajorProgressAchieved
  $NewIssuesIdentified

IMPORTANT
The War Room layer reads the completed dataset; it does not filter, replace or rewrite
$data.Rows. This avoids the dataset regression that occurred in the abandoned history build.
