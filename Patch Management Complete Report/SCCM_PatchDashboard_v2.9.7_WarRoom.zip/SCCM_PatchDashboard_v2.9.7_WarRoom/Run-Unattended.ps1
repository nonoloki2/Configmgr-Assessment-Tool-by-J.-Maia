﻿<#
================================================================================
 SCCM Monthly Patch Dashboard - ETAPA 3
 Execução 100% desatendida (sem WPF). Disparado pela ferramenta de automação
 todo dia às 17h. Gera o mesmo Dashboard.html de sempre, agora alimentado
 pelas queries SQL (Etapa 1), grava o snapshot do dia (Etapa 2) e injeta o
 rodapé comparativo de ciclo direto no HTML.
================================================================================
#>

param()

# ================================================================
# CONFIGURAÇÃO FIXA — preencher UMA vez. A automação não passa
# nenhum parâmetro na hora de agendar; roda sem argumentos.
# ================================================================

$SqlServer   = 'NJNWKSMS08V'                     # <-- ÚNICO valor que falta preencher (nome/instância do SQL Server do site A03)
$Database    = 'CM_A03'

# A coleção reportada agora é sempre a mesma que o próprio deployment
# do mês atinge (resolvida automaticamente pela query) — não precisa
# mais ser escolhida aqui.

$DeploymentNamePattern = 'Desktop Deployment - Enterprise Production - Windows - {YYYY} - {MM}'

# Pastas relativas ao próprio script — nada disso precisa ser passado por fora
$QueryFilePath = Join-Path $PSScriptRoot '01_Compliance_Query_AutoResolve.sql'
$OutputFolder  = Join-Path $PSScriptRoot 'Reports'
$LogFolder     = Join-Path $OutputFolder 'Logs'
$HistoryPath   = Join-Path $PSScriptRoot 'PatchCycleHistory.json'          # historico local, NAO fica no SQL
$HistorySeedPath = Join-Path $PSScriptRoot 'PatchCycleHistory.seed.json'  # carga inicial (Jun/Jul) fornecida pelo cliente

# Enriquecimentos opcionais. Mantidos separados da logica de compliance/patch.
$EnableSmsProviderErrorEnrichment = $true
# HARD RULE: unattended generation never connects to individual endpoints.
# Allowed sources: SCCM SQL and SMS Provider only.
$EnableEndpointHealth             = $true
$DiskWarningPercent               = 15
$DiskCriticalPercent              = 5
$InactiveDays                     = 30

# War Room / Incident Commander layer (v2.9.7).
# These values are optional and do not affect compliance calculations.
$IncidentCommander                 = 'Dina Youssef'
$NextCheckpoint                    = '1:00 PM'
$NetworkEnforcementDeadline        = '2026-08-19 17:00'
$ManualRemediation                 = 0
$PendingExceptions                 = 0
$ApprovedExceptions                = 0
$MajorProgressAchieved             = ''
$NewIssuesIdentified               = ''
$WarRoomCheckpointHistoryPath      = Join-Path $PSScriptRoot 'WarRoomCheckpointHistory.json'

# Defaults defensivos: recursos opcionais nunca podem impedir o Patch Report.
if (-not (Get-Variable -Name EnableSmsProviderErrorEnrichment -Scope Script -ErrorAction SilentlyContinue)) {
    $EnableSmsProviderErrorEnrichment = $true
}

if ([string]::IsNullOrWhiteSpace($SqlServer)) {
    throw "Preencha a variável `$SqlServer no início deste script antes de agendar a automação."
}

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'SCCM_PatchDashboard.Core.ps1')
. (Join-Path $PSScriptRoot 'SCCM_PatchDashboard.DataAccess.ps1')
$script:EndpointRealtimeBlocked = $true  # hard safety gate for unattended mode

New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
New-Item -ItemType Directory -Path $LogFolder -Force | Out-Null

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$logPath = Join-Path $LogFolder "Run_$stamp.log"
Set-Content -LiteralPath $logPath -Value '' -Encoding UTF8

try {
    Write-Log $logPath "===== Execucao iniciada (headless / SERVER-SIDE ONLY) ====="
    Write-Log $logPath "NO-ENDPOINT MODE: individual endpoint connections are disabled. Sources: SCCM SQL + SMS Provider only."

    if (-not (Test-Path -LiteralPath $HistoryPath) -and (Test-Path -LiteralPath $HistorySeedPath)) {
        Copy-Item -LiteralPath $HistorySeedPath -Destination $HistoryPath
        Write-Log $logPath "Historico local nao existia; carga inicial (seed Jun/Jul) copiada para $HistoryPath."
    }

    # 1) Extrai dados via SQL - SOMENTE LEITURA (SELECT). AssignmentID, KBs e
    #    ciclo sao resolvidos dinamicamente pela propria query.
    $data = Get-SqlComplianceRows -SqlServer $SqlServer -Database $Database `
        -DeploymentNamePattern $DeploymentNamePattern `
        -QueryFilePath $QueryFilePath -LogPath $logPath

    if ($data.Rows.Count -eq 0) {
        throw "Nenhum dispositivo retornado para a colecao $($data.CollectionName) / AssignmentID $($data.AssignmentID)."
    }

    # Restaura a mesma fidelidade de ErrorCode do dashboard v2.8 usando
    # SMS_SUMDeploymentAssetDetails quando o SMS Provider estiver acessivel.
    if ($EnableSmsProviderErrorEnrichment) {
        $data.Rows = @(Add-SmsProviderErrorEnrichment -Rows $data.Rows -SqlServer $SqlServer -Database $Database `
            -AssignmentID ([int]$data.AssignmentID) -LogPath $logPath)
    }
    $errorGroups = @($data.Rows | Where-Object { $_.DeploymentStatus -eq 'Error' -and $_.ErrorCode } | Group-Object ErrorCode | Sort-Object Count -Descending)
    Write-Log $logPath ("Error-code diagnostic: {0} distinct code(s). {1}" -f $errorGroups.Count, (($errorGroups | Select-Object -First 10 | ForEach-Object { "{0}={1}" -f $_.Name,$_.Count }) -join '; '))

    # Endpoint Health independente: falha aqui NUNCA pode impedir o Patch Report.
    $endpointHealth = $null
    if ($EnableEndpointHealth) {
        try {
            $endpointHealth = Get-EndpointHealthData -SqlServer $SqlServer -Database $Database `
                -CollectionID $data.CollectionID -DiskWarningPercent $DiskWarningPercent -DiskCriticalPercent $DiskCriticalPercent -InactiveDays $InactiveDays -LogPath $logPath
            Write-Log $logPath ("Endpoint Health: total={0}; low disk={1}; client check failed={2}; inactive>{3}d={4}" -f `
                $endpointHealth.TotalDevices,($endpointHealth.DiskWarningCount + $endpointHealth.DiskCriticalCount),$endpointHealth.ClientCheckFailedCount,$InactiveDays,$endpointHealth.InactiveCount)
            if ([int]$endpointHealth.TotalDevices -ne [int]$data.Rows.Count) {
                Write-Log $logPath ("Endpoint Health population ({0}) difere do Patch Report ({1}); indicadores continuam separados e nao alteram o patch." -f $endpointHealth.TotalDevices,$data.Rows.Count) 'WARN'
            }
        } catch {
            Write-Log $logPath "Endpoint Health falhou e foi ignorado; Patch Report continua normalmente: $($_.Exception.Message)" 'WARN'
            $endpointHealth = $null
        }
    }

    $cycleLabel = $data.CycleStartDate.ToString('yyyy-MM')
    $today = Get-Date

    # 2) Grava o snapshot do dia no historico LOCAL (JSON) - nada escrito no SQL
    $population = $data.Rows.Count
    $corrected  = @($data.Rows | Where-Object ComplianceBucket -eq 'Compliant').Count

    Save-CycleSnapshot -HistoryPath $HistoryPath `
        -CycleLabel $cycleLabel -DayNumber $data.CycleDayNumber -CalendarDate $today `
        -PopulationTotal $population -CorrectedCount $corrected -LogPath $logPath | Out-Null

    # 3) Monta o HTML do rodape comparativo (ciclo atual x ciclo anterior), a partir do JSON
    #    Isso e um extra: se falhar por qualquer motivo, o dashboard principal
    #    tem que sair do mesmo jeito, so sem o rodape.
    $footerHtml = ''
    try {
        $footerHtml = Get-CycleFooterHtml -HistoryPath $HistoryPath -CycleLabel $cycleLabel -LogPath $logPath
    } catch {
        Write-Log $logPath "Rodape comparativo falhou e foi ignorado: $($_.Exception.Message)" 'WARN'
    }

    # 4) War Room layer - isolated checkpoint history. This never changes $data.Rows.
    $warRoom = $null
    try {
        $warRoom = New-WarRoomCheckpointSummary `
            -Rows $data.Rows `
            -CheckpointHistoryPath $WarRoomCheckpointHistoryPath `
            -CycleLabel $cycleLabel `
            -CycleDayNumber $data.CycleDayNumber `
            -IncidentCommander $IncidentCommander `
            -NextCheckpoint $NextCheckpoint `
            -NetworkEnforcementDeadline $NetworkEnforcementDeadline `
            -ManualRemediation $ManualRemediation `
            -PendingExceptions $PendingExceptions `
            -ApprovedExceptions $ApprovedExceptions `
            -MajorProgressAchieved $MajorProgressAchieved `
            -NewIssuesIdentified $NewIssuesIdentified `
            -InactiveProxyCount $(if ($null -ne $endpointHealth) { [int]$endpointHealth.InactiveCount } else { 0 }) `
            -InactiveProxyDays $InactiveDays `
            -LogPath $logPath
    } catch {
        Write-Log $logPath "War Room summary falhou e foi ignorado; dashboard principal continua: $($_.Exception.Message)" 'WARN'
        $warRoom = $null
    }

    # 5) Gera o dashboard (core original + camadas opcionais)
    $result = Export-ReportPackage `
        -Rows $data.Rows `
        -DeploymentName $data.DeploymentName `
        -CollectionName $data.CollectionName `
        -CollectionID $data.CollectionID `
        -AssignmentID $data.AssignmentID `
        -DeploymentID ([string]$data.AssignmentID) `
        -BaseOutputFolder $OutputFolder `
        -LogPath $logPath `
        -CheckApiBase '' `
        -CheckToken '' `
        -EndpointHealth $endpointHealth `
        -CycleFooterHtml $footerHtml `
        -WarRoom $warRoom

    Write-Log $logPath "Dashboard gerado com sucesso: $($result.DashboardPath)"
    Write-Log $logPath "===== Execução concluída OK ====="
    exit 0
}
catch {
    $msg = "ERRO: $($_.Exception.Message) | Linha: $($_.InvocationInfo.ScriptLineNumber) | $($_.InvocationInfo.PositionMessage)"
    if (Test-Path -LiteralPath $logPath) { Write-Log $logPath $msg 'ERROR' }
    Write-Error $msg
    exit 1
}
