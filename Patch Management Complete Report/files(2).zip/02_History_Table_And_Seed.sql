﻿/*
================================================================================
 SCCM Monthly Patch Dashboard - ETAPA 2
 Tabela de histórico diário do ciclo de patch + carga inicial (seed)
 com os dados reais de Junho/2026 e Julho/2026 (fornecidos pelo usuário).

 Objetivo: dar continuidade ao comparativo "dia N do ciclo atual vs dia N
 do ciclo anterior" a partir do primeiro dia em que a automação rodar,
 sem ficar com o rodapé do dashboard em branco por falta de histórico.

 Esta tabela será alimentada diariamente pelo job (Etapa 3), com base no
 resultado das queries de compliant/non-compliant da Etapa 1.
================================================================================
*/

SET NOCOUNT ON;

/* ============================================================
   1) TABELA DE HISTÓRICO
   ============================================================ */

IF OBJECT_ID('dbo.PatchCycle_DailyHistory', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.PatchCycle_DailyHistory
    (
        CycleLabel          NVARCHAR(10)   NOT NULL,   -- ex: '2026-06', '2026-07'
        DayNumber           SMALLINT       NOT NULL,   -- -8 (início do Pilot) a 30 (fim do ciclo Production)
        CalendarDate        DATE           NOT NULL,
        CollectionID        NVARCHAR(8)    NOT NULL DEFAULT 'A0300E28',
        PopulationTotal     INT            NULL,       -- total do parque naquele dia (denominador)
        CorrectedCount      INT            NULL,       -- dispositivos compliant acumulados naquele dia
        PercentCompliant    DECIMAL(6,2)   NULL,       -- % acumulado do dia
        IsSeedData          BIT            NOT NULL DEFAULT 0,  -- 1 = carregado manualmente (planilha), 0 = gerado pelo job diário
        SnapshotCapturedAt  DATETIME2(0)   NOT NULL DEFAULT SYSDATETIME(),

        CONSTRAINT PK_PatchCycle_DailyHistory PRIMARY KEY (CycleLabel, DayNumber)
    );
END


/* ============================================================
   2) CARGA INICIAL — CICLO JUNHO/2026
      (Day -8 = 09-Jun / Day 0 = 17-Jun / Day 18 = 05-Jul)
      Só o % acumulado estava disponível na planilha de origem;
      População e corrigidos ficam NULL para este ciclo.
      Day 10 e Day 11 sem dado na planilha original (deixados NULL).
   ============================================================ */

DELETE FROM dbo.PatchCycle_DailyHistory WHERE CycleLabel = '2026-06';

INSERT INTO dbo.PatchCycle_DailyHistory
    (CycleLabel, DayNumber, CalendarDate, PopulationTotal, CorrectedCount, PercentCompliant, IsSeedData)
VALUES
    ('2026-06', -8, '2026-06-09', NULL, NULL,  0.00, 1),
    ('2026-06', -7, '2026-06-10', NULL, NULL,  0.29, 1),
    ('2026-06', -6, '2026-06-11', NULL, NULL,  1.22, 1),
    ('2026-06', -5, '2026-06-12', NULL, NULL,  2.16, 1),
    ('2026-06', -4, '2026-06-13', NULL, NULL,  2.35, 1),
    ('2026-06', -3, '2026-06-14', NULL, NULL,  2.37, 1),
    ('2026-06', -2, '2026-06-15', NULL, NULL,  2.52, 1),
    ('2026-06', -1, '2026-06-16', NULL, NULL,  2.65, 1),
    ('2026-06',  0, '2026-06-17', NULL, NULL, 30.16, 1),
    ('2026-06',  1, '2026-06-18', NULL, NULL, 47.29, 1),
    ('2026-06',  2, '2026-06-19', NULL, NULL, 53.73, 1),
    ('2026-06',  3, '2026-06-20', NULL, NULL, 55.61, 1),
    ('2026-06',  4, '2026-06-21', NULL, NULL, 56.05, 1),
    ('2026-06',  5, '2026-06-22', NULL, NULL, 58.67, 1),
    ('2026-06',  6, '2026-06-23', NULL, NULL, 66.95, 1),
    ('2026-06',  7, '2026-06-24', NULL, NULL, 72.23, 1),
    ('2026-06',  8, '2026-06-25', NULL, NULL, 75.19, 1),
    ('2026-06',  9, '2026-06-26', NULL, NULL, 79.12, 1),
    ('2026-06', 10, '2026-06-27', NULL, NULL, NULL,  1),   -- sem dado na planilha original
    ('2026-06', 11, '2026-06-28', NULL, NULL, NULL,  1),   -- sem dado na planilha original
    ('2026-06', 12, '2026-06-29', NULL, NULL, 81.96, 1),
    ('2026-06', 13, '2026-06-30', NULL, NULL, 83.75, 1),
    ('2026-06', 14, '2026-07-01', NULL, NULL, 85.21, 1),
    ('2026-06', 15, '2026-07-02', NULL, NULL, 86.84, 1),
    ('2026-06', 16, '2026-07-03', NULL, NULL, 88.42, 1),
    ('2026-06', 17, '2026-07-04', NULL, NULL, 90.18, 1),
    ('2026-06', 18, '2026-07-05', NULL, NULL, 90.86, 1);


/* ============================================================
   3) CARGA INICIAL — CICLO JULHO/2026
      (Day -8 = 12-Jul [data manual/atrasada; o correto pela regra
       seria 14-Jul] / Day 0 = 20-Jul / Day 18 = 07-Ago)
      População e corrigidos disponíveis a partir do Day -6.
      Day -8 e Day -7 sem dado (Pilot ainda não iniciado na prática).
   ============================================================ */

DELETE FROM dbo.PatchCycle_DailyHistory WHERE CycleLabel = '2026-07';

INSERT INTO dbo.PatchCycle_DailyHistory
    (CycleLabel, DayNumber, CalendarDate, PopulationTotal, CorrectedCount, PercentCompliant, IsSeedData)
VALUES
    ('2026-07', -8, '2026-07-12', NULL,  NULL, NULL,  1),  -- sem dado (pilot não iniciado)
    ('2026-07', -7, '2026-07-13', NULL,  NULL, NULL,  1),  -- sem dado (pilot não iniciado)
    ('2026-07', -6, '2026-07-14', NULL,     0, NULL,  1),  -- população não registrada nesse dia
    ('2026-07', -5, '2026-07-15', 10403,   29,  0.28, 1),
    ('2026-07', -4, '2026-07-16', 10457,  155,  1.48, 1),
    ('2026-07', -3, '2026-07-17', 10434,  222,  2.13, 1),
    ('2026-07', -2, '2026-07-18', 10436,  321,  3.08, 1),
    ('2026-07', -1, '2026-07-19', 10436,  348,  3.33, 1),
    ('2026-07',  0, '2026-07-20', 10441, 1530, 14.65, 1),
    ('2026-07',  1, '2026-07-21', 10464, 4833, 46.19, 1),
    ('2026-07',  2, '2026-07-22', 10481, 6074, 57.95, 1),
    ('2026-07',  3, '2026-07-23', 10528, 6668, 63.34, 1),
    ('2026-07',  4, '2026-07-24', 10517, 7106, 67.57, 1),
    ('2026-07',  5, '2026-07-25', 10524, 7356, 69.90, 1),
    ('2026-07',  6, '2026-07-26', 10511, 7409, 70.49, 1),
    ('2026-07',  7, '2026-07-27', 10508, 7663, 72.93, 1),
    ('2026-07',  8, '2026-07-28', 10501, 8017, 76.35, 1),
    ('2026-07',  9, '2026-07-29', 10494, 8427, 80.30, 1),
    ('2026-07', 10, '2026-07-30', 10513, 8594, 81.75, 1),
    ('2026-07', 11, '2026-07-31', 10457, 8805, 84.20, 1),
    ('2026-07', 12, '2026-08-01', 10453, 8916, 85.30, 1),
    ('2026-07', 13, '2026-08-02', 10447, 8942, 85.59, 1),
    ('2026-07', 14, '2026-08-03', 10445, 9097, 87.09, 1),
    ('2026-07', 15, '2026-08-04', 10462, 9281, 88.71, 1),
    ('2026-07', 16, '2026-08-05', 10444, 9513, 91.09, 1),
    ('2026-07', 17, '2026-08-06', 10430, 9640, 92.43, 1),
    ('2026-07', 18, '2026-08-07', 10392, 9720, 93.53, 1);


/* ============================================================
   4) CONFERÊNCIA — reproduz a linha de delta da planilha
      (% do ciclo corrente - % do mesmo Day Number no ciclo anterior)
      Rodar este SELECT após a carga para validar contra a planilha.
   ============================================================ */

SELECT
    cur.DayNumber,
    cur.CalendarDate                                   AS Current_Date,
    cur.PercentCompliant                               AS Current_Percent,
    prev.CalendarDate                                  AS Previous_Cycle_Date,
    prev.PercentCompliant                              AS Previous_Cycle_Percent,
    CASE
        WHEN cur.PercentCompliant IS NULL OR prev.PercentCompliant IS NULL THEN NULL
        ELSE ROUND(cur.PercentCompliant - prev.PercentCompliant, 2)
    END                                                 AS Delta_Percent
FROM dbo.PatchCycle_DailyHistory cur
LEFT JOIN dbo.PatchCycle_DailyHistory prev
    ON prev.CycleLabel = '2026-06'
   AND prev.DayNumber  = cur.DayNumber
WHERE cur.CycleLabel = '2026-07'
ORDER BY cur.DayNumber;


/* ============================================================
   5) MODELO PARA O JOB DIÁRIO (Etapa 3 vai automatizar isto)
      Exemplo de como o snapshot de um novo dia (ex.: Agosto) será
      inserido/atualizado a partir do resultado das queries da Etapa 1.
      Não executar agora - é só referência do formato esperado.
   ============================================================ */

/*
MERGE dbo.PatchCycle_DailyHistory AS target
USING (SELECT
            '2026-08'        AS CycleLabel,
            @CycleDay         AS DayNumber,
            @Today            AS CalendarDate,
            @PopulationTotal  AS PopulationTotal,
            @CorrectedCount   AS CorrectedCount,
            @PercentCompliant AS PercentCompliant
      ) AS src
ON  target.CycleLabel = src.CycleLabel
AND target.DayNumber  = src.DayNumber
WHEN MATCHED THEN
    UPDATE SET
        PopulationTotal    = src.PopulationTotal,
        CorrectedCount     = src.CorrectedCount,
        PercentCompliant   = src.PercentCompliant,
        SnapshotCapturedAt = SYSDATETIME(),
        IsSeedData         = 0
WHEN NOT MATCHED THEN
    INSERT (CycleLabel, DayNumber, CalendarDate, PopulationTotal, CorrectedCount, PercentCompliant, IsSeedData)
    VALUES (src.CycleLabel, src.DayNumber, src.CalendarDate, src.PopulationTotal, src.CorrectedCount, src.PercentCompliant, 0);
*/
