﻿function ConvertTo-NormalizedDeploymentStatus {
    <#
        Mapeia o Status_State (texto vindo de v_StateNames) para os 4
        buckets do dashboard: Success / InProgress / Error / Unknown.
        Baseado nos valores REAIS confirmados no ambiente (via
        03_Diagnostico_Status_State.sql), nao mais em suposicao.
        Qualquer valor novo/nao previsto cai em Unknown (e eh logado).
    #>
    param([string]$StatusState, [string]$LogPath)

    if ([string]::IsNullOrWhiteSpace($StatusState)) { return 'Unknown' }

    switch ($StatusState.Trim()) {
        'Compliant'                       { return 'Success' }
        'Successfully installed update(s)' { return 'Success' }

        'Failed to install update(s)'     { return 'Error' }
        'Failed to download update(s)'    { return 'Error' }

        'Downloaded update(s)'            { return 'InProgress' }
        'Pending system restart'          { return 'InProgress' }
        'Waiting for restart'             { return 'InProgress' }

        'Enforcement state unknown'       { return 'Unknown' }
        'Non-compliant'                   { return 'Unknown' }

        default {
            if ($LogPath) { Write-Log $LogPath "Status_State '$StatusState' sem mapeamento conhecido; tratado como Unknown." 'WARN' }
            return 'Unknown'
        }
    }
}

# ================================================================
# CAMADA SQL - ADO.NET puro (System.Data.SqlClient), sem depender
# de nenhum modulo externo (nada a instalar no servidor).
# ================================================================

Add-Type -AssemblyName System.Data -ErrorAction SilentlyContinue

function New-SqlConnectionString {
    param(
        [Parameter(Mandatory)][string]$Server,
        [Parameter(Mandatory)][string]$Database
    )
    # Autenticacao Windows Integrada (conta de servico da automacao).
    # Se o ambiente exigir login SQL, troque a linha abaixo por:
    #   "Server=$Server;Database=$Database;User ID=SEU_USER;Password=SUA_SENHA;TrustServerCertificate=True;Connection Timeout=30;"
    return "Server=$Server;Database=$Database;Integrated Security=True;TrustServerCertificate=True;Connection Timeout=30;"
}

function ConvertFrom-DataTable {
    <#
        Converte um System.Data.DataTable em uma lista de PSCustomObject,
        preservando [DBNull]::Value como esta (codigo existente ja checa isso).
    #>
    param([Parameter(Mandatory)][System.Data.DataTable]$Table)

    $colNames = @($Table.Columns | ForEach-Object { $_.ColumnName })
    $result = New-Object System.Collections.Generic.List[object]
    foreach ($row in $Table.Rows) {
        $props = [ordered]@{}
        foreach ($c in $colNames) { $props[$c] = $row[$c] }
        $result.Add([pscustomobject]$props)
    }
    return $result.ToArray()
}

function Get-SqlDataSet {
    <#
        Executa uma query (texto ou arquivo .sql) e devolve um DataSet.
        Suporta multiplos result sets (o SqlDataAdapter preenche
        $ds.Tables[0], [1], [2]... na ordem em que a query os retorna).
    #>
    param(
        [Parameter(Mandatory)][string]$ConnectionString,
        [string]$Query,
        [string]$InputFile,
        [int]$TimeoutSeconds = 300
    )

    if ($InputFile) { $Query = Get-Content -LiteralPath $InputFile -Raw -Encoding UTF8 }
    if ([string]::IsNullOrWhiteSpace($Query)) { throw "Get-SqlDataSet: nenhuma query informada (Query ou InputFile)." }

    $conn = New-Object System.Data.SqlClient.SqlConnection $ConnectionString
    $cmd  = New-Object System.Data.SqlClient.SqlCommand $Query, $conn
    $cmd.CommandTimeout = $TimeoutSeconds
    $ds = New-Object System.Data.DataSet
    $da = New-Object System.Data.SqlClient.SqlDataAdapter $cmd
    try {
        $da.Fill($ds) | Out-Null
    }
    finally {
        $conn.Close()
        $conn.Dispose()
    }
    return $ds
}

function Invoke-SqlNonQuery {
    <# Executa comandos sem retorno de linhas (INSERT/UPDATE/MERGE). #>
    param(
        [Parameter(Mandatory)][string]$ConnectionString,
        [Parameter(Mandatory)][string]$Query,
        [int]$TimeoutSeconds = 60
    )
    $conn = New-Object System.Data.SqlClient.SqlConnection $ConnectionString
    $cmd  = New-Object System.Data.SqlClient.SqlCommand $Query, $conn
    $cmd.CommandTimeout = $TimeoutSeconds
    try {
        $conn.Open()
        $cmd.ExecuteNonQuery() | Out-Null
    }
    finally {
        $conn.Close()
        $conn.Dispose()
    }
}

# ================================================================
# ETAPA 1 - extracao via SQL (substitui Get-SmsProviderData / WMI)
# ================================================================

function Get-SqlComplianceRows {
    <#
        Executa a query da ETAPA 1 (01_Compliance_Query_AutoResolve.sql) via
        ADO.NET e devolve os dispositivos ja no MESMO formato de objeto que
        Convert-AssetsToRows produz hoje, para o dashboard nao precisar mudar.
        Colunas que so existiam via WMI (ClientType, Preferred DP, Pending
        Reboot, scans, etc.) ficam em branco nesta etapa, por decisao combinada.
    #>
    param(
        [Parameter(Mandatory)][string]$SqlServer,
        [Parameter(Mandatory)][string]$Database,
        [Parameter(Mandatory)][string]$DeploymentNamePattern,
        [Parameter(Mandatory)][string]$QueryFilePath,
        [Parameter(Mandatory)][string]$LogPath
    )

    $connStr = New-SqlConnectionString -Server $SqlServer -Database $Database

    $sqlText = Get-Content -LiteralPath $QueryFilePath -Raw -Encoding UTF8
    $sqlText = $sqlText -replace `
        "DECLARE @DeploymentNamePattern NVARCHAR\(200\) =\s*\r?\n\s*'.*?';", `
        "DECLARE @DeploymentNamePattern NVARCHAR(200) = '$DeploymentNamePattern';"

    Write-Log $LogPath "Executando query de compliance via ADO.NET (AssignmentID/KBs/ciclo resolvidos dinamicamente pelo proprio T-SQL)."

    $ds = Get-SqlDataSet -ConnectionString $connStr -Query $sqlText -TimeoutSeconds 300

    if ($ds.Tables.Count -lt 3) {
        throw "A query nao devolveu os 3 result sets esperados (diagnostico, compliant, non-compliant). Verifique se ela rodou ate o fim sem erro no SQL Server."
    }

    $diagRows = ConvertFrom-DataTable -Table $ds.Tables[0]
    $diag = $diagRows | Select-Object -First 1

    Write-Log $LogPath ("Resolvido -> AssignmentID={0} | Deployment='{1}' | Cycle_Start={2} | Cycle_Day={3} | KBs={4}" -f `
        $diag.Resolved_AssignmentID, $diag.Resolved_DeploymentName, $diag.Cycle_Start_Date, $diag.Cycle_Day_Number, $diag.Resolved_KBs)

    $compliantRows    = ConvertFrom-DataTable -Table $ds.Tables[1]
    $nonCompliantRows = ConvertFrom-DataTable -Table $ds.Tables[2]

    # Mapa Boundary Group Name -> lista de hostnames de DP (para "Preferred Distribution Points").
    # So monta se os 2 result sets de apoio vieram (tolerante a versoes de CM sem essas views).
    $groupNameToId = @{}
    $groupIdToHostnames = @{}
    if ($ds.Tables.Count -ge 5) {
        try {
            $bgRows = ConvertFrom-DataTable -Table $ds.Tables[3]
            foreach ($bg in $bgRows) {
                if ($bg.GroupID -ne [DBNull]::Value -and $bg.Name -ne [DBNull]::Value) {
                    $groupNameToId[[string]$bg.Name] = [int]$bg.GroupID
                }
            }
            $dpRows = ConvertFrom-DataTable -Table $ds.Tables[4]
            foreach ($dp in $dpRows) {
                if ($dp.GroupID -eq [DBNull]::Value -or $dp.ServerNALPath -eq [DBNull]::Value) { continue }
                $nal = [string]$dp.ServerNALPath
                $hostname = $null
                if ($nal -match '\\\\([^\\"\]]+)\\') { $hostname = $matches[1] }
                elseif ($nal -match 'Display=\\\\([^\\"\]]+)') { $hostname = $matches[1] }
                if ($hostname) {
                    $gid = [int]$dp.GroupID
                    if (-not $groupIdToHostnames.ContainsKey($gid)) { $groupIdToHostnames[$gid] = New-Object System.Collections.Generic.List[string] }
                    if (-not $groupIdToHostnames[$gid].Contains($hostname)) { $groupIdToHostnames[$gid].Add($hostname) }
                }
            }
            Write-Log $LogPath "Mapa de Boundary Group -> DP carregado: $($groupNameToId.Count) grupos, $($groupIdToHostnames.Count) grupos com DP."
        } catch {
            Write-Log $LogPath "Falha ao montar mapa de Preferred Distribution Points (campo ficara em branco): $($_.Exception.Message)" 'WARN'
        }
    }

    $rows = New-Object System.Collections.Generic.List[object]

    function Get-SqlVal($value) { if ($null -eq $value -or $value -eq [DBNull]::Value) { return $null } else { return $value } }

    foreach ($r in @($compliantRows) + @($nonCompliantRows)) {
        $statusState = [string]$r.Status_State
        $complianceBucket = [string]$r.Compliance_Bucket

        <#
            Classificacao dos cards do dashboard: prioriza compliance REAL
            (v_UpdateComplianceStatus, a mesma fonte do "% Compliant" oficial
            do console) sobre o status de enforcement (v_CIAssignmentStatus).
            - Compliant  -> Success (bate com o % do console)
            - NaoCompliant -> refina com Status_State (In Progress / Error /
              Unknown); se Status_State disser "Success" mas o dispositivo
              nao esta realmente compliant (ex.: pendente reavaliacao),
              cai em Unknown em vez de inflar o Success.
        #>
        if ($complianceBucket -eq 'Compliant') {
            $deploymentStatus = 'Success'
        } else {
            $normalized = ConvertTo-NormalizedDeploymentStatus -StatusState $statusState -LogPath $LogPath
            $deploymentStatus = if ($normalized -eq 'Success') { 'Unknown' } else { $normalized }
        }

        $errorCodeValue = [UInt64]0
        if ($deploymentStatus -eq 'Error' -and $r.Hex_Error_Code -ne [DBNull]::Value -and $r.Hex_Error_Code) {
            $hexStr = [string]$r.Hex_Error_Code
            if ($hexStr -match '^0x[0-9A-Fa-f]+$') {
                try { $errorCodeValue = [Convert]::ToUInt64($hexStr.Substring(2), 16) }
                catch { Write-Log $LogPath "Falha ao converter Hex_Error_Code '$hexStr' para numero (device $([string]$r.ComputerName))." 'WARN' }
            } else {
                Write-Log $LogPath "Hex_Error_Code em formato inesperado: '$hexStr' (device $([string]$r.ComputerName))." 'WARN'
            }
        }
        $errorDetail = if ($errorCodeValue -ne 0) {
            Get-ErrorDetail -Code $errorCodeValue -LastEnforcementMessage '' -StatusDescription ''
        } else { '' }
        $recommendedActions = if ($errorCodeValue -ne 0) { Get-ErrorRecommendations -Code $errorCodeValue } else { '' }

        $hasOSDomain = $r.PSObject.Properties.Name -contains 'OSDomain'

        $clientInstalledRaw = Get-SqlVal $r.ClientInstalled
        $client = if ($clientInstalledRaw -eq 1) { 'Yes' } elseif ($null -ne $clientInstalledRaw) { 'No' } else { '' }
        $clientStatus = Get-ClientStatusLabel (Get-SqlVal $r.ClientActiveStatus) $clientInstalledRaw
        $clientCheckResult = Get-ClientCheckResultLabel (Get-SqlVal $r.ClientCheckPassRaw) $null
        $policyRequest = Format-DateValue (Get-SqlVal $r.LastPolicyRequest)
        $heartbeatDdr  = Format-DateValue (Get-SqlVal $r.LastDDR)
        $hardwareScan  = Format-DateValue (Get-SqlVal $r.LastHW)
        $softwareScan  = Format-DateValue (Get-SqlVal $r.LastSW)
        $adSite        = [string](Get-SqlVal $r.ADSiteName)
        $siteCodeVal   = [string](Get-SqlVal $r.SiteCode)
        $managementPointVal = [string](Get-SqlVal $r.LastMPServerName)
        $statusMessageVal   = Format-DateValue (Get-SqlVal $r.LastStatusMessageRaw)

        $preferredDPs = ''
        $boundaryNamesRaw = Get-SqlVal $r.BoundaryGroupNamesRaw
        if ($boundaryNamesRaw -and $groupNameToId.Count -gt 0) {
            $names = @(([string]$boundaryNamesRaw) -split '[;,]' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
            $dpSet = New-Object System.Collections.Generic.List[string]
            foreach ($n in $names) {
                if ($groupNameToId.ContainsKey($n)) {
                    $gid = $groupNameToId[$n]
                    if ($groupIdToHostnames.ContainsKey($gid)) {
                        foreach ($h in $groupIdToHostnames[$gid]) {
                            if (-not $dpSet.Contains($h)) { $dpSet.Add($h) }
                        }
                    }
                }
            }
            if ($dpSet.Count -gt 0) { $preferredDPs = ($dpSet | Sort-Object) -join '; ' }
        }
        $osCaption     = [string](Get-SqlVal $r.OSCaption)
        $osBuildStr    = [string]$r.FullOSBuild
        $buildParts    = $osBuildStr -split '\.'
        $buildForVersionLookup = if ($buildParts.Count -ge 3) { $buildParts[2] } else { $osBuildStr }
        $osVersionLabel = Get-WindowsVersionLabel -Caption $osCaption -Build $buildForVersionLookup
        $uptimeVal     = Format-Uptime (Get-SqlVal $r.LastBootUpTime)

        # Pending Reboot / Reason - mesmo bitmask ClientState que o script original
        # decodificava a partir de SMS_CombinedDeviceResources (aqui via v_CombinedDeviceResources).
        $pendingRestart = ''
        $rebootReason = ''
        $clientStateRaw = Get-SqlVal $r.ClientStateRaw
        if ($null -ne $clientStateRaw) {
            $stateInt = 0
            if ([int]::TryParse([string]$clientStateRaw, [ref]$stateInt)) {
                if ($stateInt -eq 0) {
                    $pendingRestart = 'No'
                } else {
                    $pendingRestart = 'Yes'
                    $reasons = New-Object System.Collections.Generic.List[string]
                    if (($stateInt -band 1) -ne 0) { $reasons.Add('Configuration Manager') }
                    if (($stateInt -band 2) -ne 0) { $reasons.Add('File Rename') }
                    if (($stateInt -band 4) -ne 0) { $reasons.Add('Windows Update') }
                    if (($stateInt -band 8) -ne 0) { $reasons.Add('Add or Remove Feature') }
                    $knownMask = 1 -bor 2 -bor 4 -bor 8
                    $unknownBits = $stateInt -band (-bnot $knownMask)
                    if ($unknownBits -ne 0) { $reasons.Add("Other SCCM reason bits: $unknownBits") }
                    if ($reasons.Count -eq 0) { $reasons.Add("ClientState $stateInt") }
                    $rebootReason = ($reasons -join ' + ')
                }
            }
        }

        $rows.Add([pscustomobject]@{
            Device                      = [string]$r.ComputerName
            ClientType                  = ''
            Client                      = $client
            CurrentLoggedOnUser         = [string]$r.UserId
            UserUPN                     = [string]$r.User_Email
            SiteCode                    = $siteCodeVal
            ClientStatus                = $clientStatus
            ClientCheckResult           = $clientCheckResult
            PolicyRequest               = $policyRequest
            HeartbeatDDR                = $heartbeatDdr
            HardwareScan                = $hardwareScan
            SoftwareScan                = $softwareScan
            ManagementPoint             = $managementPointVal
            StatusMessage                = $statusMessageVal
            PreferredDistributionPoints = $preferredDPs
            ADSite                      = $adSite
            Domain                      = if ($hasOSDomain) { [string]$r.OSDomain } else { '' }
            Uptime                      = $uptimeVal
            OperatingSystem             = $osCaption
            OSVersion                   = $osVersionLabel
            OSBuildNumber               = [string]$r.FullOSBuild
            PendingRestart              = $pendingRestart
            RebootReason                = $rebootReason
            RebootClientState           = ''
            DeploymentStatus            = $deploymentStatus
            ErrorCode                   = if ($deploymentStatus -eq 'Error' -and $r.Hex_Error_Code -ne [DBNull]::Value) { [string]$r.Hex_Error_Code } else { '' }
            ErrorDetail                 = $errorDetail
            RecommendedActions          = $recommendedActions
            LastStatusTime              = if ($r.Last_Modification -ne [DBNull]::Value) { [string]$r.Last_Modification } else { '' }
            ResourceID                  = 0
            ComplianceBucket            = [string]$r.Compliance_Bucket
            CycleStartDate              = [string]$diag.Cycle_Start_Date
            CycleDayNumber              = [int]$diag.Cycle_Day_Number
        })
    }

    [pscustomobject]@{
        Rows           = $rows.ToArray()
        AssignmentID   = [string]$diag.Resolved_AssignmentID
        DeploymentName = [string]$diag.Resolved_DeploymentName
        CollectionID   = [string]$diag.CollectionID
        CollectionName = [string]$diag.Resolved_CollectionName
        CycleStartDate = [datetime]$diag.Cycle_Start_Date
        CycleDayNumber = [int]$diag.Cycle_Day_Number
        ResolvedKBs    = [string]$diag.Resolved_KBs
    }
}

# ================================================================
# ETAPA 2 - historico diario em ARQUIVO JSON LOCAL (nao no SQL de
# producao). O script so faz SELECT no banco do SCCM; nenhuma
# escrita, nenhum CREATE/INSERT/MERGE la. Todo estado de histórico
# fica isolado num arquivo ao lado do script, na maquina de automacao.
# ================================================================

function Import-CycleHistory {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    $raw = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    if ([string]::IsNullOrWhiteSpace($raw)) { return @() }
    return @($raw | ConvertFrom-Json)
}

function Export-CycleHistory {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][object[]]$Records
    )
    $sorted = $Records | Sort-Object CycleLabel, DayNumber
    $sorted | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $Path -Encoding UTF8
}

function Save-CycleSnapshot {
    <#
        Grava (ou atualiza) a linha do dia corrente no arquivo JSON de
        historico (ETAPA 2). Nao toca em nada no SQL Server.
    #>
    param(
        [Parameter(Mandatory)][string]$HistoryPath,
        [Parameter(Mandatory)][string]$CycleLabel,
        [Parameter(Mandatory)][int]$DayNumber,
        [Parameter(Mandatory)][datetime]$CalendarDate,
        [Parameter(Mandatory)][int]$PopulationTotal,
        [Parameter(Mandatory)][int]$CorrectedCount,
        [Parameter(Mandatory)][string]$LogPath
    )

    $percent = if ($PopulationTotal -gt 0) { [math]::Round(($CorrectedCount / $PopulationTotal) * 100, 2) } else { 0 }

    try {
        $history = [System.Collections.Generic.List[object]](Import-CycleHistory -Path $HistoryPath)
        $existing = $history | Where-Object { $_.CycleLabel -eq $CycleLabel -and $_.DayNumber -eq $DayNumber } | Select-Object -First 1

        $record = [pscustomobject]@{
            CycleLabel       = $CycleLabel
            DayNumber        = $DayNumber
            CalendarDate     = $CalendarDate.ToString('yyyy-MM-dd')
            PopulationTotal  = $PopulationTotal
            CorrectedCount   = $CorrectedCount
            PercentCompliant = $percent
            IsSeedData       = $false
        }

        if ($existing) {
            $newHistory = New-Object System.Collections.Generic.List[object]
            foreach ($item in $history) {
                if ($item.CycleLabel -eq $CycleLabel -and $item.DayNumber -eq $DayNumber) {
                    $newHistory.Add($record)
                } else {
                    $newHistory.Add($item)
                }
            }
            $history = $newHistory
        } else {
            $history.Add($record)
        }

        Export-CycleHistory -Path $HistoryPath -Records $history.ToArray()
        Write-Log $LogPath "Snapshot gravado no JSON: ciclo $CycleLabel, dia $DayNumber ($($CalendarDate.ToString('yyyy-MM-dd'))), $CorrectedCount/$PopulationTotal ($percent%)."
    }
    catch {
        Write-Log $LogPath "Falha ao gravar snapshot no historico JSON (nao interrompe a geracao do dashboard): $($_.Exception.Message)" 'WARN'
    }

    return $percent
}

function Get-PreviousCycleLabel {
    param([string]$CycleLabel)  # 'YYYY-MM'
    $dt = [datetime]::ParseExact($CycleLabel + '-01', 'yyyy-MM-dd', $null)
    $prev = $dt.AddMonths(-1)
    return $prev.ToString('yyyy-MM')
}

function ConvertTo-ScalarDouble {
    <# Protege contra valores vindos do JSON como array/duplicados em vez de numero unico. #>
    param($Value)
    if ($null -eq $Value) { return $null }
    if ($Value -is [array]) {
        if ($Value.Count -eq 0) { return $null }
        $Value = $Value[0]
    }
    try { return [double]$Value } catch { return $null }
}

function Get-CycleFooterHtml {
    <#
        Monta o HTML do rodape (tabela dia-a-dia, resumo semanal,
        fechamento do ciclo) lendo o histórico direto do JSON local -
        nenhuma consulta ao SQL Server aqui.
    #>
    param(
        [Parameter(Mandatory)][string]$HistoryPath,
        [Parameter(Mandatory)][string]$CycleLabel,
        [Parameter(Mandatory)][string]$LogPath
    )

    try {
        $prevLabel = Get-PreviousCycleLabel -CycleLabel $CycleLabel
        $history = Import-CycleHistory -Path $HistoryPath

        $curRows  = @($history | Where-Object CycleLabel -eq $CycleLabel)
        $prevRows = @($history | Where-Object CycleLabel -eq $prevLabel)

        if ($curRows.Count -eq 0) {
            Write-Log $LogPath "Sem linhas de historico (JSON) para o ciclo $CycleLabel; rodape comparativo nao sera exibido hoje." 'WARN'
            return ''
        }

        $prevByDay = @{}
        foreach ($p in $prevRows) { $prevByDay[[int]$p.DayNumber] = $p }

        # Se houver linhas duplicadas para o mesmo DayNumber (ex.: JSON antigo com
        # lixo de execucao anterior), fica so com a ULTIMA por dia.
        $curByDay = [ordered]@{}
        foreach ($c in $curRows) { $curByDay[[int]$c.DayNumber] = $c }

        $days = $curByDay.Keys | Sort-Object { [int]$_ } | ForEach-Object {
            $cur = $curByDay[$_]
            $prev = $prevByDay[[int]$cur.DayNumber]
            $curPercentD  = ConvertTo-ScalarDouble $cur.PercentCompliant
            $prevPercentD = if ($prev) { ConvertTo-ScalarDouble $prev.PercentCompliant } else { $null }
            $delta = if ($null -ne $curPercentD -and $null -ne $prevPercentD) {
                [math]::Round($curPercentD - $prevPercentD, 2)
            } else { $null }

            [pscustomobject]@{
                DayNumber       = [int]$cur.DayNumber
                CalendarDate    = $cur.CalendarDate
                CurrentPercent  = $curPercentD
                PreviousPercent = $prevPercentD
                DeltaPercent    = $delta
            }
        }
        $days = @($days)

        $rowsHtml = ($days | ForEach-Object {
            $curPct  = if ($null -ne $_.CurrentPercent)  { '{0:N2}%' -f [double]$_.CurrentPercent }  else { '-' }
            $prevPct = if ($null -ne $_.PreviousPercent) { '{0:N2}%' -f [double]$_.PreviousPercent } else { '-' }
            $delta   = if ($null -ne $_.DeltaPercent) {
                $d = [double]$_.DeltaPercent
                $cls = if ($d -gt 0) { 'deltaPos' } elseif ($d -lt 0) { 'deltaNeg' } else { 'deltaFlat' }
                $sign = if ($d -gt 0) { '+' } else { '' }
                "<span class='$cls'>$sign$([math]::Round($d,2))%</span>"
            } else { '-' }
            $curDate = if ($_.CalendarDate) { try { ([datetime]$_.CalendarDate).ToString('dd/MM') } catch { '' } } else { '' }
            "<tr><td>Dia $($_.DayNumber)</td><td>$curDate</td><td>$curPct</td><td>$prevPct</td><td>$delta</td></tr>"
        }) -join "`n"

        $withData     = @($days | Where-Object { $null -ne $_.CurrentPercent })
        $lastWithData = if ($withData.Count -gt 0) { $withData[$withData.Count - 1] } else { $null }
        $weekSlice    = if ($withData.Count -gt 0) { $withData | Select-Object -Last 7 } else { @() }
        $weekSlice    = @($weekSlice)
        $firstOfWeek  = if ($weekSlice.Count -gt 0) { $weekSlice[0] } else { $null }

        $weeklyGain = if ($lastWithData -and $firstOfWeek -and $lastWithData.DayNumber -ne $firstOfWeek.DayNumber) {
            '{0:N2}%' -f ([double]$lastWithData.CurrentPercent - [double]$firstOfWeek.CurrentPercent)
        } else { 'N/A' }

        $day31Match = @($days | Where-Object { $_.DayNumber -eq 31 })
        $day31 = if ($day31Match.Count -gt 0) { $day31Match[0] } else { $null }

        $cycleEndSummary = if ($day31 -and $null -ne $day31.CurrentPercent) {
            "Fechamento do ciclo (dia 31): <strong>{0:N2}%</strong>" -f [double]$day31.CurrentPercent
        } elseif ($lastWithData) {
            "Ciclo em andamento - ultimo dia com dado: <strong>{0:N2}%</strong> (Dia $($lastWithData.DayNumber))" -f [double]$lastWithData.CurrentPercent
        } else { "Ciclo em andamento - sem dado ainda." }

        $overallDelta = if ($day31 -and $null -ne $day31.DeltaPercent) {
            "Ganho/perda total no fechamento vs ciclo anterior: <strong>{0:+0.00;-0.00;0.00}%</strong>" -f [double]$day31.DeltaPercent
        } elseif ($lastWithData -and $null -ne $lastWithData.DeltaPercent) {
            "Ganho/perda ate agora vs mesmo dia do ciclo anterior: <strong>{0:+0.00;-0.00;0.00}%</strong>" -f [double]$lastWithData.DeltaPercent
        } else { '' }

        return @"
<section class="panel cycle-footer">
  <h2 style="margin-top:0">Comparativo do ciclo - $CycleLabel vs $prevLabel</h2>
  <div class="note">Ganho da semana (ultimos 7 dias com dado): <strong>$weeklyGain</strong> &nbsp;|&nbsp; $cycleEndSummary &nbsp;|&nbsp; $overallDelta</div>
  <table class="cycle-footer-table" style="width:100%;border-collapse:collapse;margin-top:10px;font-size:13px;">
    <thead>
      <tr style="text-align:left;border-bottom:2px solid #d8e1eb;">
        <th style="padding:6px">Dia do ciclo</th><th style="padding:6px">Data</th>
        <th style="padding:6px">% $CycleLabel</th><th style="padding:6px">% $prevLabel</th><th style="padding:6px">Delta</th>
      </tr>
    </thead>
    <tbody>
$rowsHtml
    </tbody>
  </table>
</section>
<style>
.deltaPos{color:#1f9d55;font-weight:600}
.deltaNeg{color:#d64545;font-weight:600}
.deltaFlat{color:#7b8794;font-weight:600}
.cycle-footer-table tbody tr:nth-child(even){background:#f7fafc}
</style>
"@
    }
    catch {
        Write-Log $LogPath "Falha ao montar o rodape comparativo (nao interrompe a geracao do dashboard): $($_.Exception.Message) | Linha interna: $($_.InvocationInfo.ScriptLineNumber)" 'WARN'
        return ''
    }
}
