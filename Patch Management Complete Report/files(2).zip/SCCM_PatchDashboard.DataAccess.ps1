﻿# ================================================================
# SCCM Monthly Patch Dashboard - ETAPA 3 (módulo de dados)
# Substitui Get-SmsProviderData/Convert-AssetsToRows (WMI) por SQL direto.
# Depende de: SqlServer module (Invoke-Sqlcmd) e do Core dot-sourced antes.
# ================================================================

function ConvertTo-NormalizedDeploymentStatus {
    <#
        Mapeia o Status_State (texto vindo de v_StateNames) para os 4
        buckets que o dashboard já usa hoje: Success / InProgress / Error / Unknown.
        Qualquer valor não mapeado cai em Unknown (e é logado), nunca quebra o dashboard.
    #>
    param([string]$StatusState, [string]$LogPath)

    if ([string]::IsNullOrWhiteSpace($StatusState)) { return 'Unknown' }

    switch -Regex ($StatusState.Trim()) {
        '^(Success|Compliant|Succeeded|Installed)$'            { return 'Success' }
        '^(In Progress|InProgress|Downloading|Installing|Waiting.*)$' { return 'InProgress' }
        '^(Error|Failed|Non-?Compliant.*Error)$'                { return 'Error' }
        '^(Unknown|Requirements Not Met|Not Applicable|Non-?Compliant)$' { return 'Unknown' }
        default {
            if ($LogPath) { Write-Log $LogPath "Status_State '$StatusState' sem mapeamento conhecido; tratado como Unknown." 'WARN' }
            return 'Unknown'
        }
    }
}

function Get-SqlComplianceRows {
    <#
        Executa a query da ETAPA 1 (01_Compliance_Query_AutoResolve.sql) via
        Invoke-Sqlcmd e devolve os dispositivos já no MESMO formato de objeto
        que Convert-AssetsToRows produz hoje, para o dashboard não precisar mudar.
        Colunas que só existiam via WMI (ClientType, Preferred DP, Pending
        Reboot, scans, etc.) ficam em branco nesta etapa, por decisão combinada.
    #>
    param(
        [Parameter(Mandatory)][string]$SqlServer,
        [Parameter(Mandatory)][string]$Database,
        [Parameter(Mandatory)][string]$CollectionID,
        [Parameter(Mandatory)][string]$DeploymentNamePattern,
        [Parameter(Mandatory)][string]$QueryFilePath,
        [Parameter(Mandatory)][string]$LogPath
    )

    if (-not (Get-Module -ListAvailable -Name SqlServer)) {
        throw "O módulo PowerShell 'SqlServer' não está instalado nesta máquina de automação (Install-Module SqlServer)."
    }
    Import-Module SqlServer -ErrorAction Stop

    $sqlText = Get-Content -LiteralPath $QueryFilePath -Raw -Encoding UTF8
    $sqlText = $sqlText.Replace(
        "DECLARE @CollectionID NVARCHAR(8) = 'A0300E28';",
        "DECLARE @CollectionID NVARCHAR(8) = '$CollectionID';"
    )
    $sqlText = $sqlText -replace `
        "DECLARE @DeploymentNamePattern NVARCHAR\(200\) =\s*\r?\n\s*'.*?';", `
        "DECLARE @DeploymentNamePattern NVARCHAR(200) = '$DeploymentNamePattern';"

    Write-Log $LogPath "Executando query de compliance (AssignmentID/KBs/ciclo resolvidos dinamicamente pelo próprio T-SQL)."

    # A query devolve 3 result sets: diagnóstico, compliant, non-compliant.
    $resultSets = Invoke-Sqlcmd -ServerInstance $SqlServer -Database $Database `
        -InputFile $QueryFilePath -OutputAs DataSet -QueryTimeout 300 -ErrorAction Stop

    if ($resultSets.Tables.Count -lt 3) {
        throw "A query não devolveu os 3 result sets esperados (diagnóstico, compliant, non-compliant). Verifique se ela rodou até o fim sem erro no SQL Server."
    }

    $diag = $resultSets.Tables[0] | Select-Object -First 1
    Write-Log $LogPath ("Resolvido -> AssignmentID={0} | Deployment='{1}' | Cycle_Start={2} | Cycle_Day={3} | KBs={4}" -f `
        $diag.Resolved_AssignmentID, $diag.Resolved_DeploymentName, $diag.Cycle_Start_Date, $diag.Cycle_Day_Number, $diag.Resolved_KBs)

    $rows = New-Object System.Collections.Generic.List[object]

    foreach ($table in @($resultSets.Tables[1], $resultSets.Tables[2])) {
        foreach ($r in $table) {
            $statusState = [string]$r.Status_State
            $deploymentStatus = ConvertTo-NormalizedDeploymentStatus -StatusState $statusState -LogPath $LogPath

            $errorCodeValue = [UInt64]0
            if ($r.Error_Code_ExitCode -ne [DBNull]::Value -and $r.Error_Code_ExitCode) {
                try { $errorCodeValue = [UInt64][int64]$r.Error_Code_ExitCode } catch { $errorCodeValue = 0 }
            }
            $errorDetail = if ($errorCodeValue -ne 0) {
                Get-ErrorDetail -Code $errorCodeValue -LastEnforcementMessage '' -StatusDescription ''
            } else { '' }
            $recommendedActions = if ($errorCodeValue -ne 0) { Get-ErrorRecommendations -Code $errorCodeValue } else { '' }

            $complianceBucket = [string]$r.Compliance_Bucket

            $rows.Add([pscustomobject]@{
                Device                      = [string]$r.ComputerName
                ClientType                  = ''
                Client                      = ''
                CurrentLoggedOnUser         = [string]$r.UserId
                UserUPN                     = [string]$r.User_Email
                SiteCode                    = ''
                ClientStatus                = 'Unknown'
                ClientCheckResult           = 'Unknown'
                PolicyRequest               = ''
                HeartbeatDDR                = ''
                HardwareScan                = ''
                SoftwareScan                = ''
                ManagementPoint             = ''
                StatusMessage                = ''
                PreferredDistributionPoints = ''
                ADSite                      = ''
                Domain                      = if ($r.Table.Columns.Contains('OSDomain')) { [string]$r.OSDomain } else { '' }
                Uptime                      = ''
                OperatingSystem             = ''
                OSVersion                   = ''
                OSBuildNumber               = [string]$r.FullOSBuild
                PendingRestart              = ''
                RebootReason                = ''
                RebootClientState           = ''
                DeploymentStatus            = $deploymentStatus
                ErrorCode                   = if ($r.Hex_Error_Code -ne [DBNull]::Value) { [string]$r.Hex_Error_Code } else { '' }
                ErrorDetail                 = $errorDetail
                RecommendedActions          = $recommendedActions
                LastStatusTime              = if ($r.Last_Modification -ne [DBNull]::Value) { [string]$r.Last_Modification } else { '' }
                ResourceID                  = 0
                ComplianceBucket            = $complianceBucket
                CycleStartDate              = [string]$diag.Cycle_Start_Date
                CycleDayNumber              = [int]$diag.Cycle_Day_Number
            })
        }
    }

    [pscustomobject]@{
        Rows           = $rows.ToArray()
        AssignmentID   = [string]$diag.Resolved_AssignmentID
        DeploymentName = [string]$diag.Resolved_DeploymentName
        CollectionID   = $CollectionID
        CycleStartDate = [datetime]$diag.Cycle_Start_Date
        CycleDayNumber = [int]$diag.Cycle_Day_Number
        ResolvedKBs    = [string]$diag.Resolved_KBs
    }
}

function Save-CycleSnapshot {
    <#
        Grava (ou atualiza) a linha do dia corrente na tabela de histórico
        criada na ETAPA 2 (dbo.PatchCycle_DailyHistory).
    #>
    param(
        [Parameter(Mandatory)][string]$SqlServer,
        [Parameter(Mandatory)][string]$Database,
        [Parameter(Mandatory)][string]$CollectionID,
        [Parameter(Mandatory)][string]$CycleLabel,
        [Parameter(Mandatory)][int]$DayNumber,
        [Parameter(Mandatory)][datetime]$CalendarDate,
        [Parameter(Mandatory)][int]$PopulationTotal,
        [Parameter(Mandatory)][int]$CorrectedCount,
        [Parameter(Mandatory)][string]$LogPath
    )

    $percent = if ($PopulationTotal -gt 0) { [math]::Round(($CorrectedCount / $PopulationTotal) * 100, 2) } else { 0 }

    $mergeSql = @"
MERGE dbo.PatchCycle_DailyHistory AS target
USING (SELECT
            '$CycleLabel'                          AS CycleLabel,
            $DayNumber                              AS DayNumber,
            CONVERT(date, '$($CalendarDate.ToString('yyyy-MM-dd'))') AS CalendarDate,
            '$CollectionID'                         AS CollectionID,
            $PopulationTotal                        AS PopulationTotal,
            $CorrectedCount                         AS CorrectedCount,
            $percent                                AS PercentCompliant
      ) AS src
ON  target.CycleLabel = src.CycleLabel
AND target.DayNumber  = src.DayNumber
WHEN MATCHED THEN
    UPDATE SET
        PopulationTotal    = src.PopulationTotal,
        CorrectedCount     = src.CorrectedCount,
        PercentCompliant   = src.PercentCompliant,
        CollectionID       = src.CollectionID,
        SnapshotCapturedAt = SYSDATETIME(),
        IsSeedData         = 0
WHEN NOT MATCHED THEN
    INSERT (CycleLabel, DayNumber, CalendarDate, CollectionID, PopulationTotal, CorrectedCount, PercentCompliant, IsSeedData)
    VALUES (src.CycleLabel, src.DayNumber, src.CalendarDate, src.CollectionID, src.PopulationTotal, src.CorrectedCount, src.PercentCompliant, 0);
"@

    Invoke-Sqlcmd -ServerInstance $SqlServer -Database $Database -Query $mergeSql -QueryTimeout 60 -ErrorAction Stop
    Write-Log $LogPath "Snapshot gravado: ciclo $CycleLabel, dia $DayNumber ($($CalendarDate.ToString('yyyy-MM-dd'))), $CorrectedCount/$PopulationTotal ($percent%)."
    return $percent
}

function Get-PreviousCycleLabel {
    param([string]$CycleLabel)  # 'YYYY-MM'
    $dt = [datetime]::ParseExact($CycleLabel + '-01', 'yyyy-MM-dd', $null)
    $prev = $dt.AddMonths(-1)
    return $prev.ToString('yyyy-MM')
}

function Get-CycleFooterHtml {
    <#
        Monta o HTML do rodapé: tabela dia-a-dia (ciclo atual x ciclo anterior,
        pelo mesmo Day Number), resumo semanal e performance do ciclo (dia 31/fim).
    #>
    param(
        [Parameter(Mandatory)][string]$SqlServer,
        [Parameter(Mandatory)][string]$Database,
        [Parameter(Mandatory)][string]$CycleLabel,
        [Parameter(Mandatory)][string]$LogPath
    )

    $prevLabel = Get-PreviousCycleLabel -CycleLabel $CycleLabel

    $sql = @"
SELECT
    cur.DayNumber,
    cur.CalendarDate                                   AS Current_Date,
    cur.PercentCompliant                               AS Current_Percent,
    prev.CalendarDate                                  AS Previous_Date,
    prev.PercentCompliant                              AS Previous_Percent,
    CASE WHEN cur.PercentCompliant IS NULL OR prev.PercentCompliant IS NULL THEN NULL
         ELSE ROUND(cur.PercentCompliant - prev.PercentCompliant, 2) END AS Delta_Percent
FROM dbo.PatchCycle_DailyHistory cur
LEFT JOIN dbo.PatchCycle_DailyHistory prev
    ON prev.CycleLabel = '$prevLabel' AND prev.DayNumber = cur.DayNumber
WHERE cur.CycleLabel = '$CycleLabel'
ORDER BY cur.DayNumber;
"@

    $days = @(Invoke-Sqlcmd -ServerInstance $SqlServer -Database $Database -Query $sql -QueryTimeout 60 -ErrorAction Stop)

    if ($days.Count -eq 0) {
        Write-Log $LogPath "Sem linhas de histórico para o ciclo $CycleLabel; rodapé comparativo não será exibido hoje." 'WARN'
        return ''
    }

    $rowsHtml = ($days | ForEach-Object {
        $curPct  = if ($_.Current_Percent  -ne [DBNull]::Value) { '{0:N2}%' -f [double]$_.Current_Percent }  else { '—' }
        $prevPct = if ($_.Previous_Percent -ne [DBNull]::Value) { '{0:N2}%' -f [double]$_.Previous_Percent } else { '—' }
        $delta   = if ($_.Delta_Percent    -ne [DBNull]::Value) {
            $d = [double]$_.Delta_Percent
            $cls = if ($d -gt 0) { 'deltaPos' } elseif ($d -lt 0) { 'deltaNeg' } else { 'deltaFlat' }
            "<span class='$cls'>$('{0:+0.00;-0.00;0.00}' -f $d)%</span>"
        } else { '—' }
        $curDate = if ($_.Current_Date -ne [DBNull]::Value) { ([datetime]$_.Current_Date).ToString('dd/MM') } else { '' }
        "<tr><td>Dia $($_.DayNumber)</td><td>$curDate</td><td>$curPct</td><td>$prevPct</td><td>$delta</td></tr>"
    }) -join "`n"

    $lastWithData = $days | Where-Object { $_.Current_Percent -ne [DBNull]::Value } | Select-Object -Last 1
    $firstOfWeek  = $days | Where-Object { $_.Current_Percent -ne [DBNull]::Value } | Select-Object -Last 7 -First 1
    $weeklyGain = if ($lastWithData -and $firstOfWeek -and $lastWithData.DayNumber -ne $firstOfWeek.DayNumber) {
        '{0:N2}%' -f ([double]$lastWithData.Current_Percent - [double]$firstOfWeek.Current_Percent)
    } else { 'N/A' }

    $day31 = $days | Where-Object { $_.DayNumber -eq 31 } | Select-Object -First 1
    $cycleEndSummary = if ($day31 -and $day31.Current_Percent -ne [DBNull]::Value) {
        "Fechamento do ciclo (dia 31): <strong>{0:N2}%</strong>" -f [double]$day31.Current_Percent
    } else {
        "Ciclo em andamento — último dia com dado: <strong>{0:N2}%</strong> (Dia $($lastWithData.DayNumber))" -f [double]$lastWithData.Current_Percent
    }

    $overallDelta = if ($day31 -and $day31.Delta_Percent -ne [DBNull]::Value) {
        "Ganho/perda total no fechamento vs ciclo anterior: <strong>{0:+0.00;-0.00;0.00}%</strong>" -f [double]$day31.Delta_Percent
    } elseif ($lastWithData -and $lastWithData.Delta_Percent -ne [DBNull]::Value) {
        "Ganho/perda até agora vs mesmo dia do ciclo anterior: <strong>{0:+0.00;-0.00;0.00}%</strong>" -f [double]$lastWithData.Delta_Percent
    } else { '' }

    return @"
<section class="panel cycle-footer">
  <h2 style="margin-top:0">Comparativo do ciclo — $CycleLabel vs $prevLabel</h2>
  <div class="note">Ganho da semana (últimos 7 dias com dado): <strong>$weeklyGain</strong> &nbsp;|&nbsp; $cycleEndSummary &nbsp;|&nbsp; $overallDelta</div>
  <table class="cycle-footer-table" style="width:100%;border-collapse:collapse;margin-top:10px;font-size:13px;">
    <thead>
      <tr style="text-align:left;border-bottom:2px solid #d8e1eb;">
        <th style="padding:6px">Dia do ciclo</th><th style="padding:6px">Data</th>
        <th style="padding:6px">% $CycleLabel</th><th style="padding:6px">% $prevLabel</th><th style="padding:6px">Delta</th>
      </tr>
    </thead>
    <tbody>
$rowsHtml
    </tbody>
  </table>
</section>
<style>
.deltaPos{color:#1f9d55;font-weight:600}
.deltaNeg{color:#d64545;font-weight:600}
.deltaFlat{color:#7b8794;font-weight:600}
.cycle-footer-table tbody tr:nth-child(even){background:#f7fafc}
</style>
"@
}
