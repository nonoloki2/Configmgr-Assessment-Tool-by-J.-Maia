﻿<#
================================================================================
 SCCM Monthly Patch Dashboard - ETAPA 3
 Execução 100% desatendida (sem WPF). Disparado pela ferramenta de automação
 todo dia às 17h. Gera o mesmo Dashboard.html de sempre, agora alimentado
 pelas queries SQL (Etapa 1), grava o snapshot do dia (Etapa 2) e injeta o
 rodapé comparativo de ciclo direto no HTML.
================================================================================
#>

param()

# ================================================================
# CONFIGURAÇÃO FIXA — preencher UMA vez. A automação não passa
# nenhum parâmetro na hora de agendar; roda sem argumentos.
# ================================================================

$SqlServer   = ''                     # <-- ÚNICO valor que falta preencher (nome/instância do SQL Server do site A03)
$Database    = 'CM_A03'

# A coleção reportada agora é sempre a mesma que o próprio deployment
# do mês atinge (resolvida automaticamente pela query) — não precisa
# mais ser escolhida aqui.

$DeploymentNamePattern = 'Desktop Deployment - Enterprise Production - Windows - {YYYY} - {MM}'

# Pastas relativas ao próprio script — nada disso precisa ser passado por fora
$QueryFilePath = Join-Path $PSScriptRoot '01_Compliance_Query_AutoResolve.sql'
$OutputFolder  = Join-Path $PSScriptRoot 'Reports'
$LogFolder     = Join-Path $OutputFolder 'Logs'
$HistoryPath   = Join-Path $PSScriptRoot 'PatchCycleHistory.json'          # historico local, NAO fica no SQL
$HistorySeedPath = Join-Path $PSScriptRoot 'PatchCycleHistory.seed.json'  # carga inicial (Jun/Jul) fornecida pelo cliente

if ([string]::IsNullOrWhiteSpace($SqlServer)) {
    throw "Preencha a variável `$SqlServer no início deste script antes de agendar a automação."
}

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'SCCM_PatchDashboard.Core.ps1')
. (Join-Path $PSScriptRoot 'SCCM_PatchDashboard.DataAccess.ps1')

New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
New-Item -ItemType Directory -Path $LogFolder -Force | Out-Null

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$logPath = Join-Path $LogFolder "Run_$stamp.log"
Set-Content -LiteralPath $logPath -Value '' -Encoding UTF8

try {
    Write-Log $logPath "===== Execucao iniciada (headless) ====="

    if (-not (Test-Path -LiteralPath $HistoryPath) -and (Test-Path -LiteralPath $HistorySeedPath)) {
        Copy-Item -LiteralPath $HistorySeedPath -Destination $HistoryPath
        Write-Log $logPath "Historico local nao existia; carga inicial (seed Jun/Jul) copiada para $HistoryPath."
    }

    # 1) Extrai dados via SQL - SOMENTE LEITURA (SELECT). AssignmentID, KBs e
    #    ciclo sao resolvidos dinamicamente pela propria query.
    $data = Get-SqlComplianceRows -SqlServer $SqlServer -Database $Database `
        -DeploymentNamePattern $DeploymentNamePattern `
        -QueryFilePath $QueryFilePath -LogPath $logPath

    if ($data.Rows.Count -eq 0) {
        throw "Nenhum dispositivo retornado para a colecao $($data.CollectionName) / AssignmentID $($data.AssignmentID)."
    }

    $cycleLabel = $data.CycleStartDate.ToString('yyyy-MM')
    $today = Get-Date

    # 2) Grava o snapshot do dia no historico LOCAL (JSON) - nada escrito no SQL
    $population = $data.Rows.Count
    $corrected  = @($data.Rows | Where-Object ComplianceBucket -eq 'Compliant').Count

    Save-CycleSnapshot -HistoryPath $HistoryPath `
        -CycleLabel $cycleLabel -DayNumber $data.CycleDayNumber -CalendarDate $today `
        -PopulationTotal $population -CorrectedCount $corrected -LogPath $logPath | Out-Null

    # 3) Monta o HTML do rodape comparativo (ciclo atual x ciclo anterior), a partir do JSON
    #    Isso e um extra: se falhar por qualquer motivo, o dashboard principal
    #    tem que sair do mesmo jeito, so sem o rodape.
    $footerHtml = ''
    try {
        $footerHtml = Get-CycleFooterHtml -HistoryPath $HistoryPath -CycleLabel $cycleLabel -LogPath $logPath
    } catch {
        Write-Log $logPath "Rodape comparativo falhou e foi ignorado: $($_.Exception.Message)" 'WARN'
    }

    # 4) Gera o dashboard (mesmas funções/HTML de sempre + rodapé novo)
    $result = Export-ReportPackage `
        -Rows $data.Rows `
        -DeploymentName $data.DeploymentName `
        -CollectionName $data.CollectionName `
        -CollectionID $data.CollectionID `
        -AssignmentID $data.AssignmentID `
        -DeploymentID ([string]$data.AssignmentID) `
        -BaseOutputFolder $OutputFolder `
        -LogPath $logPath `
        -CheckApiBase '' `
        -CheckToken '' `
        -CycleFooterHtml $footerHtml

    Write-Log $logPath "Dashboard gerado com sucesso: $($result.DashboardPath)"
    Write-Log $logPath "===== Execução concluída OK ====="
    exit 0
}
catch {
    $msg = "ERRO: $($_.Exception.Message) | Linha: $($_.InvocationInfo.ScriptLineNumber) | $($_.InvocationInfo.PositionMessage)"
    if (Test-Path -LiteralPath $logPath) { Write-Log $logPath $msg 'ERROR' }
    Write-Error $msg
    exit 1
}
