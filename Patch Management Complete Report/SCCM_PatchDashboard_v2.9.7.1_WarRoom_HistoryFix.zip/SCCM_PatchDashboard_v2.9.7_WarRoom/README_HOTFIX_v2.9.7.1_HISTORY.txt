SCCM Patch Dashboard v2.9.7.1 - Patch Evolution History Fix
============================================================

Scope of this hotfix
--------------------
Only the Patch Compliance Evolution data source/rendering and the call that passes
PatchCycleHistory.json into the report package were changed.

What was wrong
--------------
The dashboard previously maintained a second history under _PatchDashboardHistory
and replaced same-day entries. With a single point, the browser displayed 0.00%
weekly progression even though that meant "insufficient history", not "no progress".

What changed
------------
- Patch evolution now reads PatchCycleHistory.json, the same authoritative cycle
  history written by Save-CycleSnapshot.
- No second _PatchDashboardHistory store is created or updated by this version.
- Current cycle and previous cycle are aligned by Cycle Day.
- Current cycle is blue; previous cycle is gray.
- The headline is now "current cycle change" and is expressed in percentage points.
- If fewer than two valid current-cycle points exist, the value is N/A instead of 0.00%.
- PatchHistory.json inside each generated report is now an export/view of the cycle
  history used by the chart; it is not a separate source of truth.

Not changed
-----------
- SCCM SQL compliance query
- ComplianceBucket/QFE classification
- Success / InProgress / Error / Unknown classification
- Top 3 error logic
- Endpoint Health
- MP / Preferred DP / Disk Space logic
- War Room checkpoint history
- PatchCycleHistory.json contents or Save-CycleSnapshot behavior

Validation note
---------------
If the current cycle has only one valid snapshot, the chart will show that point and
N/A for current-cycle change. This is intentional and prevents a false 0.00% result.
