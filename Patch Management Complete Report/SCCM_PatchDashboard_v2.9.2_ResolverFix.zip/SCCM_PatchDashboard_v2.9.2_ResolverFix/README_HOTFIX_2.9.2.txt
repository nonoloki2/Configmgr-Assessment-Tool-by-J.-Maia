SCCM Patch Dashboard v2.9.2 - Resolver Fix

ESCOPO DESTA CORRECAO
Somente a resolucao automatica do deployment mensal foi corrigida.

Problema observado em 11/08/2026:
- A busca frouxa da 2.9 aceitou o deployment auxiliar de JULHO
  "...2026 - 07 - 08 - NBU All" porque encontrou "08" no sufixo.
- Esse deployment apontava para uma collection de 2.103 devices.
- A 2.9.1 corrigiu de forma excessiva e exigiu "...2026 - 08", mas esse deployment
  principal ainda nao existia, causando abort.

Regra 2.9.2:
1. Procura igualdade EXATA do nome principal esperado para o mes corrente.
2. Nao aceita nomes com sufixos/rings/colecoes auxiliares como substitutos.
3. Na virada do Patch Tuesday, se o principal do novo mes ainda nao existir, usa
   temporariamente o principal EXATO do mes anterior.
4. Se nem isso existir, aborta e lista candidatos; nao adivinha.
5. A baseline SQL continua protegida contra alteracao de quantidade pelos enriquecimentos.

Nao foram alteradas nesta hotfix as regras de Success/In Progress/Error/Unknown,
HTML, exports ou calculos de compliance.
