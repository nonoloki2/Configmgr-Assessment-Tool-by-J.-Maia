SCCM Patch Dashboard v2.9.1 - HOTFIX
=====================================

Correção principal
------------------
A resolução automática do deployment aceitava o mês em qualquer posição do nome.
Em 11/08/2026 isso permitiu que o nome:
  Desktop Deployment - Enterprise Production - Windows - 2026 - 07 - 08 - NBU All
fosse aceito como deployment de agosto, porque continha "2026" e depois "08".
Resultado: AssignmentID/CollectionID do deployment de JULHO, produzindo a coleção
"08 - NBU All" e apenas ~2.103 devices.

Agora o SQL exige o prefixo real do ciclo:
  ... - 2026 - 08...
(normalizando apenas espaços), impedindo que números do sufixo sejam confundidos
com o mês.

Proteções adicionais
--------------------
1. Loga imediatamente o SQL baseline count + deployment + collection + AssignmentID.
2. Aborta se o deployment resolvido não corresponder ao YYYY-MM do ciclo.
3. SMS Provider enrichment só é aceito se preservar exatamente a contagem SQL.
4. Domain Trust enrichment só é aceito se preservar exatamente a contagem SQL.
5. Corrigido output acidental de List.Add() no pipeline do enriquecimento.

Nenhuma lógica de Success/In Progress/Error/Unknown foi alterada neste hotfix.
Nenhuma query de compliance (regras de compliant/non-compliant) foi alterada;
somente a seleção do deployment mensal foi tornada inequívoca.
