SCCM Patch Dashboard v2.9.7 - History & Cycle Comparison
========================================================

BASELINE
- Built directly from validated v2.9.6 QFE Compliance.
- Compliance SQL, Top 3 Errors, MP, Preferred DP, Endpoint Health and Disk Space logic are unchanged.
- No live endpoint queries were added.

HISTORY
- PatchCycleHistory.seed.json contains the supplied Excel bootstrap for cycles 2026-06 and 2026-07.
- Imported points are marked Source=ExcelBootstrap and IsSeedData=true.
- Missing historical values remain null; no interpolation is performed.
- Every dashboard execution APPENDS a new run with Source=SCCM-QFE, RunId and CapturedAt.
- Multiple executions on the same day are retained.
- The dashboard comparison uses the latest non-seed run for each Cycle Day.
- Before each JSON write, a backup is created under HistoryBackup.
- PatchCycleHistory.latest.csv is regenerated for easy review in Excel.

CYCLE POSITION
- Existing calendar dates from the bootstrap keep their exact DAY mapping.
- Later dates in an existing cycle are extrapolated from the last known calendar mapping.
- A brand-new cycle with no historical anchor falls back to the SQL cycle day in zero-based form.

DASHBOARD
- Adds Patch Cycle Evolution as an independent section.
- Shows current cycle %, previous cycle same-DAY %, and delta in percentage points.
- Includes a current-vs-previous SVG trend and expandable day-by-day table.
- Does not modify patch compliance cards or Endpoint Health.
