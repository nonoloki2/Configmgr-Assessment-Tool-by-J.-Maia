SCCM Monthly Patch Dashboard v2.6
Optimized Client Health, Recommended Actions and History

Run:
  powershell.exe -ExecutionPolicy Bypass -File .\SCCM_Monthly_Patch_Dashboard_v2.6_Optimized_Actions.ps1

IMPORTANT BEFORE REPLACING THE CURRENT VERSION
1. Copy your existing KnowledgeBase\ErrorKnowledgeBase.json into the KnowledgeBase folder beside the v2.6 PS1.
2. Do not delete your existing report history folder: <Output Folder>\_PatchDashboardHistory\
3. Test the new release with one deployment before replacing the current production shortcut.

FIXES
- Recommended Actions is never left blank for a non-zero error code.
- The offline JSON Knowledge Base remains the first recommendation source.
- Added specific fallback guidance for common SCCM, Windows Update, Delivery Optimization, MSI and servicing errors.
- Added category-based fallback recommendations for codes not yet mapped in the JSON.

PERFORMANCE OPTIMIZATION
- ConfigMgr enrichment data continues to be queried in provider-side batches.
- Resource property lookup no longer runs repeated Where-Object pipelines for every field/device.
- For deployments above 500 device records, bulk Pending Reboot remote CIM checks are automatically deferred.
- Pending Reboot displays the existing Check button so each device can be queried on demand.
- This prevents 8,000+ sequential remote calls from holding the dashboard near the Enriching stage for hours.

UNCHANGED
- Existing dashboard design and navigation.
- Top 3 error-code cards and device drilldown pages.
- Daily history and weekly progression.
- Offline-only Knowledge Base behavior.
