SCCM Monthly Patch Dashboard v2.8 - Final Stabilization Release

Run:
  powershell.exe -ExecutionPolicy Bypass -File .\SCCM_Monthly_Patch_Dashboard_v2.8_Final.ps1

Before running:
1. Copy your validated KnowledgeBase\ErrorKnowledgeBase.json from v2.7/v2.6 into this package's KnowledgeBase folder.
2. Keep v2.7 as your rollback copy until v2.8 is validated.

Changes in v2.8:
- Preserves the existing Top 3 error-code counting and grouping logic.
- Fixes error-card descriptions so compliance/status labels such as Compliant, Success, Installed and In Progress cannot be used as error descriptions.
- Adds the correct fallback description for 0x8007045B.
- Removes the empty Last Logon column.
- Adds Preferred Distribution Points using batch SMS Provider queries and in-memory maps.
- Preserves the optimized enrichment, SCCM ClientState pending reboot, reboot reason, live verification, history, charts and existing drill-down behavior.

Preferred Distribution Points note:
- This is derived from the device boundary-group information exposed by SMS_CombinedDeviceResources and the site systems assigned to those boundary groups.
- It represents available/preferred content sources, not proof of which DP was used for a specific download.
- If the site's SMS_CombinedDeviceResources class does not expose boundary-group membership properties, the value remains blank rather than triggering per-device queries.
