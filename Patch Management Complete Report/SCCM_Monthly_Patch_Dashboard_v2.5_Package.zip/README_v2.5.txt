SCCM Monthly Patch Dashboard v2.5 - Client Health and History

Run:
  powershell.exe -ExecutionPolicy Bypass -File .\SCCM_Monthly_Patch_Dashboard_v2.5_ClientHealth_History.ps1

Report column changes:
- Removed: UPN Source, Last Online Time, Device Status, Client Activity.
- Added: Pending Reboot, Uptime, Client Status, Client Check Result, Policy Request,
  Heartbeat DDR, Hardware Scan, Software Scan, Management Point, Status Message,
  and Last Logon.
- Last Logon is read from SCCM SMS_CombinedDeviceResources, not Active Directory.
- Uptime is calculated from LastBootUpTime in SCCM hardware inventory.

Dashboard changes:
- Shows the three most frequent error codes.
- Each error card opens a dedicated device-list page in a new browser tab.
- Stores one daily history record per deployment/Assignment ID.
- Displays patch success evolution and weekly success progression.
- Keeps the latest 90 daily history entries.

History location:
  <selected report output folder>\_PatchDashboardHistory\

Important:
- Keep the KnowledgeBase folder beside the PS1 file.
- Some client-health fields depend on the ConfigMgr site's discovery/inventory data.
  The script uses alternate SCCM property names when available and displays blank or
  Unknown when the site has not populated a field.
- The original v2.4 script was not overwritten.
