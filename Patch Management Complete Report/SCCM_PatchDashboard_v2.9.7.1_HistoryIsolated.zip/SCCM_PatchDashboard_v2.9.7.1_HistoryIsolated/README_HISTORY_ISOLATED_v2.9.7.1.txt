SCCM Patch Dashboard v2.9.7.1 - HISTORY ISOLATED

BASELINE
- Built by copying the validated v2.9.6 QFE Compliance release.
- NO existing v2.9.6 script/SQL file was edited.
- QFE compliance, Top 3 Errors, MP, Preferred DP, Endpoint Health, disk-space logic and endpoint real-time blocking remain byte-for-byte unchanged.

HOW TO RUN
Use:
  .\Run-Unattended-WithHistory.ps1

Do NOT schedule History.PostProcess.ps1 directly.

FLOW
1. Wrapper launches the untouched Run-Unattended.ps1 in a child PowerShell process.
2. The GOLDEN report completes first.
3. Only after exit code 0, History.PostProcess.ps1 reads the already-generated Dashboard.html.
4. It appends a QFE snapshot to PatchCycleHistory.Canonical.json.
5. It injects the current-vs-previous cycle comparison into that already-generated HTML.

FAILURE ISOLATION
- History performs NO SQL, SCCM Provider, AD, WMI, CIM, WinRM, ping or endpoint query.
- If History fails, the GOLDEN patch report remains valid and the wrapper returns success after warning.
- History cannot change the dataset/cardinality/status counts because it runs after the patch report is finished.

BOOTSTRAP
- 2026-06: DAY -8 through DAY 28 from the supplied spreadsheet; missing DAY 10 and DAY 11 values are NULL.
- 2026-07: explicit calendar DAY -8 through DAY 22. Supplied numeric data begins DAY -5 (15-Jul) through DAY 22 (11-Aug); earlier blank/DIV0 cells remain NULL.
- ExcelBootstrap rows remain preserved. New live runs are appended as Source=SCCM-QFE and win for display on the same DAY.

FILES
- PatchCycleHistory.Canonical.json: append-only canonical history.
- PatchCycleHistory.Canonical.latest.csv: latest effective row per cycle/day for Excel review.
- HistoryBackup\: automatic JSON backups before every append.
