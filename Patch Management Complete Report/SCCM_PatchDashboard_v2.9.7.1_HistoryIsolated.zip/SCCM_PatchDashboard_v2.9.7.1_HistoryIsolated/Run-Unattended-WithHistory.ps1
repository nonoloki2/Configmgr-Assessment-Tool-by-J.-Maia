<#
SAFE WRAPPER
1) Runs the untouched v2.9.6 GOLDEN in a separate PowerShell process.
2) Only if GOLDEN exits 0, runs local history post-processing against the generated HTML.
History can never change the SQL result, device list, status buckets, Top 3, MP/DP or Endpoint Health.
#>
param()
$ErrorActionPreference='Stop'
$core=Join-Path $PSScriptRoot 'Run-Unattended.ps1'
$reports=Join-Path $PSScriptRoot 'Reports'
$history=Join-Path $PSScriptRoot 'PatchCycleHistory.Canonical.json'
$post=Join-Path $PSScriptRoot 'History.PostProcess.ps1'

$exe=Join-Path $PSHOME 'powershell.exe'
if(-not (Test-Path -LiteralPath $exe)){$exe='powershell.exe'}

Write-Host '[1/2] Running untouched v2.9.6 GOLDEN patch report...'
& $exe -NoProfile -ExecutionPolicy Bypass -File $core
$rc=$LASTEXITCODE
if($rc -ne 0){
    Write-Error "GOLDEN patch report failed with exit code $rc. History was NOT executed."
    exit $rc
}

Write-Host '[2/2] Patch report is complete. Running isolated history post-process...'
try {
    & $post -ReportsRoot $reports -HistoryPath $history
    Write-Host 'Completed: patch report + isolated history.'
    exit 0
}
catch {
    Write-Warning "History failed AFTER patch report completion: $($_.Exception.Message)"
    Write-Warning 'The GOLDEN patch report remains valid. Only history was skipped.'
    exit 0
}
