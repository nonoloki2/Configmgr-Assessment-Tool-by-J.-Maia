SCCM Monthly Patch Dashboard v2.7
=================================

WHAT CHANGED
- Pending Reboot now uses SCCM SMS_CombinedDeviceResources.ClientState by default.
- Added Reboot Reason with support for multiple simultaneous reasons:
  * Configuration Manager
  * File Rename
  * Windows Update
  * Add or Remove Feature
- Preserves the v2.6 batch optimization: no remote call per device during normal generation.
- Added Verify Live per device and a visible-row bulk verification button.
- Live verification is optional and does not remove the SCCM-reported reason.
- Pending Reboot filter now includes Unknown.
- Corrected Client Check Result interpretation: 1 = Passed/Healthy, 2 = Failed/Unhealthy.

IMPORTANT
Keep your proven v2.6 as a backup.
Copy your existing ErrorKnowledgeBase.json into the KnowledgeBase folder beside the PS1 before running.

DATA BEHAVIOR
- ClientState 0: Pending Reboot = No
- ClientState > 0: Pending Reboot = Yes and the bitmask is translated into one or more reasons.
- Missing ClientState: Pending Reboot = Unknown
- Verify Live queries CCM_ClientUtilities only when explicitly requested.

RUN
powershell.exe -ExecutionPolicy Bypass -File .\SCCM_Monthly_Patch_Dashboard_v2.7_SCCM_RebootReason.ps1
